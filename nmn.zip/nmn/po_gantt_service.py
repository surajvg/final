"""
po_gantt_service.py  -  Production Schedule: PO on Process / PO on Machines / Planned vs Actual

    GET    /schedule/po-gantt                 the schedule (start_at = exact start, default now)
    GET    /schedule/po-gantt/orders          yet-to-start POs + part numbers of the plant (pickers; locked POs flagged)
    GET    /schedule/po-gantt/plants          plant codes
    GET    /schedule/po-gantt/process-check   every process: batch or series and why, batch size, machines
    GET    /schedule/po-gantt/export          the same schedule as .xlsx
    GET/PUT /schedule/part-process-time       machine hours + batch size per part / process
    GET/PUT /schedule/settings                every scheduling rule (Configure dialog) -> table schedule_settings
    POST   /schedule/plans                    save the schedule as a plan VERSION (new plan REV01 / revision REVnn)
    GET    /schedule/plans?plant=             saved versions with Plan_ID / Version_ID / Previous_Version_ID / reference
    GET    /schedule/plans/view               read-only Gantt data of a version for a date range (Assign PCB page)
    GET    /schedule/plans/{id}               one saved version with its snapshot
    PUT    /schedule/plans/{id}/baseline      make it the current plan of its plant
    DELETE /schedule/plans/{id}               only the newest version of a plan, and only if no PO was assigned from it
    GET    /schedule/plans/{id}/compare       planned (saved version) vs actual (operator_log / pcb_process_log)
    POST   /schedule/locks                    PCBs of these POs were assigned from a plan -> keep their slots
    GET    /schedule/locks?plant=             POs whose slots are kept
    DELETE /schedule/locks/{po}               release a PO's slots

Hook-up (Data_Server.py) - unchanged:
    from po_gantt_service import create_po_gantt_router
    app.include_router(create_po_gantt_router(init_db, verify_token, engine))

New tables (created automatically): schedule_settings, schedule_plan_version, schedule_po_lock.

RULES (most numbers / lists / names below are settings the user can change - see SETTINGS_SCHEMA; weekly off days,
       off Saturdays, the "always batch" words, the finished statuses and the saved-plan / assignment rules are fixed)
 * POs come ONLY from PcbData. A PO is open when every one of its PCBs has a status in PCB_OPEN_STATUSES.
 * CHILD / MAIN: product_type_master, else PcbData.Type; main <- child link: same product type, else bom_items,
   else EXTRA_CHILD_LINKS. Child -> main POs by serial number first, then by quantity.
 * Flow of a part: product_workflow_mapping, else part_process_time in step order. LINE_GROUPS = steps run as one line.
 * Scheduling starts at the exact moment the schedule is made (or the start_at the user picks).
 * Working window per process: work centre (sap_workcenter_capacity) operating_time, else shift end - shift start minus
   the break; no work centre -> shift_definition; else the fallback settings. Nothing is rounded up to 2 shifts.
 * Machines from the work centre (number_of_individuals) / equipment_details; breakdowns, maintenance, spares and
   consumables block machines / processes; off days from the settings + public_holidays + calendar_exceptions.
 * A PO whose PCBs were assigned from a saved version keeps that version's slots (LOCK_ASSIGNED_SLOTS); later
   schedules are built around them.
"""
import gzip
import heapq
import io
import json
import math
import re
from collections import defaultdict
from datetime import date, datetime, time, timedelta
from typing import Any, Dict, Iterable, List, NamedTuple, Optional, Tuple

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel
from sqlalchemy import JSON, Column, DateTime, Integer, String, func, or_, inspect as sa_inspect, text as sa_text
from sqlalchemy.orm import Session, declarative_base, joinedload

from Database_models import (
    BOMItem, CalendarException, Equipments, MachineBreakdownLog, MaintenanceScheduleLog, OperatorLog,
    OperatorShiftAssignment, OperatorStepMapping, PartProcessTime, PCBAssignment, PcbData, PCBProcessLog, Plant,
    ProcessFlowMaster, Processtype, ProductTypeMaster, ProductWorkflowMapping, PublicHoliday, SchedulePlan,
    SchedulePlanItem, ShiftDefinition, StageCapacityDB, StageScheduleConfig, InventorySpares, Consumables, WorkcenterCapacity,
    ProductPlantWorkCenterRouting
)

# --------------------------------------------------------------------------------------
# Settings - every rule below can be changed by the user (Configure button -> GET/PUT /schedule/settings, stored in the
# table schedule_settings). The values written here are only the defaults used until the user saves other values.
# --------------------------------------------------------------------------------------
ISO = "%Y-%m-%dT%H:%M:%S"
# fixed rules (NOT in the Configure dialog)
WEEKLY_OFF_DAYS = (6,)             # Python weekday(): Monday = 0 ... Sunday = 6  -> Sunday off
ALT_SATURDAYS_OFF = (1, 3)         # 1st and 3rd Saturday of the month off
DEFAULT_SHIFT_START = 8.0          # day start when neither the work centre nor shift_definition has a shift time
DEFAULT_SHIFTS = 2                 # shifts a day when neither the work centre nor shift_definition has shifts
DEFAULT_HOURS_PER_SHIFT = 7.0      # working hours of one shift (fallback)
BREAK_MINUTES = 0.0               # break per shift - taken off when the hours come from shift end - shift start
BREAK_START: Optional[float] = None   # clock time of the break (None = the break is taken at the end of the shift)
MAX_DAY_HOURS = 24.0               # longest working day
LINE_IN_ONE_DAY = True             # a line run (e.g. SMT LINE) must finish inside one working day
BATCH_NAME_KEYWORDS: Tuple[str, ...] = ("baking",)   # fixed: a process whose name contains one of these is always a batch
DEFAULT_BATCH_SIZE = 20
FALLBACK_MINUTES = 1.0
MANUAL_PARALLEL_SLOTS = 1          # a process without machine works on this many POs at the same time
HANDOFF_WARN_HOURS = 30.0          # warn when a main PO starts later than this after the child PO it needs has finished
PCB_OPEN_STATUSES = {"new", "inaction"}      # PcbData.status of a PCB that is not started (compared in lower case)
EXTRA_CHILD_LINKS: Dict[str, str] = {}      # {main_part_no: child_part_no} to force a link
OPEN_BREAKDOWN_HOURS = 24.0        # open breakdown with no ready date / downtime: machine blocked until now + this
DEFAULT_SPARE_LEAD_DAYS = 7        # inventorty_spares.procurement_lead_time empty / not a number
CONSUMABLE_RESTOCK_DAYS = 7        # consumable out of stock / expired: process blocked from now for this many days
DONE_STATUSES = {"completed", "complete", "done", "closed", "resolved"}   # fixed: statuses that count as finished
# saved plans and assignment - fixed (handled internally, NOT in the Configure dialog)
LATE_TOLERANCE_MIN = 0.0           # Planned vs Actual: finishing up to this many minutes after plan is "on time"
PLAN_NAME_PREFIX = "Production Plan"   # saved plan = <prefix>_<first day>-<last day>_REV01
PLAN_REF_PREFIX = "SCH"                # reference = SCH-<year>-<plan no>-REV-<version>
LOCK_ASSIGNED_SLOTS = True         # POs assigned from a saved plan keep their slots; later schedules work around them
VIEW_MAX_DAYS = 62                 # longest date range of the read-only Gantt (AssignPCB)

ROLES = ("CHILD", "MAIN")                   # section order of the rows

# Steps that run as ONE line, inside one working day, shown as ONE row (matched by step name, case-insensitive)
LINE_GROUPS: Dict[str, Tuple[str, ...]] = {
    "SMT LINE": (
        "SOLDER PASTE PRINTING - TOP SIDE",
        "SOLDER PASTE INSPECTION - TOP SIDE",
        "PICK N PLACE - TOP SIDE",
        "REFLOW - TOP SIDE",
    ),
}

_G_TIME = "Shifts and working hours"
_G_PROC = "Process rules"
# _G_PO = "Production orders and PCBs"
# _G_MAINT = "Breakdowns, spares and consumables"
# type: int | number | bool | time ("HH:MM", may be empty) | weekdays | month_weeks | list (strings) | line_groups | pairs | text
SETTINGS_SCHEMA: List[Dict[str, Any]] = [
    {"key": "DEFAULT_SHIFT_START", "group": _G_TIME, "type": "time", "label": "Day starts at (fallback)",
     "help": "Used only when the work centre (sap_workcenter_capacity) and shift_definition have no shift time."},
    {"key": "DEFAULT_SHIFTS", "group": _G_TIME, "type": "int", "min": 1, "max": 3, "label": "Shifts a day (fallback)",
     "help": "Used only when the work centre and shift_definition have no shifts."},
    {"key": "DEFAULT_HOURS_PER_SHIFT", "group": _G_TIME, "type": "number", "min": 0.5, "max": 24,
     "label": "Working hours per shift (fallback)", "help": "Net working hours of one shift when no table gives them."},
    {"key": "BREAK_MINUTES", "group": _G_TIME, "type": "number", "min": 0, "max": 240, "label": "Break per shift (minutes)",
     "help": "Taken off the shift when its hours come from shift end - shift start (not from operating_time)."},
    {"key": "BREAK_START", "group": _G_TIME, "type": "time", "label": "Break starts at",
     "help": "Clock time of the break (no work then). Empty = the break is taken off the end of the shift."},
    {"key": "MAX_DAY_HOURS", "group": _G_TIME, "type": "number", "min": 1, "max": 24, "label": "Longest working day (hours)"},
    {"key": "LINE_GROUPS", "group": _G_PROC, "type": "line_groups", "label": "Lines (steps that run as one line)",
     "help": "Steps of one line run one after the other as one process row. Step names must match process_flow_master."},
    {"key": "LINE_IN_ONE_DAY", "group": _G_PROC, "type": "bool", "label": "A line run must finish inside one working day"},
    {"key": "DEFAULT_BATCH_SIZE", "group": _G_PROC, "type": "int", "min": 1, "max": 10000, "label": "Batch size (fallback)",
     "help": "When part_process_time and stage_schedule_config have no batch size."},
    {"key": "MANUAL_PARALLEL_SLOTS", "group": _G_PROC, "type": "int", "min": 1, "max": 50,
     "label": "POs at the same time on a process without machine"},
    {"key": "FALLBACK_MINUTES", "group": _G_PROC, "type": "number", "min": 0, "max": 10000,
     "label": "Minutes per unit when no process time is found"},
    # {"key": "HANDOFF_WARN_HOURS", "group": _G_PROC, "type": "number", "min": 0, "max": 10000,
    #  "label": "Warn when a main PO waits longer than (hours) after its child"},
    # {"key": "PCB_OPEN_STATUSES", "group": _G_PO, "type": "list", "label": "PCB statuses that count as not started",
    #  "help": "A PO is scheduled when all its PCBs have one of these statuses (PcbData.status, any case)."},
    # {"key": "EXTRA_CHILD_LINKS", "group": _G_PO, "type": "pairs", "label": "Extra main -> child part links",
    #  "help": "Force a main part to be fed by a child part when product_type_master / PcbData.Type / BOM do not link them."},
    # {"key": "OPEN_BREAKDOWN_HOURS", "group": _G_MAINT, "type": "number", "min": 0, "max": 10000,
    #  "label": "Open breakdown with no ready date blocks the machine for (hours)"},
    # {"key": "DEFAULT_SPARE_LEAD_DAYS", "group": _G_MAINT, "type": "int", "min": 0, "max": 3650,
    #  "label": "Spare lead time when not filled (days)"},
    # {"key": "CONSUMABLE_RESTOCK_DAYS", "group": _G_MAINT, "type": "int", "min": 0, "max": 3650,
    #  "label": "Consumable out of stock / expired blocks the process for (days)"},
]
_SETTING_KEYS = {s["key"]: s for s in SETTINGS_SCHEMA}


def _hours_to_hm(h: Optional[float]) -> str:
    if h is None:
        return ""
    m = int(round(float(h) * 60))
    return f"{m // 60 % 24:02d}:{m % 60:02d}"


def _hm_to_hours(v) -> Optional[float]:
    if v is None or (isinstance(v, str) and not v.strip()):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    m = re.match(r"^\s*(\d{1,2})(?::(\d{2}))?\s*$", str(v))
    if not m or int(m.group(1)) > 23:
        raise PoGanttError(400, f"'{v}' is not a time (HH:MM)")
    return int(m.group(1)) + int(m.group(2) or 0) / 60.0


def _setting_json(key: str) -> Any:
    """Current value of one setting in the form the UI edits it."""
    v = globals()[key]
    t = _SETTING_KEYS[key]["type"]
    if t == "time":
        return _hours_to_hm(v)
    if t in ("weekdays", "month_weeks"):
        return sorted(int(x) for x in v)
    if t == "list":
        return sorted(v) if isinstance(v, (set, frozenset)) else list(v)
    if t == "line_groups":
        return [{"name": g, "steps": list(st)} for g, st in v.items()]
    if t == "pairs":
        return [{"main": m, "child": c} for m, c in v.items()]
    return v


_DEFAULT_SETTINGS = {s["key"]: _setting_json(s["key"]) for s in SETTINGS_SCHEMA}


def _setting_value(key: str, v: Any) -> Any:
    """UI value -> the Python value the scheduler uses (validated)."""
    sch = _SETTING_KEYS[key]
    t, lab = sch["type"], sch["label"]

    def rng(x):
        if "min" in sch and x < sch["min"] or "max" in sch and x > sch["max"]:
            raise PoGanttError(400, f"{lab}: {x} is outside {sch.get('min')} - {sch.get('max')}")
        return x
    try:
        if t == "int":
            return rng(int(v))
        if t == "number":
            return rng(float(v))
        if t == "bool":
            return bool(v)
        if t == "text":
            return str(v or "").strip()
        if t == "time":
            return _hm_to_hours(v)
        if t == "weekdays":
            return tuple(sorted({int(x) for x in v if 0 <= int(x) <= 6}))
        if t == "month_weeks":
            return tuple(sorted({int(x) for x in v if 1 <= int(x) <= 5}))
        if t == "list":
            vals = [str(x).strip() for x in (v or []) if str(x).strip()]
            return {x.lower() for x in vals} if key.endswith("STATUSES") else tuple(x.lower() for x in vals)
        if t == "line_groups":
            out = {}
            for g in v or []:
                name = str(g.get("name") or "").strip()
                steps = tuple(str(x).strip() for x in (g.get("steps") or []) if str(x).strip())
                if name and steps:
                    out[name] = steps
            return out
        if t == "pairs":
            return {str(x.get("main")).strip(): str(x.get("child")).strip() for x in (v or [])
                    if str(x.get("main") or "").strip() and str(x.get("child") or "").strip()}
    except PoGanttError:
        raise
    except Exception:
        raise PoGanttError(400, f"{lab}: invalid value {v!r}")
    raise PoGanttError(400, f"Unknown setting type {t}")


BLUE, ORANGE = "BLUE", "ORANGE"


class PoGanttError(Exception):
    def __init__(self, status_code: int, detail: str):
        super().__init__(detail)
        self.status_code, self.detail = status_code, detail


# --------------------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------------------
def _iso(dt: Optional[datetime]) -> Optional[str]:
    return dt.replace(microsecond=0).strftime(ISO) if dt else None


def _norm(s: Optional[str]) -> str:
    """Part / PO numbers: ignore spaces and leading zeros."""
    return (s or "").strip().lstrip("0")


def _key(s: Optional[str]) -> str:
    """Name matching: case / punctuation insensitive."""
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def _hm(h: float) -> str:
    hh = int(h)
    return f"{hh:02d}:{int(round((h - hh) * 60)):02d}"


def _chunks(seq: List[Any], n: int = 500) -> Iterable[List[Any]]:
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


_DATE_FMTS = ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%Y/%m/%d", "%d.%m.%Y", "%d-%b-%Y", "%d %b %Y", "%d-%B-%Y")
_TIME_FMTS = ("%H:%M:%S", "%H:%M", "%I:%M %p", "%I:%M:%S %p", "%I:%M%p", "%H:%M:%S.%f")


def _parse_time(v) -> Optional[time]:
    if v is None or v == "":
        return None
    if isinstance(v, time):
        return v
    s = str(v).strip()
    for f in _TIME_FMTS:
        try:
            return datetime.strptime(s, f).time()
        except ValueError:
            continue
    return None


def _parse_dt(v) -> Optional[datetime]:
    """Dates / datetimes as stored in the maintenance and log tables (ISO, dd-mm-yyyy, dd/mm/yyyy, with or without time)."""
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v if v.tzinfo is None else v.astimezone().replace(tzinfo=None)
    if isinstance(v, date):
        return datetime.combine(v, time.min)
    s = str(v).strip()
    if not s:
        return None
    try:
        dt = datetime.fromisoformat(s[:-1] if s.endswith("Z") else s)
        return dt if dt.tzinfo is None else dt.astimezone().replace(tzinfo=None)
    except ValueError:
        pass
    for df in _DATE_FMTS:
        for tf in ("",) + tuple(" " + t for t in _TIME_FMTS):
            try:
                return datetime.strptime(s, df + tf)
            except ValueError:
                continue
    return None


def _merge(intervals: Iterable[Tuple[datetime, datetime]]) -> List[Tuple[datetime, datetime]]:
    out: List[List[datetime]] = []
    for a, b in sorted(intervals):
        if out and a <= out[-1][1]:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return [(a, b) for a, b in out]


class FlowStep:
    """A routing step built from part_process_time when product_workflow_mapping has no flow for the part
    (same attributes the scheduler reads from a ProductWorkflowMapping row)."""
    def __init__(self, part: str, step, seq: int):
        self.product_part_number, self.flow_step_id, self.step_sequence = part, step.flow_step_id, seq
        self.process_detail, self.process_time_seconds, self.id = step, None, None


def _part_flows(db: Session, part_numbers, plant: Optional[str]) -> Tuple[Dict[str, list], List[str]]:
    """{part: [routing steps in order]} + the parts whose flow came from part_process_time.
      1. product_workflow_mapping (step_sequence)                                    - the flow set up in MES
      2. else part_process_time of the part (plant): steps of process_flow_master that have a step_order and an MES time
         (actual_time), in step_order. The SAP routing rows (no step_order) are left out."""
    flows: Dict[str, list] = defaultdict(list)
    parts = list(part_numbers or [])
    if not parts:
        return flows, []
    for chunk in _chunks(parts):
        for r in db.query(ProductWorkflowMapping).options(joinedload(ProductWorkflowMapping.process_detail)
                ).filter(ProductWorkflowMapping.product_part_number.in_(chunk)
                ).order_by(ProductWorkflowMapping.product_part_number, ProductWorkflowMapping.step_sequence,
                           ProductWorkflowMapping.id).all():
            flows[r.product_part_number].append(r)
    missing = [pn for pn in parts if pn not in flows]
    if missing:
        q = db.query(PartProcessTime.part_no, ProcessFlowMaster).join(
            ProcessFlowMaster, ProcessFlowMaster.flow_step_id == PartProcessTime.process_id
        ).filter(PartProcessTime.part_no.in_(missing), ProcessFlowMaster.step_order.isnot(None),
                 PartProcessTime.actual_time.isnot(None))
        if plant:
            q = q.filter(PartProcessTime.plant == plant)
        rows = sorted(q.all(), key=lambda x: (x[0], x[1].step_order, x[1].flow_step_id))
        seen = set()
        for pn, st in rows:
            if (pn, st.flow_step_id) in seen:
                continue
            seen.add((pn, st.flow_step_id))
            flows[pn].append(FlowStep(pn, st, len(flows[pn]) + 1))
    return flows, [pn for pn in missing if pn in flows]


def step_name(row) -> str:
    """Stage name of a ProductWorkflowMapping row (via its process_detail relationship -> process_flow_master)."""
    pd = row.process_detail
    return (pd.step_name if pd and pd.step_name else None) or f"Step {row.flow_step_id}"


# --------------------------------------------------------------------------------------
# Calendar with a per-station daily window + machine down-time
# --------------------------------------------------------------------------------------
class Win(NamedTuple):
    """The working window of a process on a normal working day: starts at start_h (clock hours), lasts cap_min minutes
    (the gross shift span when the break is a gap, else the net working time), with an optional break gap at brk_h."""
    start_h: float
    cap_min: float
    brk_h: Optional[float] = None
    brk_min: float = 0.0

    @property
    def net_min(self) -> float:
        return self.cap_min - (self.brk_min if self.brk_h is not None else 0.0)


class DayCalendar:
    """A working day d has, per process, a window [d start_h, + cap_min * factor) - minus its break gap, if any.
    `cap` arguments are a Win (or plain minutes: then the window starts at the calendar's default day start).
    `blocks` (sorted, merged (start, end) pairs) are times the machine is down; work never runs inside them."""

    def __init__(self, holidays: Dict[date, str], exceptions: Dict[date, str], shift_start: float):
        self.holidays = holidays
        self.exceptions = {d: (t or "").strip().lower() for d, t in exceptions.items()}
        self.shift_start = float(shift_start)

    def _w(self, cap) -> Win:
        return cap if isinstance(cap, Win) else Win(self.shift_start, float(cap))

    def factor(self, d: date) -> float:
        exc = self.exceptions.get(d)
        if exc == "working":
            return 1.0
        if exc == "half-day":
            return 0.5
        if exc == "holiday":
            return 0.0
        if d in self.holidays:
            return 0.0
        if d.weekday() in WEEKLY_OFF_DAYS:
            return 0.0
        if d.weekday() == 5 and ((d.day - 1) // 7 + 1) in ALT_SATURDAYS_OFF:
            return 0.0
        return 1.0

    def off_reason(self, d: date) -> str:
        if d in self.holidays:
            return self.holidays[d] or "Holiday"
        exc = self.exceptions.get(d)
        if exc == "holiday":
            return "Holiday"
        if exc == "half-day":
            return "Half day"
        if d.weekday() in WEEKLY_OFF_DAYS:
            return d.strftime("%A")
        if d.weekday() == 5 and ((d.day - 1) // 7 + 1) in ALT_SATURDAYS_OFF:
            n = (d.day - 1) // 7 + 1
            return f"{n}{'st' if n == 1 else 'nd' if n == 2 else 'rd' if n == 3 else 'th'} Saturday"
        return "Off"

    def spans(self, d: date, cap) -> List[Tuple[datetime, datetime]]:
        """Working stretches of day d (two when the break is a gap inside the window)."""
        w = self._w(cap)
        f = self.factor(d)
        if f <= 0 or w.cap_min <= 0:
            return []
        base = datetime.combine(d, time.min)
        ws = base + timedelta(hours=w.start_h)
        we = ws + timedelta(minutes=w.cap_min * f)
        if w.brk_h is not None and w.brk_min > 0:
            bs = base + timedelta(hours=w.brk_h)
            if bs < ws:
                bs += timedelta(days=1)                      # night shift: the break is after midnight
            be = bs + timedelta(minutes=w.brk_min)
            if bs < we and be > ws:
                return [(a, b) for a, b in ((ws, bs), (be, we)) if b > a]
        return [(ws, we)]

    def window(self, d: date, cap) -> Tuple[datetime, datetime]:
        sp = self.spans(d, cap)
        if not sp:
            ws = datetime.combine(d, time.min) + timedelta(hours=self._w(cap).start_h)
            return ws, ws
        return sp[0][0], sp[-1][1]

    def longest_stretch(self, cap) -> float:
        """Minutes of the longest working stretch of a normal day (a run that must not be split has to fit in it)."""
        w = self._w(cap)
        if w.brk_h is None or w.brk_min <= 0:
            return w.cap_min
        ref = date(2000, 1, 3)                                   # any date; factor is ignored below
        base = datetime.combine(ref, time.min)
        ws = base + timedelta(hours=w.start_h)
        we = ws + timedelta(minutes=w.cap_min)
        bs = base + timedelta(hours=w.brk_h)
        if bs < ws:
            bs += timedelta(days=1)
        be = bs + timedelta(minutes=w.brk_min)
        if not (bs < we and be > ws):
            return w.cap_min
        return max((min(we, bs) - ws).total_seconds(), (we - max(ws, be)).total_seconds(), 0) / 60.0

    def first_working_day(self, d: date) -> date:
        for _ in range(4000):
            if self.factor(d) > 0:
                return d
            d += timedelta(days=1)
        raise PoGanttError(500, "No working day found - check public_holidays / calendar_exceptions")

    def locate(self, t: datetime, cap) -> Tuple[datetime, date, datetime]:
        """Earliest moment >= t inside a working stretch, the working day it belongs to, and the end of that stretch."""
        d = t.date() - timedelta(days=1)                      # yesterday's window may spill past midnight
        for _ in range(4000):
            for a, b in self.spans(d, cap):
                if t < a:
                    return a, d, b
                if t < b:
                    return t, d, b
            d += timedelta(days=1)
        raise PoGanttError(500, "No working day found - check public_holidays / calendar_exceptions")

    def next_start(self, t: datetime, cap) -> datetime:
        return self.locate(t, cap)[0]

    def free_pieces(self, t: datetime, cap, blocks=()):
        """Contiguous free stretches (day, start, end) from t onward: inside working stretches and outside `blocks`."""
        cur, day, span_end = self.locate(t, cap)
        i, n = 0, len(blocks)
        for _ in range(500000):
            while i < n and blocks[i][1] <= cur:
                i += 1
            if i < n and blocks[i][0] <= cur:                    # machine down right now -> jump past it
                cur, day, span_end = self.locate(blocks[i][1], cap)
                continue
            end = span_end if i >= n else min(span_end, blocks[i][0])
            if end > cur:
                yield day, cur, end
            cur, day, span_end = self.locate(end, cap)
        raise PoGanttError(500, "Could not place a run inside the working calendar")

    def consume(self, start: datetime, minutes: float, cap, blocks=()):
        """Run `minutes` of work from `start`, only inside working stretches and outside down-time.
        Returns (real_start, end, end_day, [(day, seg_start, seg_end, minutes), ...])."""
        if minutes <= 0:
            cur, day, _ = self.locate(start, cap)
            return cur, cur, day, []
        rem, segs, first = float(minutes), [], None
        for day, a, b in self.free_pieces(start, cap, blocks):
            if first is None:
                first = a
            use = min(rem, (b - a).total_seconds() / 60.0)
            e = a + timedelta(minutes=use)
            segs.append((day, a, e, use))
            rem -= use
            if rem <= 1e-9:
                return first, e, day, segs
        raise PoGanttError(500, "Could not place a run inside the working calendar")

    def place_within_day(self, start: datetime, minutes: float, cap, blocks=()):
        """The whole run must sit in ONE free stretch of ONE working day. If it does not fit in what is left, it moves
        to the next stretch that can hold it. A run longer than the longest stretch of a day has to spill over.
        Returns consume(...) + (fits_in_one_day,)."""
        if minutes <= self.longest_stretch(cap) + 1e-9:
            for k, (day, a, b) in enumerate(self.free_pieces(start, cap, blocks)):
                if (b - a).total_seconds() / 60.0 + 1e-9 >= minutes:
                    e = a + timedelta(minutes=minutes)
                    return a, e, day, [(day, a, e, minutes)], True
                if k > 20000:
                    break
        # longer than one working stretch: start at the beginning of a day, so it is spread over as few days as possible
        for day, a, b in self.free_pieces(start, cap, blocks):
            if a == self.window(day, cap)[0]:
                start = a
                break
        return self.consume(start, minutes, cap, blocks) + (False,)


# --------------------------------------------------------------------------------------
# Station container
# --------------------------------------------------------------------------------------
class Station:
    def __init__(self, key: str, name: str, kind: str, step_ids: List[int]):
        self.key, self.name, self.kind, self.step_ids = key, name, kind, list(step_ids)   # kind: STEP | LINE
        self.steps: List[str] = []                       # member step names (LINE only)
        self.options: List[Dict[str, Any]] = []          # ways to run it: {name, resources, phys, blocks}
        self.real_machines: List[Tuple[str, str]] = []   # every physical machine of the process: (machine_id, step name)
        self.shifts, self.hps, self.cap_min = DEFAULT_SHIFTS, DEFAULT_HOURS_PER_SHIFT, 0.0
        self.mode, self.batch_size = "SERIES", DEFAULT_BATCH_SIZE
        self.setup = self.cooldown = 0.0
        self.cd_working_only = self.next_day_release = False
        self.operators = 0
        self.material: List[Dict[str, Any]] = []        # consumable shortages of its steps
        self.workcenter: Optional[str] = None
        self.wc_name: Optional[str] = None

    @property
    def machines(self) -> List[str]:
        return [o["name"] for o in self.options if o["name"]]


# --------------------------------------------------------------------------------------
# Loaders
# --------------------------------------------------------------------------------------
# def _load_candidates(db: Session, plant: Optional[str], warnings: List[str]) -> Dict[str, Dict[str, Any]]:
#     """POs come ONLY from PcbData. Plant filter: the PO's part number must belong to that plant in
#     product_type_master (PcbData.plant is only used for parts missing from the master).
#     A PO is loadable when EVERY one of its PCBs has a status in PCB_OPEN_STATUSES (New / Assigned).
#     PcbData.status stays 'Assigned' after the PCB is finished (the assign step is the only place that changes it), so a
#     PO whose PCBs are ALL finished in pcb_assignment (current_step_id empty or overall_status done) is left out -
#     otherwise every PO ever made would be scheduled again."""
#     finished = set()
#     for (pid,) in db.query(PCBAssignment.assigned_pcb_id).filter(or_(
#             PCBAssignment.current_step_id.is_(None),
#             func.lower(func.coalesce(PCBAssignment.overall_status, "")).in_(list(DONE_STATUSES)))).all():
#         finished.add(pid)
#     plant_parts, known_parts = set(), set()
#     if plant:
#         for pn, pc in db.query(ProductTypeMaster.part_number, ProductTypeMaster.plant_code).all():
#             known_parts.add(_norm(pn))
#             if pc == plant:
#                 plant_parts.add(_norm(pn))
#     q = db.query(PcbData.productionOrder, PcbData.partNumber, PcbData.quantity, PcbData.status, PcbData.createdAt,
#                  PcbData.plant, PcbData.serialNo, PcbData.PCBserialNoPartNumber, PcbData.Type
#                  ).filter(PcbData.productionOrder.isnot(None), PcbData.productionOrder != "")
#     by_po: Dict[str, list] = defaultdict(list)
#     for r in q.all():
#         if plant:
#             n = _norm(r[1])
#             if not (n in plant_parts or (n not in known_parts and (r[5] or "").strip() == plant)):
#                 continue
#         by_po[_norm(r[0])].append(r)

#     cands: Dict[str, Dict[str, Any]] = {}
#     for po, rows in by_po.items():
#         if all(r[7] in finished for r in rows):              # every PCB finished -> history, not scheduled
#             continue
#         parts = [r[1] for r in rows if r[1]]
#         if not parts:
#             warnings.append(f"PO {po}: PCBs have no part number - ignored")
#             continue
#         part = max(set(parts), key=parts.count)
#         if len(set(parts)) > 1:
#             warnings.append(f"PO {po}: PCBs carry several part numbers ({', '.join(sorted(set(parts)))}) - {part} used")
#         created = [r[4] for r in rows if r[4]]
#         cands[po] = {
#             "po": po, "part": part,
#             "qty": sum(r[2] if (r[2] and r[2] > 0) else 1 for r in rows),
#             "created": min(created) if created else None,
#             "started": any((r[3] or "").strip().lower() not in PCB_OPEN_STATUSES for r in rows),
#             # every PCB of the PO: serial number (links child <-> main), PCB id (pcb_assignment), Type, status
#             "pcbs": [{"sn": r[6], "serial": (r[6] or "").strip().upper(), "pcb_id": r[7], "part": r[1],
#                       "type": (r[8] or "").strip().upper(), "status": (r[3] or "").strip().lower()} for r in rows],
#         }
#     return cands


def _load_candidates(db: Session, plant: Optional[str], warnings: List[str]) -> Dict[str, Dict[str, Any]]:
    """POs come ONLY from PcbData. Plant filter: the PO's part number must belong to that plant in
    product_type_master (PcbData.plant is only used for parts missing from the master).
    A PO is loadable when EVERY one of its PCBs has a status in PCB_OPEN_STATUSES (New / Assigned).
    Already assigned or locked POs are strictly excluded."""
    
    # 1. Fetch actively locked or assigned POs to exclude them
    excluded_pos = set()
    try:
        # Check active slot locks
        for (po_val,) in db.query(SchedulePoLock.production_order).filter(SchedulePoLock.released_at.is_(None)).all():
            if po_val:
                excluded_pos.add(_norm(po_val))
        
        # Check active PCB assignments where the PO is in progress
        assigned_po_rows = db.query(PcbData.productionOrder).join(
            PCBAssignment, PCBAssignment.assigned_pcb_id == PcbData.PCBserialNoPartNumber
        ).filter(
            PCBAssignment.overall_status != "COMPLETED",
            PcbData.productionOrder.isnot(None),
            PcbData.productionOrder != ""
        ).distinct().all()
        for (po_val,) in assigned_po_rows:
            if po_val:
                excluded_pos.add(_norm(po_val))
    except Exception:
        db.rollback()

    finished = set()
    for (pid,) in db.query(PCBAssignment.assigned_pcb_id).filter(or_(
            PCBAssignment.current_step_id.is_(None),
            func.lower(func.coalesce(PCBAssignment.overall_status, "")).in_(list(DONE_STATUSES)))).all():
        finished.add(pid)
        
    plant_parts, known_parts = set(), set()
    if plant:
        for pn, pc in db.query(ProductTypeMaster.part_number, ProductTypeMaster.plant_code).all():
            known_parts.add(_norm(pn))
            if pc == plant:
                plant_parts.add(_norm(pn))
                
    q = db.query(PcbData.productionOrder, PcbData.partNumber, PcbData.quantity, PcbData.status, PcbData.createdAt,
                 PcbData.plant, PcbData.serialNo, PcbData.PCBserialNoPartNumber, PcbData.Type
                 ).filter(PcbData.productionOrder.isnot(None), PcbData.productionOrder != "")
    by_po: Dict[str, list] = defaultdict(list)
    for r in q.all():
        po_norm = _norm(r[0])
        # Skip if already assigned or locked
        if po_norm in excluded_pos:
            continue
            
        if plant:
            n = _norm(r[1])
            if not (n in plant_parts or (n not in known_parts and (r[5] or "").strip() == plant)):
                continue
        by_po[po_norm].append(r)

    cands: Dict[str, Dict[str, Any]] = {}
    for po, rows in by_po.items():
        if all(r[7] in finished for r in rows):              # every PCB finished -> history, not scheduled
            continue
        parts = [r[1] for r in rows if r[1]]
        if not parts:
            warnings.append(f"PO {po}: PCBs have no part number - ignored")
            continue
        part = max(set(parts), key=parts.count)
        if len(set(parts)) > 1:
            warnings.append(f"PO {po}: PCBs carry several part numbers ({', '.join(sorted(set(parts)))}) - {part} used")
        created = [r[4] for r in rows if r[4]]
        cands[po] = {
            "po": po, "part": part,
            "qty": sum(r[2] if (r[2] and r[2] > 0) else 1 for r in rows),
            "created": min(created) if created else None,
            "started": any((r[3] or "").strip().lower() not in PCB_OPEN_STATUSES for r in rows),
            "pcbs": [{"sn": r[6], "serial": (r[6] or "").strip().upper(), "pcb_id": r[7], "part": r[1],
                      "type": (r[8] or "").strip().upper(), "status": (r[3] or "").strip().lower()} for r in rows],
        }
    return cands


def _serial_links(db: Session, cands: Dict[str, Dict[str, Any]], role_of, child_of: Dict[str, str], main_pos: List[str]):
    """Child -> main link by SERIAL NUMBER (same rule as the assign step, can_proceed in Data_Server):
    the main PCB with serialNo S needs the child PCB with the same serialNo S.
    Only for `main_pos` (the main POs being scheduled); their child PCBs are looked up in PcbData by serial number, so a
    child PO that is already finished (and so not a candidate) is still found.
    Returns
      links {main_po: [{child_po, child_part, pcbs, done, in_progress, not_assigned, steps}]}
      unmatched {main_po: number of main PCBs with no child PCB of the same serial}
    State of a child PCB (pcb_assignment.assigned_pcb_id = PCBserialNoPartNumber):
      no assignment row                     -> not assigned
      current_step_id empty / status done   -> done (child flow finished)
      current_step_id filled                -> in process (at that step)"""
    def is_main(pcb) -> bool:
        return pcb["type"].endswith("MAIN") or role_of(pcb["part"]) == "MAIN"

    mains = [po for po in main_pos if po in cands and role_of(cands[po]["part"]) == "MAIN"]
    serials = sorted({pcb["sn"].strip() for po in mains for pcb in cands[po]["pcbs"] if pcb["sn"] and pcb["sn"].strip()})
    child_by_serial: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for chunk in _chunks(serials):
        for sn, pid, part, po, typ, status in db.query(
                PcbData.serialNo, PcbData.PCBserialNoPartNumber, PcbData.partNumber, PcbData.productionOrder,
                PcbData.Type, PcbData.status).filter(PcbData.serialNo.in_(chunk)).all():
            typ = (typ or "").strip().upper()
            if po and (typ.endswith("CHILD") or role_of(part) == "CHILD"):
                child_by_serial[(sn or "").strip().upper()].append(
                    {"po": _norm(po), "pcb_id": pid, "part": part, "status": (status or "").strip().lower()})

    ids = [ch["pcb_id"] for lst in child_by_serial.values() for ch in lst if ch["pcb_id"]]
    state: Dict[str, Tuple[Optional[int], str]] = {}
    for chunk in _chunks(ids):
        for a in db.query(PCBAssignment).filter(PCBAssignment.assigned_pcb_id.in_(chunk)).all():
            state[a.assigned_pcb_id] = (a.current_step_id, (a.overall_status or "").strip().lower())

    links: Dict[str, List[Dict[str, Any]]] = {}
    unmatched: Dict[str, int] = {}
    for po in mains:
        c = cands[po]
        per_child: Dict[str, Dict[str, Any]] = {}
        missing = 0
        for pcb in c["pcbs"]:
            if not is_main(pcb):
                continue
            hits = [ch for ch in child_by_serial.get(pcb["serial"], []) if ch["part"] != c["part"]]
            want = child_of.get(c["part"])
            hits = [h for h in hits if h["part"] == want] or hits          # prefer the child part of its family
            if not hits:
                missing += 1
                continue
            ch = hits[0]
            l = per_child.setdefault(ch["po"], {"child_po": ch["po"], "child_part": ch["part"], "pcbs": 0, "done": 0,
                                                "in_progress": 0, "not_assigned": 0, "steps": []})
            l["pcbs"] += 1
            st = state.get(ch["pcb_id"])
            if ch["status"] in DONE_STATUSES or (st and (st[0] is None or st[1] in DONE_STATUSES)):
                l["done"] += 1
            elif st:
                l["in_progress"] += 1
                if st[0] not in l["steps"]:
                    l["steps"].append(st[0])
            else:
                l["not_assigned"] += 1
        if per_child:
            links[po] = list(per_child.values())
            unmatched[po] = missing
    return links, unmatched


def _product_links(db: Session, warnings: Optional[List[str]] = None):
    """Returns (products, child_of {main_pn: child_pn}, role_of(pn) -> 'CHILD' | 'MAIN').
    1. product_type_master: CHILD and MAIN rows with the same product_type_name (and plant) belong together.
    2. bom_items fallback: the child P/N appears as a material of the main P/N (leading zeros ignored).
    3. EXTRA_CHILD_LINKS override."""
    products = {p.part_number: p for p in db.query(ProductTypeMaster).all()}
    # PcbData.Type ("OCTA-CHILD", "HEXA-MAIN") - used when product_type_master does not know the part
    type_of: Dict[str, Tuple[str, str]] = {}
    for pn, typ in db.query(PcbData.partNumber, PcbData.Type).filter(PcbData.Type.isnot(None)).distinct().all():
        typ = (typ or "").strip().upper()
        if pn and "-" in typ and typ.rsplit("-", 1)[1] in ROLES and pn not in type_of:
            fam, role = typ.rsplit("-", 1)
            type_of[pn] = (fam, role)
    part_by_norm = {_norm(pn): pn for pn in list(products) + list(type_of)}

    def sub(pn: str) -> str:
        p = products.get(pn)
        s = (p.sub_product_type_name or "").strip().upper() if p else ""
        return s if s in ROLES else (type_of[pn][1] if pn in type_of else s)

    child_of: Dict[str, str] = {}
    families: Dict[tuple, Dict[str, List[str]]] = defaultdict(lambda: {"CHILD": [], "MAIN": []})
    for pn, p in products.items():
        s = sub(pn)
        if s in ROLES and _key(p.product_type_name):
            families[(_key(p.product_type_name), p.plant_code)][s].append(pn)
    for (fam, _plant), g in sorted(families.items(), key=lambda kv: (kv[0][0], str(kv[0][1]))):
        childs = sorted(g["CHILD"])
        for m in g["MAIN"]:
            if childs:
                child_of[m] = childs[0]
                if len(childs) > 1 and warnings is not None:
                    warnings.append(f"Family {fam.upper()}: several child parts ({', '.join(childs)}) - "
                                    f"{childs[0]} used to feed {m}")

    # parts only in PcbData: a MAIN part is fed by the CHILD part of the same Type family (OCTA-CHILD -> OCTA-MAIN)
    fam_parts: Dict[str, Dict[str, List[str]]] = defaultdict(lambda: {"CHILD": [], "MAIN": []})
    for pn, (fam, role) in type_of.items():
        if pn not in products:
            fam_parts[fam][role].append(pn)
    for fam, g in fam_parts.items():
        childs = sorted(g["CHILD"])
        for m in g["MAIN"]:
            if childs and m not in child_of:
                child_of[m] = childs[0]

    known_pns = sorted(set(part_by_norm) | set(part_by_norm.values()))
    bom_rows = []
    for chunk in _chunks(known_pns):
        bom_rows += db.query(BOMItem.product_part_number, BOMItem.material).filter(BOMItem.material.in_(chunk)).all()
    for main_pn, material in bom_rows:
        m = part_by_norm.get(_norm(main_pn)) or main_pn
        c = part_by_norm.get(_norm(material))
        if c and m and c != m and m not in child_of and sub(m) != "CHILD" and sub(c) != "MAIN":
            child_of[m] = c
    for m, c in EXTRA_CHILD_LINKS.items():
        m, c = part_by_norm.get(_norm(m)), part_by_norm.get(_norm(c))
        if m and c:
            child_of[m] = c
    for m, c in list(child_of.items()):
        if child_of.get(c) == m:
            del child_of[m]
    child_parts = set(child_of.values())

    def role_of(pn: Optional[str]) -> str:
        s = sub(pn or "")
        if s in ROLES:
            return s
        return "CHILD" if pn in child_parts else "MAIN"

    return products, child_of, role_of


# def _load_downtime(db: Session, machines: Dict[str, Dict[str, Any]], not_before: datetime, now: datetime,
#                    warnings: List[str]) -> Dict[str, List[Dict[str, Any]]]:
#     """Down-time events per machine_id from machine_breakdown_logs and maintenance_schedules.
#     `machines` = {machine_id: {"name", "eqpt_no", ...}} of the plant. Only events ending after `not_before` are kept."""
#     by_id = {_key(mid): mid for mid in machines}
#     names: Dict[str, List[str]] = defaultdict(list)
#     for mid, info in machines.items():
#         for n in {_key(info.get("name")), _key(info.get("eqpt_no"))} - {""}:
#             if mid not in names[n]:
#                 names[n].append(mid)

#     def match(rec_id, rec_name) -> Optional[str]:
#         mid = by_id.get(_key(rec_id))
#         if mid:
#             return mid
#         for k in (_key(rec_id), _key(rec_name)):
#             if k and len(names.get(k, [])) == 1:          # only an unambiguous name
#                 return names[k][0]
#         return None

#     out: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
#     assumed = 0
#     try:
#         breakdowns = db.query(MachineBreakdownLog).all()
#     except Exception as exc:                                 # table missing -> schedule without it
#         db.rollback()
#         warnings.append(f"machine_breakdown_logs could not be read ({exc.__class__.__name__}) - breakdowns ignored")
#         breakdowns = []
#     for b in breakdowns:
#         mid = match(b.machine_id, b.machine_name)
#         if not mid:
#             continue
#         st = _parse_dt(b.breakdown_date)
#         if not st:
#             continue
#         tt = _parse_time(b.breakdown_time)
#         if tt and st.time() == time.min:
#             st = datetime.combine(st.date(), tt)
#         is_open = (b.status or "").strip().lower() not in DONE_STATUSES
#         en, note = _parse_dt(b.mc_ready_date), None
#         if not en and b.downtime_hours and b.downtime_hours > 0:
#             en = st + timedelta(hours=float(b.downtime_hours))
#         if not en and is_open:
#             en = max(now, st) + timedelta(hours=OPEN_BREAKDOWN_HOURS)
#             note = f"still open - assumed down until {_iso(en)}"
#             assumed += 1
#         if not en or en <= st or en <= not_before:
#             continue
#         out[mid].append({"machine": mid, "kind": "BREAKDOWN", "label": b.event_type or "Breakdown",
#                          "status": b.status, "start": st, "end": en,
#                          "note": note or (b.issue_description or "")})

#     try:
#         pms = db.query(MaintenanceScheduleLog).all()
#     except Exception as exc:
#         db.rollback()
#         warnings.append(f"maintenance_schedules could not be read ({exc.__class__.__name__}) - maintenance ignored")
#         pms = []
#     for m in pms:
#         mid = match(m.machine_id, m.machine_name)
#         if not mid:
#             continue
#         for q in (1, 2, 3, 4):
#             status = (getattr(m, f"q{q}_status") or "").strip().lower()
#             if status in DONE_STATUSES:
#                 continue
#             d = _parse_dt(getattr(m, f"q{q}_actual_date")) or _parse_dt(getattr(m, f"q{q}_planned_date"))
#             if not d:
#                 continue
#             st = datetime.combine(d.date(), time.min)
#             en = st + timedelta(days=1)
#             if en <= not_before:
#                 continue
#             out[mid].append({"machine": mid, "kind": "PM", "label": m.event_type or "Preventive Maintenance",
#                              "status": getattr(m, f"q{q}_status"), "start": st, "end": en,
#                              "note": f"Q{q} maintenance" + (f" - {m.remarks}" if m.remarks else "")})
#     if assumed:
#         warnings.append(f"{assumed} open breakdown(s) without ready date / downtime - machine assumed down for "
#                         f"{OPEN_BREAKDOWN_HOURS:g} h from now")
#     for mid in out:
#         out[mid].sort(key=lambda e: e["start"])
#     return out

def _load_downtime(db: Session, machines: Dict[str, Dict[str, Any]], not_before: datetime, now: datetime,
                   warnings: List[str]) -> Dict[str, List[Dict[str, Any]]]:
    by_id = {_key(mid): mid for mid in machines}
    names: Dict[str, List[str]] = defaultdict(list)
    for mid, info in machines.items():
        for n in {_key(info.get("name")), _key(info.get("eqpt_no"))} - {""}:
            if mid not in names[n]:
                names[n].append(mid)

    def match(rec_id, rec_name) -> Optional[str]:
        mid = by_id.get(_key(rec_id))
        if mid: return mid
        for k in (_key(rec_id), _key(rec_name)):
            if k and len(names.get(k, [])) == 1: return names[k][0]
        return None

    out: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

    # 1. Spares (inventorty_spares): a spare only matters when its machine is DOWN. If the spare is out of stock, an open
    #    breakdown of that machine lasts at least the procurement lead time (the repair waits for the spare).
    #    A running machine is NOT blocked because a spare is missing - that is only a risk (warning).
    try:
        spares = db.query(InventorySpares).all()
    except Exception:
        db.rollback()
        spares = []
    spare_out: Dict[str, Tuple[int, str]] = {}           # machine_id -> (lead days, spare text)
    low_spares: List[str] = []
    for sp in spares:
        q, th = _num(sp.qty_avl), _num(sp.threshold_qty)
        if q is None:                                    # no stock figure -> nothing to check
            continue
        if sp.eqpt_no:
            mids = [match(sp.eqpt_no, None)]
        else:                                            # spare of a process: every machine of that process
            mids = [m for m, info in machines.items() if sp.flow_step_id in info.get("stage_ids", [])]
        mids = [m for m in mids if m]
        text = sp.decription or sp.part_number or "spare"
        if q <= 0:
            days = _lead_days(sp.procurement_lead_time)
            for m in mids:
                if days >= spare_out.get(m, (0, ""))[0]:
                    spare_out[m] = (days, text)
        elif th is not None and q < th:
            low_spares.append(f"{text} ({', '.join(mids) or sp.eqpt_no or 'no machine'}: {q:g} left, threshold {th:g})")

    # 2. Machine Breakdowns
    try:
        breakdowns = db.query(MachineBreakdownLog).all()
    except Exception:
        db.rollback()
        breakdowns = []
    waiting_spare = set()
    for b in breakdowns:
        mid = match(b.machine_id, b.machine_name)
        if not mid: continue
        st = _parse_dt(b.breakdown_date)
        if not st: continue
        tt = _parse_time(b.breakdown_time)
        if tt and st.time() == time.min: st = datetime.combine(st.date(), tt)
        is_open = (b.status or "").strip().lower() not in DONE_STATUSES
        en, note = _parse_dt(b.mc_ready_date), None
        if not en and b.downtime_hours and b.downtime_hours > 0:
            en = st + timedelta(hours=float(b.downtime_hours))
        if not en and is_open:
            en = max(now, st) + timedelta(hours=OPEN_BREAKDOWN_HOURS)
            note = f"still open - assumed down until {_iso(en)}"
            if mid in spare_out:                         # the repair needs a spare that is not in stock
                days, text = spare_out[mid]
                en = max(en, max(now, st) + timedelta(days=days))
                note = f"waiting for spare '{text}' (out of stock, lead time {days} day(s)) - down until {_iso(en)}"
                waiting_spare.add(mid)
        if not en or en <= st or en <= not_before: continue
        out[mid].append({"machine": mid, "kind": "BREAKDOWN", "label": b.event_type or "Breakdown",
                         "status": b.status, "start": st, "end": en, "note": note or (b.issue_description or "")})
    if waiting_spare:
        warnings.append("Breakdown repair waits for an out-of-stock spare (lead time used): "
                        + ", ".join(f"{m} - {spare_out[m][1]} ({spare_out[m][0]} d)" for m in sorted(waiting_spare)))
    risk = sorted(m for m in spare_out if m not in waiting_spare)
    if risk:
        warnings.append("Spare out of stock (machine still running - a breakdown there would take the lead time): "
                        + ", ".join(f"{m} - {spare_out[m][1]} ({spare_out[m][0]} d)" for m in risk))
    if low_spares:
        warnings.append("Spares at or below threshold: " + "; ".join(low_spares))

    # 3. Maintenance Schedules
    try:
        pms = db.query(MaintenanceScheduleLog).all()
    except Exception:
        db.rollback()
        pms = []
    for m in pms:
        mid = match(m.machine_id, m.machine_name)
        if not mid: continue
        for q in (1, 2, 3, 4):
            if (getattr(m, f"q{q}_status") or "").strip().lower() in DONE_STATUSES: continue
            d = _parse_dt(getattr(m, f"q{q}_actual_date")) or _parse_dt(getattr(m, f"q{q}_planned_date"))
            if not d: continue
            st = datetime.combine(d.date(), time.min)
            en = st + timedelta(days=1)
            if en <= not_before: continue
            out[mid].append({"machine": mid, "kind": "PM", "label": m.event_type or "Preventive Maintenance",
                             "status": getattr(m, f"q{q}_status"), "start": st, "end": en,
                             "note": f"Q{q} maintenance" + (f" - {m.remarks}" if m.remarks else "")})

    for mid in out:
        out[mid].sort(key=lambda e: e["start"])
    return out

def _num(v) -> Optional[float]:
    """'12', '12.5', ' 12 nos' -> number; empty / text -> None."""
    m = re.search(r"-?\d+(\.\d+)?", str(v)) if v is not None else None
    return float(m.group()) if m else None


def _lead_days(v) -> int:
    """procurement_lead_time: '10', '10 days', '2 weeks' -> days."""
    n = _num(v)
    if n is None or n <= 0:
        return DEFAULT_SPARE_LEAD_DAYS
    return int(math.ceil(n * 7)) if "week" in str(v).lower() else int(math.ceil(n))


def _load_consumable_blocks(db: Session, now: datetime, not_before: datetime,
                            warnings: List[str]) -> Dict[int, List[Dict[str, Any]]]:
    """Consumables (consumables table) of every process (stage_id = flow_step_id).
    A consumable (material number) is usable when one of its rows has quantity > 0 (empty quantity = not counted, taken
    as available) and is not past consumable_shelf_life. The PROCESS cannot run (all its machines, and a process without
    a machine too) while one of its consumables is not usable:
        out of stock / already expired -> blocked from now for CONSUMABLE_RESTOCK_DAYS
        every batch in stock expires   -> blocked from the day after the last expiry for CONSUMABLE_RESTOCK_DAYS
    The table has no use per PCB, so stock is checked as available yes / no, it is not used up PCB by PCB."""
    try:
        rows = db.query(Consumables).all()
    except Exception:
        db.rollback()
        return {}
    groups: Dict[Tuple[int, str], list] = defaultdict(list)
    for c in rows:
        if c.stage_id is not None:
            groups[(c.stage_id, _key(c.consumable_material_number) or _key(c.consumable_material_name))].append(c)
    today = now.date()

    def expiry(c) -> Optional[date]:
        d = c.consumable_shelf_life
        return d.date() if isinstance(d, datetime) else d

    out: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
    low: List[str] = []
    for (sid, _), lst in groups.items():
        first = lst[0]
        name = first.consumable_material_name or first.consumable_material_number or "consumable"
        mat = first.consumable_material_number or ""
        in_stock = [c for c in lst if c.quantity is None or c.quantity > 0]
        usable = [c for c in in_stock if not expiry(c) or expiry(c) >= today]
        ev = None
        if not usable:
            why = "out of stock" if not in_stock else f"expired on {max(expiry(c) for c in in_stock):%d-%m-%Y}"
            ev = {"label": "Consumable " + ("out of stock" if not in_stock else "expired"), "start": now,
                  "end": now + timedelta(days=CONSUMABLE_RESTOCK_DAYS),
                  "note": f"{name} {mat} {why} - assumed back in {CONSUMABLE_RESTOCK_DAYS} day(s)"}
        elif all(expiry(c) for c in usable):
            last = max(expiry(c) for c in usable)
            st = datetime.combine(last + timedelta(days=1), time.min)
            ev = {"label": "Consumable expires", "start": st, "end": st + timedelta(days=CONSUMABLE_RESTOCK_DAYS),
                  "note": f"{name} {mat}: the stock expires on {last:%d-%m-%Y} - assumed back in {CONSUMABLE_RESTOCK_DAYS} day(s)"}
        if ev and ev["end"] > not_before:
            out[sid].append({"machine": None, "kind": "SHORTAGE", "status": "Awaiting stock", "stage_id": sid,
                             "material": mat, "material_name": name, **ev})
        qty = [c.quantity for c in usable if c.quantity is not None]
        th = max((x for x in (_num(c.threshold_qty) for c in lst) if x is not None), default=None)
        if usable and qty and th is not None and sum(qty) <= th:
            low.append(f"{name} (step {sid}: {sum(qty)} left, threshold {th:g})")
    if low:
        warnings.append("Consumables at or below threshold: " + "; ".join(low))
    return out


def _send(result: Dict[str, Any], request: Request, drop_for_page: bool = False) -> Response:
    """Fast JSON for big schedules: no jsonable_encoder walk (the result is already plain JSON), no spaces, and gzip when
    the browser accepts it (1.2 MB -> ~0.1 MB). drop_for_page: leave out what the page does not use
    (rows' cells / po_runs and the flat runs list - Save plan / Excel build the schedule again on the server)."""
    if drop_for_page:
        result = {**result, "runs": None, "bookings": None,
                  "stations": [{k: v for k, v in s.items() if k not in ("cells", "po_runs")} for s in result["stations"]]}
    body = json.dumps(result, separators=(",", ":"), default=str).encode()
    if len(body) > 20000 and "gzip" in (request.headers.get("accept-encoding") or ""):
        return Response(gzip.compress(body, 5), media_type="application/json",
                        headers={"Content-Encoding": "gzip", "Vary": "Accept-Encoding"})
    return Response(body, media_type="application/json")


def _win_from_span(start_h: float, span_min: float, shifts: int) -> Win:
    """A shift span (end - start) -> working window: the break (BREAK_MINUTES per shift) is a gap at BREAK_START when that
    is set and inside the span, else it is taken off the end."""
    one = max(float(BREAK_MINUTES or 0), 0.0)
    brk = one * max(shifts, 1)
    span_min = min(span_min, MAX_DAY_HOURS * 60.0)
    if BREAK_START is not None and one > 0:
        off = ((BREAK_START - start_h) % 24) * 60.0
        rest = brk - one                                   # breaks of the other shifts come off the end of the day
        if off < span_min - rest:
            return Win(start_h, max(span_min - rest, 0.0), BREAK_START, min(one, span_min - rest - off))
    return Win(start_h, max(span_min - brk, 0.0))


def _default_win(db: Session) -> Tuple[Win, str, int]:
    """Working window of a process that has no work centre capacity: the active shifts of shift_definition
    (first start -> last end, minus the break of every shift), else the fallback settings."""
    try:
        rows = db.query(ShiftDefinition).filter(ShiftDefinition.is_active.is_(True)).order_by(
            ShiftDefinition.sort_order, ShiftDefinition.id).all()
    except Exception:
        db.rollback()
        rows = []
    spans = []
    for r in rows:
        try:
            a, b = _hm_to_hours(r.start_time), _hm_to_hours(r.end_time)
        except PoGanttError:
            continue
        if a is None or b is None:
            continue
        spans.append((a, (b - a if b > a else b + 24 - a)))
    if spans:
        first = spans[0][0]
        last_end = max(((a - first) % 24) + ln for a, ln in spans)     # the day runs from the first start to the last end
        w = _win_from_span(first, last_end * 60.0, len(spans))
        gaps = last_end - sum(ln for _, ln in spans)
        if gaps > 0.01:                                               # time between shifts is not working time
            w = Win(w.start_h, max(w.cap_min - gaps * 60.0, 0.0), w.brk_h, w.brk_min)
        return w, f"shift_definition ({len(spans)} active shift{'s' if len(spans) > 1 else ''})", len(spans)
    return (Win(DEFAULT_SHIFT_START, DEFAULT_SHIFTS * DEFAULT_HOURS_PER_SHIFT * 60.0),
            f"settings: {DEFAULT_SHIFTS} shift(s) x {DEFAULT_HOURS_PER_SHIFT:g} h from {_hours_to_hm(DEFAULT_SHIFT_START)}",
            DEFAULT_SHIFTS)


def _load_workcenters(db: Session, plant: Optional[str], warnings: List[str]):
    """Capacity of every process from SAP (sap_workcenter_capacity), found through its work centre:
        process_flow_master.workcenter_code  ->  else product_plant_workcenter_routing (plant + flow_step_id)
    Per work centre (plant_code + workcenter_code):
        machines = number_of_individuals (Aznor) of its machine rows (capacity_category 001; labour rows 002 if no 001)
        day      = starts at shift_start_time (else the fallback day start);
                   hours = operating_time (Einzh, net hours a day) if filled,
                   else shift_end_time - shift_start_time - the break (BREAK_MINUTES; a gap at BREAK_START if set)
    Returns ({flow_step_id: workcenter_code}, {workcenter_code: {...}})."""
    wc_of_step: Dict[int, str] = {}
    wc_col = getattr(ProcessFlowMaster, "workcenter_code", None) or getattr(ProcessFlowMaster, "work_centre", None)
    if wc_col is not None:
        for sid, wc in db.query(ProcessFlowMaster.flow_step_id, wc_col).all():
            wc = (wc or "").strip()
            if wc:
                wc_of_step[sid] = wc
    try:
        q = db.query(ProductPlantWorkCenterRouting.flow_step_id, ProductPlantWorkCenterRouting.workcenter_code)
        if plant:
            q = q.filter(ProductPlantWorkCenterRouting.plant_code == plant)
        for sid, wc in q.all():
            if sid is not None and wc and sid not in wc_of_step:
                wc_of_step[sid] = wc.strip()
    except Exception:
        db.rollback()

    caps: Dict[str, Dict[str, Any]] = {}
    try:
        q = db.query(WorkcenterCapacity)
        if plant:
            q = q.filter(WorkcenterCapacity.plant_code == plant)
        rows = q.all()
    except Exception as exc:
        db.rollback()
        warnings.append(f"sap_workcenter_capacity could not be read ({exc.__class__.__name__}) - default 2 shifts, machines "
                        f"from equipment_details")
        rows = []
    by_wc: Dict[str, list] = defaultdict(list)
    for r in rows:
        by_wc[(r.workcenter_code or "").strip()].append(r)
    for wc, lst in by_wc.items():
        mach = [r for r in lst if (r.capacity_category or "").strip() == "001"]
        use = mach or lst
        n = sum(int(r.number_of_individuals or 0) for r in use)
        best: Optional[Win] = None
        src = None
        for r in use:
            st_h = (r.shift_start_time.hour + r.shift_start_time.minute / 60.0) if r.shift_start_time else None
            w, why = None, None
            if float(r.operating_time or 0) > 0:
                w = Win(st_h if st_h is not None else DEFAULT_SHIFT_START, float(r.operating_time) * 60.0)
                why = f"operating_time {float(r.operating_time):g} h"
            elif r.shift_start_time and r.shift_end_time:
                b_ = r.shift_end_time.hour + r.shift_end_time.minute / 60.0
                span = (b_ - st_h if b_ > st_h else b_ + 24 - st_h) * 60.0
                w = _win_from_span(st_h, span, 1)
                why = (f"shift {_hours_to_hm(st_h)}-{_hours_to_hm(b_)} minus {BREAK_MINUTES:g} min break")
            if w and (best is None or w.net_min > best.net_min):
                best, src = w, why
        first = use[0]
        caps[wc] = {"workcenter": wc, "name": first.name or first.capacity_name or wc, "machines": max(n, 0),
                    "is_machine": bool(mach), "win": best, "hours": round(best.net_min / 60.0, 2) if best else None,
                    "source": src,
                    "shift_start": first.shift_start_time.strftime("%H:%M") if first.shift_start_time else None,
                    "shift_end": first.shift_end_time.strftime("%H:%M") if first.shift_end_time else None}
    return wc_of_step, caps


# def _batch_steps(db: Session) -> Dict[int, Tuple[Optional[bool], str]]:
#     """Batch or series for every process (flow_step_id) and WHY - from process_type (stage_id, process_type_batch).
#       1. a process_type row with stage_id = flow_step_id                         -> its process_type_batch
#       2. else a row with stage_id = the step's step_order (the way the equipment page stores stage_id),
#          when that number is not the flow_step_id of another step                -> its process_type_batch
#       3. else no row                                                              -> series (None = row missing)
#     stage_schedule_config.batch_size is NOT used to decide: it defaults to 30 for every process."""
#     flags: Dict[int, bool] = {}
#     for p in db.query(Processtype).all():
#         if p.stage_id is not None:
#             flags[p.stage_id] = flags.get(p.stage_id, False) or bool(p.process_type_batch)
#     steps = db.query(ProcessFlowMaster).all()
#     ids = {s.flow_step_id for s in steps}
#     out: Dict[int, Tuple[Optional[bool], str]] = {}
#     for s in steps:
#         sid, so = s.flow_step_id, s.step_order
#         if sid in flags:
#             out[sid] = (flags[sid], f"process_type.stage_id = {sid} (flow_step_id)")
#         elif so is not None and so in flags and so not in ids:
#             out[sid] = (flags[so], f"process_type.stage_id = {so} (stored as step_order)")
#         else:
#             out[sid] = (None, f"no process_type row for flow_step_id {sid}" + (f" / step_order {so}" if so is not None else ""))
#     return out


def _batch_steps(db: Session) -> Dict[int, Tuple[Optional[bool], str]]:
    """Batch or series for every process (flow_step_id) and WHY.
      1. name contains one of BATCH_NAME_KEYWORDS (settings, default "baking")       -> batch
      2. a process_type row with stage_id = flow_step_id                           -> its process_type_batch
      3. else a row with stage_id = the step's step_order (when that number is not another step's id) -> its flag
      4. else (no process_type row) part_process_time.batch_size is filled for the process -> batch
      5. else                                                                      -> series (None = not set)"""
    flags: Dict[int, bool] = {}
    for p in db.query(Processtype).all():
        if p.stage_id is not None:
            flags[p.stage_id] = flags.get(p.stage_id, False) or bool(p.process_type_batch)
    steps = db.query(ProcessFlowMaster.flow_step_id, ProcessFlowMaster.step_order, ProcessFlowMaster.step_name).all()
    ids = {s.flow_step_id for s in steps}
    sized = {pid for (pid,) in db.query(PartProcessTime.process_id).filter(PartProcessTime.batch_size > 0).distinct().all()}
    out: Dict[int, Tuple[Optional[bool], str]] = {}
    for s in steps:
        sid, so = s.flow_step_id, s.step_order
        
        # processes whose name contains a configured word (default "baking") always run as batches
        kw = next((k for k in BATCH_NAME_KEYWORDS if k and k.lower() in (s.step_name or "").lower()), None)
        if kw:
            out[sid] = (True, f"name contains '{kw}'")
            continue
            
        if sid in flags:
            out[sid] = (flags[sid], f"process_type.stage_id = {sid} (flow_step_id)")
        elif so is not None and so in flags and so not in ids:
            out[sid] = (flags[so], f"process_type.stage_id = {so} (stored as step_order)")
        elif sid in sized:
            out[sid] = (True, "no process_type row - part_process_time.batch_size is filled for this process")
        else:
            out[sid] = (None, f"no process_type row for flow_step_id {sid}" + (f" / step_order {so}" if so is not None else ""))
    return out

def process_check(db: Session, plant: Optional[str] = None) -> Dict[str, Any]:
    """GET /schedule/po-gantt/process-check - every process: batch or series and why, batch size, machines.
    Use it when a process is scheduled the wrong way (e.g. a batch process shown as one block per PO)."""
    batch = _batch_steps(db)
    cfg = {c.stage_id: c for c in db.query(StageScheduleConfig).all()}
    eq: Dict[int, List[str]] = defaultdict(list)
    for e in db.query(Equipments).all():
        if e.stage_id is not None and (not plant or not e.plant_code or e.plant_code == plant):
            eq[e.stage_id].append(e.machine_id or e.eqpt_no or f"EQ-{e.id}")
    sizes: Dict[int, List[int]] = defaultdict(list)
    tq = db.query(PartProcessTime.process_id, PartProcessTime.batch_size).filter(PartProcessTime.batch_size.isnot(None))
    if plant:
        tq = tq.filter(PartProcessTime.plant == plant)
    for pid, bs in tq.all():
        if bs and bs > 0 and bs not in sizes[pid]:
            sizes[pid].append(bs)
    q = db.query(ProcessFlowMaster)
    if plant:
        q = q.filter(or_(ProcessFlowMaster.plant_code == plant, ProcessFlowMaster.plant_code.is_(None)))
    rows = []
    for s in q.order_by(ProcessFlowMaster.step_order, ProcessFlowMaster.flow_step_id).all():
        b, why = batch.get(s.flow_step_id, (None, "-"))
        c = cfg.get(s.flow_step_id)
        rows.append({
            "flow_step_id": s.flow_step_id, "step_order": s.step_order, "process": s.step_name,
            "scheduled_as": "BATCH" if b else "SERIES", "why": why, "process_type_row": b is not None,
            "batch_size_config": c.batch_size if c else None, "batch_size_parts": sorted(sizes.get(s.flow_step_id, [])),
            "machines_by_flow_step_id": eq.get(s.flow_step_id, []),
            "machines_by_step_order": eq.get(s.step_order, []) if s.step_order != s.flow_step_id else [],
        })
    return {"plant": plant, "processes": rows,
            "missing_process_type": [r["process"] for r in rows if not r["process_type_row"]]}


def list_batch_sizes(db: Session, plant: Optional[str] = None) -> Dict[str, Any]:
    """GET /schedule/batch-sizes - every BATCH process of the plant with its own batch size
    (stage_schedule_config.batch_size, one row per process). Empty = the fallback (DEFAULT_BATCH_SIZE) is used.
    A size set for one part (part_process_time.batch_size, Process times dialog) still wins for that part."""
    use_settings(db)
    seen, out = set(), []
    for r in process_check(db, plant)["processes"]:
        if r["scheduled_as"] != "BATCH" or r["flow_step_id"] in seen:
            continue
        seen.add(r["flow_step_id"])
        out.append({"flow_step_id": r["flow_step_id"], "step_order": r["step_order"], "process": r["process"],
                    "why": r["why"], "batch_size": r["batch_size_config"], "part_sizes": r["batch_size_parts"]})
    return {"plant": plant, "fallback": DEFAULT_BATCH_SIZE, "processes": out}


class BatchSizeSave(BaseModel):
    plant: Optional[str] = None
    sizes: List[Dict[str, Any]] = []          # [{flow_step_id, batch_size}] - batch_size empty / null = use the fallback


def save_batch_sizes(db: Session, body: BatchSizeSave) -> Dict[str, Any]:
    now = datetime.now()
    for x in body.sizes:
        try:
            sid = int(x.get("flow_step_id"))
        except (TypeError, ValueError):
            raise PoGanttError(400, f"Bad process id {x.get('flow_step_id')!r}")
        raw = x.get("batch_size")
        bs = None if raw in (None, "") else int(raw)
        if bs is not None and not (1 <= bs <= 10000):
            raise PoGanttError(400, f"Batch size {bs} must be between 1 and 10000")
        row = db.query(StageScheduleConfig).filter(StageScheduleConfig.stage_id == sid).first()
        if row is None:
            if bs is None:
                continue
            row = StageScheduleConfig(stage_id=sid)
            db.add(row)
        row.batch_size = bs
        if hasattr(row, "updated_at"):
            row.updated_at = now
    db.commit()
    return list_batch_sizes(db, body.plant)


def _dt_json(e: Dict[str, Any]) -> Dict[str, Any]:
    return {**e, "start": _iso(e["start"]), "end": _iso(e["end"])}


def list_open_orders(db: Session, plant: Optional[str] = None) -> Dict[str, Any]:
    """Yet-to-start POs for the picker (oldest first) + their part numbers - both ONLY from PcbData.
    A PO is yet to start when every one of its PCBs is New / Assigned (PCB_OPEN_STATUSES).
    Part number = PcbData.partNumber, Child / Main = PcbData.Type (e.g. OCTA-CHILD), plant = PcbData.plant."""
    warnings: List[str] = []
    q = db.query(PcbData.productionOrder, PcbData.partNumber, PcbData.quantity, PcbData.status, PcbData.createdAt,
                 PcbData.Type).filter(PcbData.productionOrder.isnot(None), PcbData.productionOrder != "",
                                      PcbData.partNumber.isnot(None), PcbData.partNumber != "")
    if plant:
        q = q.filter(PcbData.plant == plant)
    by_po: Dict[str, list] = defaultdict(list)
    for r in q.all():
        by_po[_norm(r[0])].append(r)

    def role(typ: Optional[str]) -> str:
        t_ = (typ or "").strip().upper()
        return "CHILD" if t_.endswith("CHILD") else "MAIN"

    open_pos = []
    for po, rows in by_po.items():
        if any((r[3] or "").strip().lower() not in PCB_OPEN_STATUSES for r in rows):
            continue                                              # some PCB already started -> not a yet-to-start PO
        parts = [r[1] for r in rows]
        part = max(set(parts), key=parts.count)
        if len(set(parts)) > 1:
            warnings.append(f"PO {po}: PCBs carry several part numbers ({', '.join(sorted(set(parts)))}) - {part} used")
        created = [r[4] for r in rows if r[4]]
        types = [r[5] for r in rows if r[1] == part and r[5]]
        open_pos.append({"po": po, "part": part, "qty": sum(r[2] if (r[2] and r[2] > 0) else 1 for r in rows),
                         "created": min(created) if created else None, "type": types[0] if types else None})
    open_pos.sort(key=lambda c: (c["created"] or datetime.max, c["po"]))

    parts = []
    for pn in sorted({c["part"] for c in open_pos}):                # only part numbers that are in PcbData
        typ = next((c["type"] for c in open_pos if c["part"] == pn and c["type"]), None)
        fam = (typ or "").strip().upper().rpartition("-")[0] or None
        parts.append({"part_number": pn, "role": role(typ), "product_type": fam, "sub_type": role(typ) if typ else None,
                      "description": None, "orders": sum(1 for c in open_pos if c["part"] == pn)})
    try:
        locked = {l.production_order: l.version_id for l in
                  db.query(SchedulePoLock).filter(SchedulePoLock.released_at.is_(None)).all()}
    except Exception:
        db.rollback()
        locked = {}
    return {"orders": [{"production_order": c["po"], "part_number": c["part"], "quantity": c["qty"],
                        "role": role(c["type"]), "created": c["created"].isoformat() if c["created"] else None,
                        "locked": c["po"] in locked, "locked_version_id": locked.get(c["po"])}
                       for c in open_pos],
            "parts": parts,
            "warnings": warnings}


def list_plants(db: Session) -> Dict[str, Any]:
    """Plant codes of product_type_master and of PcbData (a PO belongs to the plant of its part number)."""
    codes = sorted({(r[0] or "").strip() for r in db.query(ProductTypeMaster.plant_code).distinct().all()
                    if (r[0] or "").strip()} | {(r[0] or "").strip() for r in db.query(PcbData.plant).distinct().all()
                                               if (r[0] or "").strip()})
    info = {p.plant_code: p.location for p in db.query(Plant).all()}
    return {"plants": [{"plant_code": c, "location": info.get(c) or ""} for c in codes]}


def ensure_part_process_time_columns(engine) -> None:
    """create_all() does not alter existing tables - add machine_hours / batch_size once if they are missing."""
    try:
        cols = {c["name"] for c in sa_inspect(engine).get_columns("part_process_time")}
        with engine.begin() as conn:
            if "machine_hours" not in cols:
                conn.execute(sa_text("ALTER TABLE part_process_time ADD COLUMN machine_hours DOUBLE PRECISION NOT NULL DEFAULT 0"))
            if "batch_size" not in cols:
                conn.execute(sa_text("ALTER TABLE part_process_time ADD COLUMN batch_size INTEGER"))
    except Exception as exc:                                   # never block start-up
        print(f"[po_gantt] could not verify part_process_time columns: {exc}")


_PLAN_TABLES_READY = False


def ensure_plan_tables(bind) -> None:
    """Create schedule_plan / schedule_plan_item + this module's own tables (settings, plan versions, slot locks) if they
    do not exist yet, and give every older saved plan a version row (REV01 of its own plan)."""
    global _PLAN_TABLES_READY
    if _PLAN_TABLES_READY:
        return
    SchedulePlan.__table__.create(bind=bind, checkfirst=True)
    SchedulePlanItem.__table__.create(bind=bind, checkfirst=True)
    _OwnBase.metadata.create_all(bind=bind, checkfirst=True)
    with Session(bind=bind) as db:
        have = {v for (v,) in db.query(SchedulePlanVersion.version_id).all()}
        old = [p for p in db.query(SchedulePlan.id, SchedulePlan.name, SchedulePlan.created_at, SchedulePlan.created_by)
               .order_by(SchedulePlan.id).all() if p.id not in have]
        for p in old:
            yr = (p.created_at or datetime.now()).year
            ref = _next_plan_reference(db, yr)
            db.add(SchedulePlanVersion(version_id=p.id, plan_id=p.id, version_no=1, previous_version_id=None,
                                       plan_name=p.name, version_name=p.name, plan_reference=ref,
                                       reference=f"{ref}-REV-01", created_at=p.created_at, created_by=p.created_by))
            db.flush()
        db.commit()
    _PLAN_TABLES_READY = True


# --------------------------------------------------------------------------------------
# Own tables: user settings, plan version history, slot locks of assigned POs
# --------------------------------------------------------------------------------------
_OwnBase = declarative_base()


class ScheduleSetting(_OwnBase):
    """One row per setting the user changed on the Configure dialog (no row = default)."""
    __tablename__ = "schedule_settings"
    key = Column(String, primary_key=True)
    value = Column(JSON)
    updated_by = Column(String, nullable=True)
    updated_at = Column(DateTime, nullable=True)


class SchedulePlanVersion(_OwnBase):
    """Plan version history. Version_ID = schedule_plan.id (the saved schedule); Plan_ID = Version_ID of its REV01;
    Previous_Version_ID = the version it was revised from. Saved versions are never changed."""
    __tablename__ = "schedule_plan_version"
    version_id = Column(Integer, primary_key=True, autoincrement=False)
    plan_id = Column(Integer, index=True, nullable=False)
    version_no = Column(Integer, nullable=False)
    previous_version_id = Column(Integer, nullable=True)
    plan_name = Column(String)                       # Production Plan_03Nov2026-20Nov2026
    version_name = Column(String)                    # Production Plan_03Nov2026-20Nov2026_REV02
    plan_reference = Column(String, index=True)      # SCH-2026-001
    reference = Column(String, unique=True)          # SCH-2026-001-REV-02
    created_at = Column(DateTime)
    created_by = Column(String, nullable=True)


class SchedulePoLock(_OwnBase):
    """A PO assigned from a saved plan version keeps that version's time slots (machines / lines / batches)."""
    __tablename__ = "schedule_po_lock"
    id = Column(Integer, primary_key=True, autoincrement=True)
    version_id = Column(Integer, index=True, nullable=False)
    production_order = Column(String, index=True, nullable=False)
    plant_code = Column(String, index=True, nullable=True)
    locked_at = Column(DateTime)
    locked_by = Column(String, nullable=True)
    released_at = Column(DateTime, nullable=True)
    released_by = Column(String, nullable=True)


def _next_plan_reference(db: Session, year: int) -> str:
    """SCH-<year>-<nnn>: nnn = the plan's number among the plans started in that year."""
    pref = f"{PLAN_REF_PREFIX}-{year}-"
    n = 0
    for (r,) in db.query(SchedulePlanVersion.plan_reference).filter(SchedulePlanVersion.version_no == 1,
                                                                     SchedulePlanVersion.plan_reference.like(f"%-{year}-%")).all():
        m = re.search(r"-(\d+)$", r or "")
        if m:
            n = max(n, int(m.group(1)))
    return f"{pref}{n + 1:03d}"


# --------------------------------------------------------------------------------------
# Settings: load (every request) / save
# --------------------------------------------------------------------------------------
def use_settings(db: Session) -> Dict[str, Any]:
    """Defaults + the values the user saved -> the module rules used by this request. Returns the UI values."""
    ensure_plan_tables(db.get_bind())
    vals = dict(_DEFAULT_SETTINGS)
    try:
        for r in db.query(ScheduleSetting).all():
            if r.key in _SETTING_KEYS:
                vals[r.key] = r.value
    except Exception:
        db.rollback()
    for k, v in vals.items():
        try:
            globals()[k] = _setting_value(k, v)
        except PoGanttError:
            globals()[k] = _setting_value(k, _DEFAULT_SETTINGS[k])
    return vals


def get_settings(db: Session) -> Dict[str, Any]:
    vals = use_settings(db)
    changed = {r.key: {"by": r.updated_by, "at": _iso(r.updated_at)} for r in db.query(ScheduleSetting).all()}
    return {"schema": SETTINGS_SCHEMA, "values": vals, "defaults": _DEFAULT_SETTINGS, "changed": changed}


class SettingsSave(BaseModel):
    values: Dict[str, Any] = {}
    reset: List[str] = []              # keys to put back to the default
    updated_by: Optional[str] = None


def save_settings(db: Session, body: SettingsSave) -> Dict[str, Any]:
    ensure_plan_tables(db.get_bind())
    now = datetime.now()
    for k in body.reset:
        db.query(ScheduleSetting).filter(ScheduleSetting.key == k).delete(synchronize_session=False)
    for k, v in body.values.items():
        if k not in _SETTING_KEYS:
            raise PoGanttError(400, f"Unknown setting {k}")
        py = _setting_value(k, v)                    # validates
        if k == "DEFAULT_SHIFT_START" and py is None:
            raise PoGanttError(400, "Day starts at (fallback): enter a time")
        ui = _setting_json_of(k, py)
        if ui == _DEFAULT_SETTINGS[k]:
            db.query(ScheduleSetting).filter(ScheduleSetting.key == k).delete(synchronize_session=False)
            continue
        row = db.query(ScheduleSetting).filter(ScheduleSetting.key == k).first()
        if row is None:
            row = ScheduleSetting(key=k)
            db.add(row)
        row.value, row.updated_by, row.updated_at = ui, body.updated_by, now
    db.commit()
    return get_settings(db)


def _setting_json_of(key: str, py: Any) -> Any:
    old = globals()[key]
    globals()[key] = py
    try:
        return _setting_json(key)
    finally:
        globals()[key] = old


def list_part_process_times(db: Session, plant: Optional[str], part_no: Optional[str] = None) -> Dict[str, Any]:
    """Every routing step of every part of the plant, joined with its part_process_time row (if any).
    Parts: product_type_master of the plant + parts of PcbData (plant) that the master does not know.
    Steps: product_workflow_mapping, else part_process_time (see _part_flows)."""
    pq = db.query(ProductTypeMaster)
    if plant:
        pq = pq.filter(ProductTypeMaster.plant_code == plant)
    if part_no:
        pq = pq.filter(ProductTypeMaster.part_number == part_no)
    products = [{"part_no": p.part_number, "product_type": p.product_type_name, "sub_type": p.sub_product_type_name,
                 "description": p.description}
                for p in pq.order_by(ProductTypeMaster.product_type_name, ProductTypeMaster.sub_product_type_name,
                                     ProductTypeMaster.part_number).all()]
    known = {p["part_no"] for p in products}
    tq0 = db.query(PcbData.partNumber, PcbData.Type).filter(PcbData.partNumber.isnot(None))
    if plant:
        tq0 = tq0.filter(PcbData.plant == plant)
    if part_no:
        tq0 = tq0.filter(PcbData.partNumber == part_no)
    for pn, typ in sorted(set(tq0.distinct().all()), key=lambda x: x[0]):
        if pn not in known:
            known.add(pn)
            fam, _, role = (typ or "").strip().upper().rpartition("-")
            products.append({"part_no": pn, "product_type": fam or None, "sub_type": role or None, "description": None})
    pns = [p["part_no"] for p in products]
    if not pns:
        return {"plant": plant, "parts": [], "rows": []}
    batch = {sid for sid, (b, _) in _batch_steps(db).items() if b}
    ppt = {}
    for chunk in _chunks(pns):
        tq = db.query(PartProcessTime).filter(PartProcessTime.part_no.in_(chunk))
        if plant:
            tq = tq.filter(PartProcessTime.plant == plant)
        for r in tq.all():
            ppt[(r.part_no, r.process_id)] = r
    flows, _ = _part_flows(db, pns, plant)
    rows = []
    for p in products:
        for st in flows.get(p["part_no"], []):
            r = ppt.get((p["part_no"], st.flow_step_id))
            rows.append({
                "part_no": p["part_no"], "product_type": p["product_type"], "sub_type": p["sub_type"],
                "process_id": st.flow_step_id, "process_name": step_name(st), "step_sequence": st.step_sequence,
                "is_batch": st.flow_step_id in batch,
                "sap_time": r.sap_time if r else None, "actual_time": r.actual_time if r else None,
                "machine_hours": float(r.machine_hours or 0) if r else 0.0,
                "batch_size": r.batch_size if r else None,
            })
    return {"plant": plant, "parts": products, "rows": rows}


class PartTimeItem(BaseModel):
    part_no: str
    process_id: int
    machine_hours: Optional[float] = 0.0
    batch_size: Optional[int] = None


class PartTimeSave(BaseModel):
    plant: str
    items: List[PartTimeItem]


def save_part_process_times(db: Session, body: PartTimeSave) -> Dict[str, Any]:
    stage_names = dict(db.query(ProcessFlowMaster.flow_step_id, ProcessFlowMaster.step_name).all())
    updated = created = 0
    for it in body.items:
        mh = float(it.machine_hours or 0)
        if mh < 0:
            raise PoGanttError(422, f"{it.part_no} / step {it.process_id}: machine hours cannot be negative")
        if it.batch_size is not None and it.batch_size < 0:
            raise PoGanttError(422, f"{it.part_no} / step {it.process_id}: batch size cannot be negative")
        bs = int(it.batch_size) if it.batch_size and it.batch_size > 0 else None
        row = db.query(PartProcessTime).filter(
            PartProcessTime.part_no == it.part_no, PartProcessTime.plant == body.plant,
            PartProcessTime.process_id == it.process_id).first()
        if row:
            row.machine_hours, row.batch_size = mh, bs
            updated += 1
        else:
            if it.process_id not in stage_names:
                raise PoGanttError(404, f"Process step {it.process_id} not found")
            db.add(PartProcessTime(part_no=it.part_no, plant=body.plant, process_id=it.process_id,
                                   process_name=stage_names[it.process_id], machine_hours=mh, batch_size=bs))
            created += 1
    db.commit()
    return {"updated": updated, "created": created}


# --------------------------------------------------------------------------------------
# Builder
# --------------------------------------------------------------------------------------
def _load_calendar(db: Session, plant: Optional[str]) -> DayCalendar:
    """public_holidays + calendar_exceptions of the plant (rows without a plant count for every plant)."""
    def of_plant(model):
        q = db.query(model)
        col = getattr(model, "plant_code", None)
        if plant and col is not None:
            q = q.filter(or_(col == plant, col.is_(None), col == ""))
        return q.all()
    holidays = {h.holiday_date: h.name for h in of_plant(PublicHoliday)}
    exceptions = {e.exception_date: e.exception_type for e in of_plant(CalendarException)}
    return DayCalendar(holidays, exceptions, DEFAULT_SHIFT_START)


def build_po_gantt(db: Session, production_orders: Optional[List[str]] = None, plant: Optional[str] = None,
                   start_date: Optional[date] = None, time_source: str = "actual", label_mode: str = "seq",
                   show_holidays: bool = False, shift_start: Optional[float] = None,
                   today: Optional[date] = None, now: Optional[datetime] = None,
                   start_at: Optional[datetime] = None, use_locks: bool = True) -> Dict[str, Any]:
    """start_at = the exact moment scheduling starts (default: now). start_date (legacy) = from the start of that day.
    shift_start is not used any more (the day start comes from the shift tables / settings)."""
    use_settings(db)
    if time_source not in ("actual", "sap"):
        raise PoGanttError(400, "time_source must be 'actual' or 'sap'")
    if label_mode not in ("seq", "po"):
        raise PoGanttError(400, "label_mode must be 'seq' or 'po'")
    warnings: List[str] = []
    now = now or datetime.now()
    today = today or now.date()
    if start_at is not None:
        start_dt = start_at.replace(tzinfo=None, microsecond=0)
    elif start_date is not None:
        start_dt = datetime.combine(start_date, time.min)
    else:                                                          # the exact moment the schedule is made
        start_dt = now.replace(second=0, microsecond=0) + (timedelta(minutes=1) if now.second or now.microsecond else timedelta())
    start_day = start_dt.date()

    # ---------------- calendar ----------------
    cal = _load_calendar(db, plant)
    default_win, default_win_src, default_shifts = _default_win(db)
    cal.shift_start = default_win.start_h
    wc_of_step, wc_caps = _load_workcenters(db, plant, warnings)

    # ---------------- masters (loaded once) ----------------
    products, child_of, role_of = _product_links(db, warnings)

    batch_rule = _batch_steps(db)                                  # flow_step_id -> (batch?, why)
    is_batch: Dict[int, bool] = defaultdict(bool, {sid: bool(b) for sid, (b, _) in batch_rule.items()})
    cfg = {c.stage_id: c for c in db.query(StageScheduleConfig).all()}
    cap_by_key = {_key(c.name): c for c in db.query(StageCapacityDB).all()}
    cap_compact = {k.replace(" ", ""): c for k, c in cap_by_key.items()}

    def find_cap(name: Optional[str]):
        """stage_capacity row of a process: exact name, then ignoring spaces / punctuation, then a UNIQUE partial match."""
        k = _key(name)
        if not k:
            return None
        c = cap_by_key.get(k) or cap_compact.get(k.replace(" ", ""))
        if c:
            return c
        hits = [v for ck, v in cap_by_key.items() if ck and (ck in k or k in ck)]
        return hits[0] if len(hits) == 1 else None

    equipment: Dict[int, List[str]] = defaultdict(list)          # stage_id -> machine_ids
    machine_info: Dict[str, Dict[str, Any]] = {}                  # machine_id -> details
    eq_q = db.query(Equipments)
    # only the machines of the chosen plant - or, for "all plants", of the plants that have POs in PcbData
    eq_plants = [plant] if plant else sorted({(r[0] or "").strip() for r in db.query(PcbData.plant).distinct().all()
                                               if (r[0] or "").strip()})
    if eq_plants:
        eq_q = eq_q.filter(or_(Equipments.plant_code.in_(eq_plants), Equipments.plant_code.is_(None), Equipments.plant_code == ""))
    seen_eq = defaultdict(set)                                    # sets: 44k machines must not mean 44k x 44k checks
    for e in eq_q.order_by(Equipments.stage_id, Equipments.id).all():
        mid = e.machine_id or e.eqpt_no or f"EQ-{e.id}"
        if e.stage_id is not None and mid not in seen_eq[e.stage_id]:
            seen_eq[e.stage_id].add(mid)
            equipment[e.stage_id].append(mid)
        info = machine_info.setdefault(mid, {"machine_id": mid, "name": e.eqpt_name or mid, "eqpt_no": e.eqpt_no,
                                             "process_type": e.process_type,
                                             "make": e.eqpt_make, "model": e.eqpt_model,
                                             "workcenter": getattr(e, "workcenter_code", None) or getattr(e, "workcenter_name", None), "stage_ids": []})
        if e.stage_id is not None and e.stage_id not in info["stage_ids"]:
            info["stage_ids"].append(e.stage_id)

    # equipment is normally linked by stage_id = flow_step_id. A process whose flow step has a different id / spelling
    # (e.g. "BAKING" vs "Baking") would then wrongly look manual - so also match by the step NAME, and by the
    # equipment's own process_type / workcenter / name.
    stage_names = dict(db.query(ProcessFlowMaster.flow_step_id, ProcessFlowMaster.step_name).all())
    eq_by_stage_name: Dict[str, Dict[str, None]] = defaultdict(dict)   # dict = ordered set
    for sid_, mids_ in equipment.items():
        k_ = _key(stage_names.get(sid_))
        if k_:
            eq_by_stage_name[k_].update(dict.fromkeys(mids_))
    eq_by_label: Dict[str, Dict[str, None]] = defaultdict(dict)
    for m_, inf_ in machine_info.items():
        for lab_ in (inf_.get("process_type"), inf_.get("workcenter"), inf_.get("name")):
            k_ = _key(lab_)
            if k_:
                eq_by_label[k_][m_] = None

    def machines_for_step(sid: int, name: str) -> List[str]:
        k_ = _key(name)
        for pool in (equipment.get(sid), eq_by_stage_name.get(k_), eq_by_label.get(k_)):
            if pool:
                return list(pool)
        return []

    shift_names = [s.name for s in db.query(ShiftDefinition).filter(ShiftDefinition.is_active.is_(True))
                   .order_by(ShiftDefinition.sort_order, ShiftDefinition.id).all()]
    assigned: Dict[str, set] = defaultdict(set)
    for a in db.query(OperatorShiftAssignment).all():
        assigned[a.operator_staff_no].add(a.shift_name)
    ops_by_stage: Dict[int, List[str]] = defaultdict(list)
    for o in db.query(OperatorStepMapping).all():
        who = o.operator_staff_no or o.operator_name
        if who and who not in ops_by_stage[o.flow_step_id]:
            ops_by_stage[o.flow_step_id].append(who)

    def operators_per_shift(sid: int) -> int:
        ops = ops_by_stage.get(sid, [])
        if not shift_names:
            return len(ops)
        return max((sum(1 for o in ops if not assigned.get(o) or sn in assigned[o]) for sn in shift_names), default=0)

    line_of_name = {_key(n): g for g, names in LINE_GROUPS.items() for n in names}

    # ---------------- select the POs to load ----------------
    cands = _load_candidates(db, plant, warnings)
    # POs assigned from a saved plan keep that plan's slots: they are not scheduled again, their slots are booked first
    locked = _locked_slots(db, plant, start_dt, warnings) if (use_locks and LOCK_ASSIGNED_SLOTS) else {}
    if production_orders:
        selected, seen = [], set()
        for raw in production_orders:
            k = _norm(raw) or raw
            if k in seen:
                continue
            seen.add(k)
            if k in locked:
                continue                                       # shown at its locked slots
            if k not in cands:
                raise PoGanttError(404, f"Production order {raw} not found")
            if cands[k]["started"]:
                warnings.append(f"PO {k} has already started - scheduled from scratch as requested")
            selected.append(cands[k])
        explicit = True
    else:
        selected = sorted((c for c in cands.values() if not c["started"] and c["po"] not in locked),
                          key=lambda c: (c["created"] or datetime.max, c["po"]))
        explicit = False

    # ---------------- routing (product_workflow_mapping) + times ----------------
    # child -> main by serial number; the child POs that are NOT in this schedule are still needed (in process / what-if)
    serial_links, serial_unmatched = _serial_links(db, cands, role_of, child_of, [c["po"] for c in selected])
    sel_pos = {c["po"] for c in selected}
    outside_child_parts = {l["child_part"] for c in selected for l in serial_links.get(c["po"], [])
                           if l["child_po"] not in sel_pos and l["child_part"]}
    part_numbers = ({c["part"] for c in selected if c["part"]} | outside_child_parts
                    | {L["part"] for L in locked.values() if L["part"]})
    routing, from_times = _part_flows(db, part_numbers, plant)
    if from_times:
        warnings.append(f"No flow in product_workflow_mapping for part(s) {', '.join(sorted(from_times))} - the flow was taken "
                        f"from part_process_time (MES steps in step order). Set up the flow in product workflow mapping.")
    times: Dict[tuple, list] = defaultdict(list)
    if part_numbers:
        tq = db.query(PartProcessTime).filter(PartProcessTime.part_no.in_(part_numbers))
        if plant:
            tq = tq.filter(PartProcessTime.plant == plant)
        for r in tq.all():
            times[(r.part_no, r.process_id)].append(r)
    other = "sap" if time_source == "actual" else "actual"

    def time_row(part: str, sid: int):
        rows = times.get((part, sid), [])
        if not rows:
            return None
        pref = plant or (products[part].plant_code if part in products else None)
        return next((r for r in rows if r.plant == pref), rows[0])

    def hours_per_unit(part: str, step) -> Tuple[Optional[float], str]:
        """Hours for one unit (SERIES) / one batch (BATCH) = base time + machine hours."""
        row = time_row(part, step.flow_step_id)
        mh = max(float(getattr(row, "machine_hours", 0) or 0), 0.0) if row else 0.0
        base, src = None, "none"
        if row:
            for s in (time_source, other):
                val = row.actual_time if s == "actual" else row.sap_time
                if val and val > 0:
                    base, src = float(val), f"part_process_time.{s}"
                    break
        if base is None and getattr(step, "process_time_seconds", None) and step.process_time_seconds > 0:
            base, src = step.process_time_seconds / 3600.0, "routing"
        if base is None:
            cap = find_cap(step_name(step))
            if cap and cap.manufacturing_time_mins and cap.manufacturing_time_mins > 0:
                base, src = float(cap.manufacturing_time_mins) / 60.0, "stage_capacity"
        if base is None and mh <= 0:
            return None, "none"
        return (base or 0.0) + mh, src + (" + machine_hours" if mh > 0 else "")

    def batch_size_for(part: str, sid: int) -> int:
        row = time_row(part, sid)
        if row and getattr(row, "batch_size", None) and row.batch_size > 0:
            return int(row.batch_size)
        return max(int((cfg[sid].batch_size if sid in cfg else 0) or DEFAULT_BATCH_SIZE), 1)

    # ---------------- operations of a part (its flow, with the line steps merged) ----------------
    ops_cache: Dict[str, List[Dict[str, Any]]] = {}

    def ops_for(part: str) -> List[Dict[str, Any]]:
        if part in ops_cache:
            return ops_cache[part]
        steps = routing.get(part, [])
        ops, done = [], set()
        for st in steps:
            g = line_of_name.get(_key(step_name(st)))
            if g:
                if g in done:
                    continue
                done.add(g)
                members = [x for x in steps if line_of_name.get(_key(step_name(x))) == g]
                ops.append({"key": f"LINE-{g}", "line": g, "steps": members})
            else:
                ops.append({"key": f"STEP-{st.flow_step_id}", "line": None, "steps": [st]})
        ops_cache[part] = ops
        return ops

    # ---------------- build PO objects ----------------
    pos: List[Dict[str, Any]] = []
    for c in selected:
        part, po_no = c["part"], c["po"]
        steps = routing.get(part or "", [])
        if not steps or c["qty"] <= 0:
            msg = (f"PO {po_no}: part {part} has no flow in product_workflow_mapping" if not steps
                   else f"PO {po_no}: quantity is 0")
            if explicit:
                raise PoGanttError(422, msg)
            warnings.append(msg + " - not scheduled")
            continue
        pos.append({"po": po_no, "part": part, "qty": c["qty"], "ops": ops_for(part), "idx": len(pos) + 1,
                    "role": role_of(part)})
    if not pos and not locked:
        raise PoGanttError(404, "No production orders to schedule")
    for po_no, L in sorted(locked.items(), key=lambda kv: kv[1]["start"] or datetime.max):
        if L.get("past"):                                  # assigned and its planned slots are over: nothing left to keep
            continue
        pos.append({"po": po_no, "part": L["part"], "qty": L["qty"], "ops": ops_for(L["part"]) if L["part"] else [],
                    "idx": len(pos) + 1, "role": role_of(L["part"]) if L["part"] else (L.get("role") or "MAIN"),
                    "locked": True, "lock": L})
    locked_info = [p for p in pos if p.get("locked")]
    for p in pos:
        p["label"] = f"B{p['idx']}" if label_mode == "seq" else p["po"]
    label_idx = {p["label"]: p["idx"] for p in pos}
    label_role = {p["label"]: p["role"] for p in pos}

    # ---------------- machine down-time (breakdowns + preventive maintenance) ----------------
    downtime = _load_downtime(db, machine_info, start_dt, now, warnings)
    blocks_of = {mid: _merge((e["start"], e["end"]) for e in evs) for mid, evs in downtime.items()}
    material = _load_consumable_blocks(db, now, start_dt, warnings)     # flow_step_id -> consumable shortages

    # ---------------- stations ----------------
    stations: Dict[str, Station] = {}
    cap_missing: List[str] = []
    shift_missing: List[str] = []

    def workcenter_of(sids: List[int]):
        for i in sids:
            wc = wc_of_step.get(i)
            if wc and wc in wc_caps:
                return wc, wc_caps[wc]
        return next((wc_of_step[i] for i in sids if i in wc_of_step), None), None

    def virtual_machine(wc: str, k: int, step: str) -> str:
        """A machine the work centre has (number_of_individuals) but equipment_details does not list."""
        vid = f"{wc}-M{k + 1}"
        machine_info.setdefault(vid, {"machine_id": vid, "name": f"{wc_caps[wc]['name']} - machine {k + 1}", "eqpt_no": None,
                                      "process_type": step, "make": None, "model": None, "workcenter": wc,
                                      "stage_ids": [], "virtual": True})
        return vid

    def make_station(op: Dict[str, Any]) -> Station:
        key = op["key"]
        if key in stations:
            return stations[key]
        members = op["steps"]
        sids = [m.flow_step_id for m in members]
        wc, wcap = workcenter_of(sids)
        if op["line"] and wcap and wcap["machines"] > 0:
            # SMT LINE with a work centre: number_of_individuals = number of lines
            g = op["line"]
            s = Station(key, g, "LINE", sids)
            s.steps = [step_name(m) for m in members]
            s.mode = "LINE"
            mach_of = {m.flow_step_id: machines_for_step(m.flow_step_id, step_name(m)) for m in members}
            n = wcap["machines"]
            for i in range(n):
                phys = [(mach_of[m.flow_step_id][i], step_name(m)) for m in members if i < len(mach_of[m.flow_step_id])]
                s.options.append({"name": g if n == 1 else f"{g} #{i + 1}",
                                  "resources": [mid for mid, _ in phys] or [f"LINE-{g}-{i}"], "phys": phys})
            s.real_machines = [(mid, nm) for o in s.options for mid, nm in o["phys"]]
            s.setup = max([float(cfg[i].setup_minutes or 0) for i in sids if i in cfg], default=0.0)
            s.operators = max(operators_per_shift(i) for i in sids)
            last = cfg.get(sids[-1])
            names = [g] + s.steps
        elif op["line"]:
            g = op["line"]
            s = Station(key, g, "LINE", sids)
            s.steps = [step_name(m) for m in members]
            s.mode = "LINE"
            mach_of = {m.flow_step_id: machines_for_step(m.flow_step_id, step_name(m)) for m in members}
            with_eq = [(m.flow_step_id, step_name(m)) for m in members if mach_of[m.flow_step_id]]
            n = min(len(mach_of[i]) for i, _ in with_eq) if with_eq else 1   # as parallel as its narrowest step
            for i in range(n):
                phys = [(mach_of[sid][i], nm) for sid, nm in with_eq]
                s.options.append({"name": g if n == 1 else f"{g} #{i + 1}",
                                  "resources": [m for m, _ in phys] or [f"LINE-{g}-{i}"], "phys": phys})
            s.real_machines = [(mid, nm) for sid, nm in with_eq for mid in mach_of[sid]]
            s.setup = max([float(cfg[i].setup_minutes or 0) for i in sids if i in cfg], default=0.0)
            s.operators = max(operators_per_shift(i) for i in sids)
            last = cfg.get(sids[-1])
            names = [g] + s.steps
        else:
            sid = sids[0]
            s = Station(key, step_name(members[0]), "STEP", sids)
            s.mode = "BATCH" if is_batch.get(sid) else "SERIES"
            last = cfg.get(sid)
            if last:
                s.batch_size = max(int(last.batch_size or DEFAULT_BATCH_SIZE), 1)
                s.setup = float(last.setup_minutes or 0)
            mids = machines_for_step(sid, s.name)
            rmode = (str(getattr(last, "resource_mode", None) or "AUTO")).upper() if last else "AUTO"
            if rmode == "MANUAL":                                   # stage_schedule_config.resource_mode forces manual
                mids = []
            elif rmode == "MACHINE" and not mids:
                warnings.append(f"{s.name}: resource_mode is MACHINE but no machine is mapped in equipment_details")
            if wcap and wcap["machines"] > 0 and rmode != "MANUAL":
                # work centre: number_of_individuals machines (labour rows = people / work places). The first ones are the
                # machines of equipment_details (so their breakdowns / maintenance count), the rest are named after the WC.
                n = wcap["machines"]
                if len(mids) > n:
                    warnings.append(f"{s.name}: equipment_details lists {len(mids)} machines, work centre {wc} has {n} - "
                                    f"{n} used ({', '.join(mids[:n])})")
                for k in range(n):
                    if k < len(mids):
                        s.options.append({"name": mids[k], "resources": [mids[k]], "phys": [(mids[k], s.name)]})
                    elif wcap["is_machine"]:
                        vid = virtual_machine(wc, k, s.name)
                        s.options.append({"name": vid, "resources": [vid], "phys": [(vid, s.name)]})
                    else:
                        s.options.append({"name": f"{wc} #{k + 1}", "resources": [f"WC-{wc}-{k}"], "phys": []})
                s.real_machines = [ph for o in s.options for ph in o["phys"]]
            elif mids:
                s.options = [{"name": mid, "resources": [mid], "phys": [(mid, s.name)]} for mid in mids]
                s.real_machines = [(mid, s.name) for mid in mids]
            else:
                slots = max(int(MANUAL_PARALLEL_SLOTS), 1)          # no machine -> people: several POs can run side by side
                s.options = [{"name": "", "resources": [f"NO-MACHINE-{sid}-{k}"], "phys": []} for k in range(slots)]
            s.operators = operators_per_shift(sid)
            names = [s.name]
        # a consumable shortage of ANY step stops the whole process (SMT LINE: the whole line), machine or not
        s.material = [e for i in sids for e in material.get(i, [])]
        mat_blocks = [(e["start"], e["end"]) for e in s.material]
        for o in s.options:
            o["blocks"] = _merge([b for r in o["resources"] for b in blocks_of.get(r, [])] + mat_blocks)
        if s.kind == "LINE":
            # the LINE is one PO at a time (line_res for the whole run); each machine is only busy during ITS step,
            # so a machine shared with another process (e.g. the reflow oven) holds the line only when it is needed
            for i, o in enumerate(s.options):
                o["line_res"] = f"LINE-{key}-{i}"
                o["step_mids"] = [[mid for mid, nm in o["phys"] if nm == sname] for sname in s.steps]
        if last:
            s.cooldown = float(last.cooldown_minutes or 0)
            s.cd_working_only = bool(last.cooldown_working_time_only)
            s.next_day_release = bool(last.next_day_release) and bool(is_batch.get(sids[-1]))
        # working window of a day: the work centre (sap_workcenter_capacity) as it is - else shift_definition - else
        # the fallback settings. Nothing is rounded up to a minimum number of shifts.
        # s.workcenter, s.wc_name = wc, (wcap or {}).get("name")
        # if wcap and wcap.get("win"):
        #     s.win, s.shift_source = wcap["win"], f"work centre {wc}: {wcap['source']}"
        #     s.shifts = max(1, int(round(s.win.net_min / 60.0 / max(DEFAULT_HOURS_PER_SHIFT, 0.5))))
        # else:
        #     if not wcap:
        #         cap_missing.append(f"{s.name}" + (f" (WC {wc})" if wc else ""))
        #     s.win, s.shift_source, s.shifts = default_win, default_win_src, default_shifts
        # s.cap_min = s.win.net_min                          # net working minutes of a normal day
        # s.hps = s.cap_min / 60.0 / max(s.shifts, 1)

                # working window of a day:  shifts a day = stage_capacity.shifts_per_day (taken directly, matched by the stage name)
        #                           hours of ONE shift + start = the work centre (sap_workcenter_capacity)
        # s.workcenter, s.wc_name = wc, (wcap or {}).get("name")
        # cap_row = next((c for c in (find_cap(n) for n in names) if c), None)        # stage_capacity row of this stage
        # sh = int(cap_row.shifts_per_day or 0) if cap_row else 0
        # if not sh:
        #     shift_missing.append(s.name)
        # if wcap and wcap.get("win"):
        #     one = wcap["win"]                                                        # ONE shift of the work centre
        #     n_sh = sh or default_shifts
        #     span = min(one.cap_min * n_sh, MAX_DAY_HOURS * 60.0)
        #     s.win = Win(one.start_h, span) if one.brk_h is None else _win_from_span(one.start_h, span, n_sh)
        #     s.shifts = n_sh
        #     s.shift_source = (f"work centre {wc}: {wcap['source']} x {n_sh} shift(s)"
        #                       + (" (stage_capacity)" if sh else " (default)"))
        # else:
        #     if not wcap:
        #         cap_missing.append(f"{s.name}" + (f" (WC {wc})" if wc else ""))
        #     s.win, s.shift_source, s.shifts = default_win, default_win_src, default_shifts
        #     if sh and sh != default_shifts:                                          # shifts from stage_capacity
        #         per_shift = default_win.net_min / max(default_shifts, 1)
        #         s.win = Win(default_win.start_h, min(per_shift * sh, MAX_DAY_HOURS * 60.0))
        #         s.shifts = sh
        #         s.shift_source = f"{default_win_src}: {per_shift / 60:g} h x {sh} shift(s) (stage_capacity)"
        # s.cap_min = s.win.net_min                          # net working minutes of a normal day
        # s.hps = s.cap_min / 60.0 / max(s.shifts, 1)


        # working window of a day: shifts a day = stage_capacity.shifts_per_day (mapped by Workcenter)
        # hours of ONE shift + start = the work centre (sap_workcenter_capacity)
        s.workcenter, s.wc_name = wc, (wcap or {}).get("name")
        
        # Link Process -> Workcenter -> Shifts in stage_capacity
        lookup_names = [n for n in [wc, s.wc_name] + names if n]
        cap_row = next((c for c in (find_cap(n) for n in lookup_names) if c), None)
        
        sh = int(cap_row.shifts_per_day or 0) if cap_row else 0
        if not sh:
            shift_missing.append(f"{s.name} (WC: {wc})")
            
        n_sh = sh if sh > 0 else default_shifts

        if wcap and wcap.get("win"):
            one = wcap["win"]
            span = min(one.cap_min * n_sh, MAX_DAY_HOURS * 60.0)
            s.win = Win(one.start_h, span) if one.brk_h is None else _win_from_span(one.start_h, span, n_sh)
            s.shifts = n_sh
            s.shift_source = f"work centre {wc}: {wcap['source']} x {n_sh} shift(s)" + (" (stage_capacity)" if sh else " (default)")
        else:
            if not wcap:
                cap_missing.append(f"{s.name}" + (f" (WC {wc})" if wc else ""))
            per_shift = default_win.net_min / max(default_shifts, 1)
            s.win = Win(default_win.start_h, min(per_shift * n_sh, MAX_DAY_HOURS * 60.0))
            s.shifts = n_sh
            s.shift_source = f"{default_win_src}: {per_shift / 60:g} h x {n_sh} shift(s)" + (" (stage_capacity)" if sh else " (default)")

        s.cap_min = s.win.net_min                          # net working minutes of a normal day
        s.hps = s.cap_min / 60.0 / max(s.shifts, 1)
        
        stations[key] = s
        return s

    for p in pos:
        for op in p["ops"]:
            make_station(op)
    no_type = sorted({f"{step_name(m)} (step {m.flow_step_id})" for p in pos for op in p["ops"] for m in op["steps"]
                      if not op["line"] and batch_rule.get(m.flow_step_id, (None, ""))[0] is None})
    if no_type:
        warnings.append("No process_type row (batch / series not set) - scheduled as series, one PO block: "
                        + ", ".join(no_type) + ". If one of them is a batch process, add it to process_type with "
                        "process_type_batch = true (stage_id = flow_step_id). Check: /schedule/po-gantt/process-check")
    for cpart in outside_child_parts:                   # child POs outside the schedule (only for estimates)
        for op in ops_for(cpart):
            make_station(op)
    if cap_missing:
        warnings.append(f"No work centre capacity (sap_workcenter_capacity) for: {', '.join(dict.fromkeys(cap_missing))} - "
                        f"working hours from {default_win_src} and the machines of equipment_details used "
                        f"(set process_flow_master.workcenter_code)")
    if shift_missing:
        warnings.append(f"No stage_capacity row (shifts_per_day) for: {', '.join(dict.fromkeys(shift_missing))} - "
                        f"{default_shifts} shift(s) used (the stage_capacity name must match the process name)")

    # ---------------- run time of one operation ----------------
    missing_time: Dict[str, List[str]] = defaultdict(list)

    def step_minutes(part: str, st, qty: int) -> Optional[Tuple[float, float]]:
        """(minutes for the whole PO, minutes for the first board / batch) of one routing step."""
        hrs, _src = hours_per_unit(part, st)
        if hrs is None:
            return None
        t = hrs * 60.0
        sid = st.flow_step_id
        if is_batch.get(sid):
            bs = batch_size_for(part, sid)
            return math.ceil(qty / bs) * t, t
        return qty * t, t

    def op_minutes_and_parts(p: Dict[str, Any], op: Dict[str, Any], s: Station):
        """Minutes of one operation for the whole PO, and (PO minutes, first board / batch minutes) of each step in it.
        SMT LINE: the steps run one after the other, so the line time is the SUM of its steps."""
        parts = []
        for st in op["steps"]:
            m = step_minutes(p["part"], st, p["qty"])
            if m is None:
                missing_time[p["part"]].append(step_name(st))
                m = (FALLBACK_MINUTES, FALLBACK_MINUTES)
            parts.append(m)
        total = sum(m[0] for m in parts) if s.kind == "LINE" else parts[0][0]
        return max(total + s.setup, 1.0), parts

    # ---------------- child PO -> main PO ----------------
    # 1. by SERIAL number: the main PCB needs the child PCB with the same serial (as the assign step checks it).
    #    child PO in this schedule          -> the main PO waits for it
    #    child PO outside, PCBs done        -> nothing to wait for
    #    child PO outside, PCBs in process  -> the main PO waits for the estimated end of the child (rest of its flow)
    #    child PO outside, NOT assigned     -> the main PO is scheduled without waiting (FORCED) + "assign the child on
    #                                          day X -> main can start on day Y" message
    # 2. main POs without any serial match: first come, first served by quantity (as before).
    depends_on: Dict[str, List[str]] = defaultdict(list)
    link_by: Dict[str, str] = {}                                    # main po -> "serial" | "quantity"
    outside_links: Dict[str, List[Dict[str, Any]]] = defaultdict(list)   # main po -> child links outside the schedule
    by_part: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for p in pos:
        by_part[p["part"]].append(p)
    in_plan = {p["po"] for p in pos}
    # main PCBs with NO child PCB anywhere (no child PO / child POs used up / no serial match): the main PO is scheduled
    # without them = FORCED, the same as a child that is not assigned yet
    missing_child: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    why_text = {"no_child_po": "no open child PO of part {cp}",
                "short": "the open child POs of part {cp} are used up by earlier main POs",
                "no_serial_match": "no child PCB has the same serial number"}

    def no_child(m: Dict[str, Any], cp: Optional[str], n: int, reason: str) -> None:
        missing_child[m["po"]].append({"child_po": None, "child_part": cp, "pcbs": n, "done": 0, "in_progress": 0,
                                       "not_assigned": n, "in_plan": False, "forced": True, "reason": reason})
        warnings.append(f"PO {m['po']} ({m['label']}): {n} main PCB(s) have no child PCB - "
                        + why_text[reason].format(cp=cp or "?")
                        + " - the main PO is scheduled without them (forced). It can only really start when those child "
                          "PCBs are made: release / assign a child PO" + (f" of part {cp}" if cp else "") + ".")

    taken_by_serial: Dict[str, int] = defaultdict(int)             # child po -> PCBs already linked by serial
    for m in pos:
        links = serial_links.get(m["po"], [])
        if not links:
            continue
        link_by[m["po"]] = "serial"
        for l in links:
            taken_by_serial[l["child_po"]] += l["pcbs"]
            if l["child_po"] in in_plan:
                depends_on[m["po"]].append(l["child_po"])
            else:
                outside_links[m["po"]].append(l)
        if serial_unmatched.get(m["po"]):
            no_child(m, child_of.get(m["part"]), serial_unmatched[m["po"]], "no_serial_match")
    for main_pn, child_pn in child_of.items():
        mains = [m for m in by_part.get(main_pn, []) if m["po"] not in link_by and not m.get("locked")]
        childs = by_part.get(child_pn, [])
        if not mains:
            continue
        if not childs:
            for m in mains:
                link_by[m["po"]] = "quantity"
                no_child(m, child_pn, m["qty"], "no_child_po")
            continue
        supply, run = [], 0
        for c in childs:
            free = max(c["qty"] - taken_by_serial.get(c["po"], 0), 0)
            if free:
                supply.append((run, run + free, c["po"]))
                run += free
        need = 0
        for m in mains:
            lo, hi = need, need + m["qty"]
            need = hi
            depends_on[m["po"]] = [cpo for (a, b, cpo) in supply if a < hi and b > lo]
            link_by[m["po"]] = "quantity"
            if hi > run:                                     # the open child POs run out before this main PO
                no_child(m, child_pn, hi - max(run, lo), "short")

    def depth(part: str) -> int:
        d = 0
        while part in child_of and d < 10:
            part, d = child_of[part], d + 1
        return d

    # ---------------- chains: a child PO and the main PO(s) it feeds belong together ----------------
    parent = {p["po"]: p["po"] for p in pos}

    def find(x: str) -> str:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for m_po, c_pos in depends_on.items():
        for c_po in c_pos:
            if c_po in parent and m_po in parent:
                parent[find(c_po)] = find(m_po)
    chain_first: Dict[str, int] = {}
    for p in pos:
        r = find(p["po"])
        chain_first[r] = min(chain_first.get(r, p["idx"]), p["idx"])
    chain_key = {p["po"]: chain_first[find(p["po"])] for p in pos}        # chain = its first PO (load order)
    chain_no = {k: i + 1 for i, k in enumerate(sorted(set(chain_key.values())))}

    # ---------------- schedule (finite capacity, machines shared, down-time skipped) ----------------
    busy: Dict[str, List[Tuple[datetime, datetime, str]]] = defaultdict(list)   # resource -> runs already booked (first-fit gaps)
    bookings: List[Dict[str, Any]] = []                 # every slot booked (saved with the plan: locking an assigned PO)
    po_of_label = {p["label"]: p["po"] for p in pos}
    usage: Dict[str, Dict[date, Dict[str, float]]] = defaultdict(lambda: defaultdict(lambda: defaultdict(float)))
    segments: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    machine_segments: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    runs: Dict[Tuple[str, str], List[datetime]] = {}
    run_list: List[Dict[str, Any]] = []
    po_ready: Dict[str, datetime] = {}
    po_span: Dict[str, List[datetime]] = {}
    route: Dict[str, List[str]] = defaultdict(list)
    delayed_by_downtime: Dict[str, set] = defaultdict(set)

    # placement order: a main PO is placed immediately after the last child PO that feeds it (child, main, child, main ...)
    # - NOT "all children first", which pushed every main behind all the child work on shared machines.
    by_po = {p["po"]: p for p in pos}
    kids = {m: [c for c in cs if c in by_po] for m, cs in depends_on.items()}
    feeds: Dict[str, List[str]] = defaultdict(list)
    for m_po, cs in kids.items():
        for c_po in cs:
            feeds[c_po].append(m_po)
    order: List[Dict[str, Any]] = []
    placed_po: set = set()

    def emit(p: Dict[str, Any]) -> None:
        if p["po"] in placed_po:
            return
        placed_po.add(p["po"])
        for c_po in kids.get(p["po"], []):
            emit(by_po[c_po])
        order.append(p)
        for m_po in feeds.get(p["po"], []):
            if m_po not in placed_po and all(c in placed_po for c in kids[m_po]):
                emit(by_po[m_po])

    for p in sorted(pos, key=lambda x: x["idx"]):
        emit(p)
    handoff: Dict[str, Dict[str, Any]] = {}

    open_batches: Dict[str, List[Dict[str, Any]]] = defaultdict(list)   # station key -> batches already booked (for co-loading)

    def step_windows(segs, step_mins: List[float]):
        """(start, end) of every line step inside a placed line run (the steps run one after the other)."""
        w: Dict[int, Tuple[datetime, datetime]] = {}
        for k, (d, a, b, m) in split_steps(segs, step_mins):
            w[k] = (w[k][0], b) if k in w else (a, b)
        return [w.get(i) for i in range(len(step_mins))]

    def book(st: Station, ready: datetime, minutes: float, one_day: bool = False, dry=None, step_mins=None):
        """First fit on every machine (option) of the station: the earliest start >= ready where the whole run clears the runs
        already booked there and the machine's down-time. The machine that FINISHES first wins.
        one_day = the run must sit inside one free stretch of one working day (SMT LINE, an oven batch).
        dry = bookings of a trial run (estimates) - looked at, but never kept.
        Returns (mi, o, start, end, end_day, pieces, fits_in_one_day, blocked_by)."""
        best = None
        taken = lambda rs: sorted(iv for r in rs for iv in busy[r] + (dry.get(r, []) if dry is not None else []))
        for mi, o in enumerate(st.options):
            per_step = st.kind == "LINE" and step_mins and "line_res" in o
            booked = taken([o["line_res"]] if per_step else o["resources"])
            step_booked = [taken(m) for m in o["step_mids"]] if per_step else []
            s0, first_block = ready, None
            for _ in range(100000):
                if one_day:
                    s, e, eday, segs, same = cal.place_within_day(s0, minutes, st.win, o["blocks"])
                else:
                    s, e, eday, segs = cal.consume(s0, minutes, st.win, o["blocks"])
                    same = True
                clash = next((iv for iv in booked if iv[0] < e and iv[1] > s), None)
                if clash is None and per_step:                    # a step's machine busy during that step -> shift the run
                    for i, win in enumerate(step_windows(segs, step_mins)):
                        c = win and next((iv for iv in step_booked[i] if iv[0] < win[1] and iv[1] > win[0]), None)
                        if c:
                            clash = (c[0], s + (c[1] - win[0]), c[2])
                            break
                if clash is None:
                    break
                if first_block is None:
                    first_block = clash[2]
                s0 = max(clash[1], s0 + timedelta(minutes=1))
            else:
                raise PoGanttError(500, f"No free slot found on {o['name'] or st.name}")
            if best is None or e < best[3]:
                best = (mi, o, s, e, eday, segs, same, first_block)
        return best

    def reserve(o: Dict[str, Any], s: datetime, e: datetime, label: str, dry=None, windows=None) -> None:
        store = busy if dry is None else dry

        def put(r: str, a: datetime, b: datetime) -> None:
            store.setdefault(r, []).append((a, b, label))
            if dry is None:
                bookings.append({"po": po_of_label.get(label, label), "resource": r, "start": _iso(a), "end": _iso(b)})
        if windows is not None and "line_res" in o:                # LINE: the line for the whole run, machines per step
            put(o["line_res"], s, e)
            for mids, win in zip(o["step_mids"], windows):
                for mid in mids:
                    if win:
                        put(mid, win[0], win[1])
            return
        for r in o["resources"]:
            put(r, s, e)

    def add_segment(p: Dict[str, Any], st: Station, row_id: str, mi: int, o: Dict[str, Any], piece, s: datetime, e: datetime,
                    phys: List[Tuple[str, str]], extra: Dict[str, Any]) -> None:
        """One bar of the Gantt (one PO, one day, one machine / step) + the same bar on each machine row."""
        d, a, b, m = piece
        seg = {
            "label": p["label"], "po": p["po"], "part": p["part"], "role": p["role"], "quantity": p["qty"],
            "machine": o["name"], "machine_no": mi, "machines": [mid for mid, _ in phys], "operation": st.name,
            "row_id": row_id, "date": d.isoformat(), "start": _iso(a), "end": _iso(b), "minutes": round(m, 1),
            "run_start": _iso(s), "run_end": _iso(e),
        }
        seg.update(extra)
        segments[st.key].append(seg)
        for mid, nm in phys:
            machine_segments[mid].append({**seg, "machine": mid, "step": nm})
        usage[st.key][d][p["label"]] += m

    def split_steps(segs, step_mins: List[float]):
        """Cut a line run [(day, a, b, minutes)] into its steps, one after the other -> [(step_index, (day, a, b, minutes))]."""
        out, i, left, n = [], 0, step_mins[0], len(step_mins)
        for d, a, b, m in segs:
            while m > 1e-9:
                while left <= 1e-9 and i < n - 1:          # a step with no time: go to the next one
                    i += 1
                    left = step_mins[i]
                use = m if i == n - 1 else min(m, left)    # the last step takes whatever is left (rounding)
                out.append((i, (d, a, a + timedelta(minutes=use), use)))
                a, m, left = a + timedelta(minutes=use), m - use, left - use
        return out

    def place_batches(p: Dict[str, Any], st: Station, parts, ready: datetime, row_id: str, dry=None):
        """Batch process: batch_size PCBs go in together and come out together (one bar per batch).
        70 PCBs / batch 30 -> 30 + 30 + 10. Batches of one PO run side by side on free ovens.
        A batch of the SAME part that still has room, is not started before this PO is ready and does not finish later
        than a new batch would, takes the PCBs instead (co-loading). A trial run (dry) never co-loads.
        Returns (start, end, end_day, machine names, blocked_by)."""
        size = batch_size_for(p["part"], st.step_ids[0])
        per_batch = parts[0][1]                                   # minutes for one batch (time of a batch, not per PCB)
        left, mine, blocked_by = p["qty"], [], None
        while left > 0:
            mins = per_batch + (st.setup if not mine else 0.0)
            mi, o, s, e, eday, segs, same, blocked = book(st, ready, mins, one_day=True, dry=dry)
            join = None
            if dry is None:
                # any part may share an oven batch that still has room (your rule), but only when the PCBs are ready
                # BEFORE the batch starts and joining does not finish later than a batch of its own would
                join = min((b for b in open_batches[st.key]
                            if b["room"] > 0 and b["start"] >= ready and b["end"] <= e),
                           key=lambda b: b["start"], default=None)

                # join = min((b for b in open_batches[st.key]
                #             if b["part"] == p["part"] and b["room"] > 0 and b["start"] >= ready and b["end"] <= e),
                #            key=lambda b: b["start"], default=None)
            if join:
                take = min(left, join["room"])
                join["room"] -= take
                mi, o, s, e, eday, segs = join["mi"], join["o"], join["start"], join["end"], join["eday"], join["segs"]
                together = join["together"]
                for r in o["resources"]:                      # this PO is in that batch too (kept if it gets locked)
                    bookings.append({"po": p["po"], "resource": r, "start": _iso(s), "end": _iso(e)})
            else:
                take = min(left, size)
                reserve(o, s, e, p["label"], dry)
                together = []
                if dry is None:
                    open_batches[st.key].append({"part": p["part"], "room": size - take, "start": s, "end": e, "eday": eday,
                                                 "mi": mi, "o": o, "segs": segs, "together": together})
                    if blocked_by is None:
                        blocked_by = blocked
                    if o["blocks"] and any(a < e and b > ready for a, b in o["blocks"]):
                        delayed_by_downtime[p["po"]].add(st.name)
                    if not same:
                        warnings.append(f"PO {p['po']} ({p['label']}): one {st.name} batch needs {mins / 60:.1f} h, more than "
                                        f"one working day ({st.cap_min / 60:g} h) - the batch is spread over several days")
            together.append({"label": p["label"], "po": p["po"], "qty": take})   # every PO inside this batch (shared list)
            left -= take
            mine.append((mi, o, s, e, eday, segs, take, mins, together))
        if dry is None:
            for k, (mi, o, s, e, eday, segs, take, mins, together) in enumerate(mine, start=1):
                info = {"no": k, "count": len(mine), "qty": take, "size": size, "minutes": round(mins, 1),
                        "start": _iso(s), "end": _iso(e), "together": together}
                for piece in segs:
                    add_segment(p, st, row_id, mi, o, piece, s, e, o["phys"], {"batch": info})
        s_all, e_all = min(b[2] for b in mine), max(b[3] for b in mine)
        last = max(mine, key=lambda b: b[3])
        names = list(dict.fromkeys(b[1]["name"] for b in mine if b[1]["name"]))
        return s_all, e_all, last[4], ", ".join(names), blocked_by

    def run_po(p: Dict[str, Any], ready: datetime, dry=None, first: int = 0, count: Optional[int] = None,
               after: Optional[str] = None, ready0: Optional[datetime] = None):
        """Place a PO through its operations (p["ops"]), one after the other, from `ready`.
        first / count: only these operations (the main loop places one operation at a time).
        dry = None: book it into the schedule. dry = {}: a trial run on top of the schedule (estimate only, nothing kept).
        Returns (start of its first placed operation, when the PO is ready for the next step, the last process name)."""
        ready0 = ready if ready0 is None else ready0
        first_start = None
        if after is None:
            after = "its child PO(s)" if ready > start_dt else "the schedule start"   # what the PO waited for before this process
        ops = list(enumerate(p["ops"], start=1))
        for seq, op in ops[first:(first + count) if count else None]:
            st = stations[op["key"]]
            minutes, parts = op_minutes_and_parts(p, op, st)
            row_id = f"{p['role']}:{st.key}"
            n_seg0 = len(segments[st.key])
            o = None

            if st.mode == "BATCH":
                # -------- batch process: one bar per batch --------
                s, e, eday, machine_text, blocked_by = place_batches(p, st, parts, ready, row_id, dry)
                phys_ids = []
            else:
                # -------- normal process / SMT LINE: the whole PO in one run --------
                step_mins = [parts[i][0] + (st.setup if i == 0 else 0.0) for i in range(len(parts))] if st.kind == "LINE" else None
                mi, o, s, e, eday, segs, same, blocked_by = book(st, ready, minutes, one_day=(st.kind == "LINE" and LINE_IN_ONE_DAY),
                                                                 dry=dry, step_mins=step_mins)
                reserve(o, s, e, p["label"], dry, windows=step_windows(segs, step_mins) if step_mins else None)
                machine_text = o["name"]
                phys_ids = [m for m, _ in o["phys"]]
                if dry is None:
                    if o["blocks"] and any(a < e and b > ready for a, b in o["blocks"]):
                        delayed_by_downtime[p["po"]].add(st.name)
                    if not same:
                        warnings.append(f"PO {p['po']} ({p['label']}): {st.name} needs {minutes / 60:.1f} h, more than one "
                                        f"working day ({st.cap_min / 60:g} h) - the run is spread over several days")
                    if st.kind == "LINE":
                        # the line steps run ONE AFTER THE OTHER (step 1 for the whole PO, then step 2 ...), all inside the day
                        pieces = split_steps(segs, step_mins)
                        for i, name in enumerate(st.steps):
                            mine = [pc for k, pc in pieces if k == i]
                            if not mine:
                                continue
                            step_phys = [(mid, nm) for mid, nm in o["phys"] if nm == name]
                            extra = {"step": name, "step_no": i + 1, "step_count": len(st.steps),
                                     "step_start": _iso(mine[0][1]), "step_end": _iso(mine[-1][2]),
                                     "step_minutes": round(step_mins[i], 1)}
                            if step_phys:
                                extra["machine"] = step_phys[0][0]
                            for piece in mine:
                                add_segment(p, st, row_id, mi, o, piece, s, e, step_phys, extra)
                    else:
                        for piece in segs:
                            add_segment(p, st, row_id, mi, o, piece, s, e, o["phys"], {})

            first_start = s if first_start is None else first_start
            if dry is None:
                # when the PO was ready for this process, and after which step (shown on the bar's hover card)
                for sg in segments[st.key][n_seg0:]:
                    sg["ready"] = {"at": _iso(ready), "after": after}
                # why did the PO wait between "ready for this process" and its start? (shown on the bar's hover card)
                waited = (s - ready).total_seconds() / 60.0
                if waited > 1:
                    # the last run on this machine / line that ended before this one started (not this run itself)
                    prev = max(((iv[0], iv[1], iv[2], r) for r in ((o["resources"] + ([o["line_res"]] if "line_res" in o else []))
                                                                    if o is not None else [])
                                for iv in busy.get(r, [])
                                if ready <= iv[1] <= s and iv[2] != p["label"]),
                               key=lambda iv: (iv[1], o is not None and iv[3] == o.get("line_res")), default=None)
                    who = None
                    if prev:                                       # the line itself, or a machine it shares with another process
                        who = (f"{st.name} busy with PO {prev[2]}" if prev[3] == o.get("line_res") or st.kind != "LINE"
                               else f"machine {prev[3]} (shared with another process) busy with PO {prev[2]}")
                    if st.kind == "LINE" and LINE_IN_ONE_DAY and prev and (s - prev[1]).total_seconds() > 1800:
                        why = (f"{who} until {prev[1]:%d-%m %H:%M}; this run ({minutes / 60:.1f} h) did not "
                               f"fit in the rest of that day - the line run must finish inside one working day")
                    elif blocked_by:
                        why = (f"{who} until {prev[1]:%d-%m %H:%M}" if prev else f"{st.name} busy with PO {blocked_by}")
                    elif o is not None and any(a < s and b > ready for a, b in o["blocks"]):
                        why = "machine down / consumable not available"
                    elif st.kind == "LINE" and LINE_IN_ONE_DAY:
                        why = "the line run must finish inside one working day - it did not fit in what was left of the day"
                    else:
                        why = "outside the working hours of this process (shift end / off day)"
                    for sg in segments[st.key][n_seg0:]:
                        sg["wait"] = {"from": _iso(ready), "hours": round(waited / 60.0, 1), "why": why}
                if seq == 1 and any(c in po_ready for c in depends_on.get(p["po"], [])):   # main PO: how soon after its child?
                    wait_h = max((s - ready0).total_seconds() / 3600.0, 0.0)
                    handoff[p["po"]] = {"child_ready": _iso(ready0), "main_start": _iso(s), "wait_hours": round(wait_h, 1),
                                        "station": st.name, "machine": machine_text, "blocked_by": blocked_by}
                    if wait_h > HANDOFF_WARN_HOURS:
                        warnings.append(f"PO {p['po']} ({p['label']}) starts {wait_h / 24:.1f} days after its child PO "
                                        f"finished: {st.name} is busy" + (f" with PO {blocked_by}" if blocked_by else ""))
                span = runs.setdefault((st.key, p["label"]), [s, e])
                span[0], span[1] = min(span[0], s), max(span[1], e)
                ps = po_span.setdefault(p["po"], [s, e])
                ps[0], ps[1] = min(ps[0], s), max(ps[1], e)
                if row_id not in route[p["po"]]:
                    route[p["po"]].append(row_id)
                run_list.append({"seq": seq, "label": p["label"], "po": p["po"], "part": p["part"], "role": p["role"],
                                 "quantity": p["qty"], "row_id": row_id, "station": st.name, "kind": st.kind,
                                 "flow_step_ids": st.step_ids, "machine": machine_text, "machines": phys_ids,
                                 "start": _iso(s), "end": _iso(e), "minutes": round(minutes, 1)})

            after = st.name
            ready = e                                            # when the PO may enter the next process
            if st.next_day_release:                       # output released at the start of the next working day
                ready = cal.next_start(datetime.combine(eday + timedelta(days=1), time.min), st.win)
            if st.cooldown > 0:
                if st.cd_working_only:
                    ready = cal.consume(ready, st.cooldown, st.win)[1]
                else:
                    ready = ready + timedelta(minutes=st.cooldown)
        return first_start, ready, after

    def outside_child(l: Dict[str, Any], qty: int, from_step: bool) -> Dict[str, Any]:
        """A child PO that is not in this schedule, as a PO for a trial run: its whole flow, or (in process) the rest of
        its flow from the earliest step its PCBs are at."""
        ops = ops_for(l["child_part"])
        if from_step and l["steps"]:
            at = [i for i, op in enumerate(ops) if any(m.flow_step_id in l["steps"] for m in op["steps"])]
            ops = ops[min(at):] if at else ops
        return {"po": l["child_po"], "label": l["child_po"], "part": l["child_part"], "qty": qty, "role": "CHILD", "ops": ops}

    for p in locked_info:
        L = p["lock"]
        for b in L["bookings"]:
            a_, b_ = _parse_dt(b["start"]), _parse_dt(b["end"])
            busy[b["resource"]].append((a_, b_, p["label"]))
            bookings.append({**b, "po": p["po"]})
        for key, segs in L["segments"].items():
            if key not in stations:
                warnings.append(f"PO {p['po']} (locked): process {segs[0].get('operation') or key} is no longer in its flow - "
                                f"its slot is still kept, but not shown")
                continue
            for sg in segs:
                d_ = date.fromisoformat(sg["date"])
                segments[key].append({**sg, "label": p["label"], "row_id": f"{p['role']}:{key}", "locked": True})
                usage[key][d_][p["label"]] += float(sg.get("minutes") or 0)
                a_, b_ = _parse_dt(sg["start"]), _parse_dt(sg["end"])
                span = runs.setdefault((key, p["label"]), [a_, b_])
                span[0], span[1] = min(span[0], a_), max(span[1], b_)
                if f"{p['role']}:{key}" not in route[p["po"]]:
                    route[p["po"]].append(f"{p['role']}:{key}")
        for mid, segs in L["machine_segments"].items():
            for sg in segs:
                machine_segments[mid].append({**sg, "label": p["label"], "locked": True})
        for r in L["runs"]:
            run_list.append({**r, "label": p["label"], "locked": True})
        if L["start"] and L["end"]:
            po_span[p["po"]] = [L["start"], L["end"]]

    child_notes: Dict[str, List[Dict[str, Any]]] = defaultdict(list)   # main po -> what the child outside the plan means
    forced: List[Tuple[Dict[str, Any], Dict[str, Any]]] = []          # (main PO, child link) scheduled without waiting

    # ---------- process by process: always the operation that is ready first (ties: PO priority / load order) ----------
    # A PO is placed one operation at a time. So when PO A finishes its top side on the SMT line at 12:06, PO B (ready since
    # the morning) gets the line at 12:06 - it does not have to wait until PO A has also done its bottom side on the same
    # machines (printer / SPI / pick and place / reflow are mapped to both sides in equipment_details).
    prio = {p["po"]: i for i, p in enumerate(order)}
    waiting_for = {p["po"]: {c for c in depends_on.get(p["po"], []) if c in by_po} for p in order}
    state: Dict[str, Dict[str, Any]] = {}
    heap: List[Tuple[datetime, int, str]] = []

    def release(p: Dict[str, Any]) -> None:
        """All child POs of p are placed (or p has none): p may start."""
        if p.get("locked"):                              # already at its locked slots: ready for its main PO at its end
            ready_at = p["lock"]["end"] or start_dt
            state[p["po"]] = {"next": len(p["ops"]), "ready": ready_at, "ready0": ready_at, "after": None}
            finished(p["po"], ready_at)
            return
        waits = [po_ready[c] for c in depends_on.get(p["po"], []) if c in po_ready]
        child_notes[p["po"]].extend(missing_child.get(p["po"], []))
        for l in outside_links.get(p["po"], []):
            note = {"child_po": l["child_po"], "child_part": l["child_part"], "pcbs": l["pcbs"], "done": l["done"],
                    "in_progress": l["in_progress"], "not_assigned": l["not_assigned"], "in_plan": False}
            if l["in_progress"]:
                # child PCBs are on the floor: the main waits for the rest of the child flow (estimate, nothing booked)
                trial = outside_child(l, l["in_progress"], from_step=True)
                if trial["ops"]:
                    _, est, _ = run_po(trial, max(now, start_dt), dry={})
                    waits.append(est)
                    note["child_ready_estimate"] = _iso(est)
                    warnings.append(f"PO {p['po']} ({p['label']}): {l['in_progress']} child PCB(s) of PO {l['child_po']} are "
                                    f"still in process - estimated done {est:%d-%m-%Y %H:%M}, the main PO waits for that")
            if l["not_assigned"]:
                note["forced"] = True
                forced.append((p, l))
            child_notes[p["po"]].append(note)
        r0 = max([start_dt] + waits)
        state[p["po"]] = {"next": 0, "ready": r0, "ready0": r0, "after": None}
        heapq.heappush(heap, (r0, prio[p["po"]], p["po"]))

    def finished(po: str, ready_at: datetime) -> None:
        po_ready[po] = ready_at
        for m_po in feeds.get(po, []):
            waiting_for[m_po].discard(po)
            if not waiting_for[m_po] and m_po not in state:
                release(by_po[m_po])

    for p in order:
        if not waiting_for[p["po"]]:
            release(p)
    while heap:
        _, _, po = heapq.heappop(heap)
        p, stt = by_po[po], state[po]
        if stt["next"] >= len(p["ops"]):
            finished(po, stt["ready"])
            continue
        _, stt["ready"], stt["after"] = run_po(p, stt["ready"], first=stt["next"], count=1, after=stt["after"], ready0=stt["ready0"])
        stt["next"] += 1
        if stt["next"] < len(p["ops"]):
            heapq.heappush(heap, (stt["ready"], prio[po], po))
        else:
            finished(po, stt["ready"])
    for p in order:                                       # safety: a PO that could not be released (a loop in the links)
        if p["po"] not in state:
            release(p)
            if not p.get("locked"):
                _, po_ready[p["po"]], _ = run_po(p, state[p["po"]]["ready"])

    # child not assigned -> main was scheduled without waiting. What if the child is assigned on the first working day?
    for p, l in forced:
        trial = outside_child(l, l["not_assigned"], from_step=False)
        note = next(n for n in child_notes[p["po"]] if n["child_po"] == l["child_po"])
        main_start = po_span[p["po"]][0]
        if not trial["ops"]:
            warnings.append(f"PO {p['po']} ({p['label']}): child PO {l['child_po']} is not assigned yet and its part "
                            f"{l['child_part']} has no flow - main PO scheduled without waiting for it (forced)")
            continue
        c_start, c_end, _ = run_po(trial, start_dt, dry={})
        note.update({"assign_on": _iso(c_start), "child_done": _iso(c_end), "main_can_start": _iso(c_end),
                     "main_planned_start": _iso(main_start)})
        warnings.append(
            f"PO {p['po']} ({p['label']}): child PO {l['child_po']} ({l['not_assigned']} PCB(s)) is not assigned yet - the "
            f"main PO is scheduled without waiting for it (forced, from {main_start:%d-%m-%Y %H:%M}). If child PO "
            f"{l['child_po']} is assigned on {c_start:%d-%m-%Y}, it is done by {c_end:%d-%m-%Y %H:%M} and PO {p['po']} "
            f"can start from {c_end:%d-%m-%Y %H:%M}"
            + (" - until then its PCBs cannot be assigned (the child must be complete)." if c_end > main_start else "."))

    for part, names in missing_time.items():
        uniq = list(dict.fromkeys(names))
        warnings.append(f"Part {part}: no process time for {len(uniq)} step(s) "
                        f"[{', '.join(uniq[:6])}{'...' if len(uniq) > 6 else ''}] - {FALLBACK_MINUTES:g} min used")
    if delayed_by_downtime:
        warnings.append(f"{len(delayed_by_downtime)} PO(s) were moved around machine breakdowns / maintenance / "
                        f"consumable shortages")

    # ---------------- days ----------------
    used_days = [d for per_day in usage.values() for d in per_day]
    last_day = max(used_days + [start_day])
    days, day_no, working_nos = [], {}, 0
    d = start_day
    while d <= last_day:
        if cal.factor(d) > 0:
            working_nos += 1
            day_no[d] = working_nos
            days.append({"working_day_no": working_nos, "date": d.isoformat(), "weekday": d.strftime("%a"),
                         "is_holiday": False, "off_reason": None})
        elif show_holidays:
            days.append({"working_day_no": None, "date": d.isoformat(), "weekday": d.strftime("%a"),
                         "is_holiday": True, "off_reason": cal.off_reason(d)})
        d += timedelta(days=1)

    # ---------------- rows: CHILD section first, then MAIN; each in flow order ----------------
    def part_sort(pn: str):
        prod = products.get(pn)
        return (_key(prod.product_type_name) if prod else "", pn)

    part_order = sorted({p["part"] for p in pos}, key=part_sort)
    section_rows: Dict[str, List[str]] = {r: [] for r in ROLES}
    parts_by_row: Dict[Tuple[str, str], List[str]] = defaultdict(list)
    for part in part_order:
        role = role_of(part)
        lst, at = section_rows[role], -1
        for op in ops_for(part):                              # merge the flows of several parts in one section
            if op["key"] in lst:
                at = lst.index(op["key"])
            else:
                at += 1
                lst.insert(at, op["key"])
            if part not in parts_by_row[(role, op["key"])]:
                parts_by_row[(role, op["key"])].append(part)
    roles_of_station: Dict[str, set] = defaultdict(set)
    for role, keys in section_rows.items():
        for k in keys:
            roles_of_station[k].add(role)

    def order_labels(labels) -> List[str]:
        return sorted(labels, key=lambda x: label_idx.get(x, 0))

    def cells_for(key: str, role: str) -> List[Dict[str, Any]]:
        s, out = stations[key], []
        for dd, no in day_no.items():
            u = usage.get(key, {}).get(dd)
            if not u:
                continue
            labels = [lb for lb in u if label_role.get(lb) == role]
            if not labels:
                continue
            out.append({"working_day_no": no, "date": dd.isoformat(), "pos": order_labels(labels),
                        "color": ORANGE if len(labels) >= 2 else BLUE,
                        "minutes_used": round(sum(u[lb] for lb in labels), 1),
                        "station_minutes_used": round(sum(u.values()), 1),
                        "capacity_minutes": round(len(s.options) * s.cap_min * cal.factor(dd), 1)})
        return out

    def runs_for(key: str, role: str) -> List[Dict[str, str]]:
        out = [(lb, v) for (k, lb), v in runs.items() if k == key and label_role.get(lb) == role]
        return [{"label": lb, "start": _iso(v[0]), "end": _iso(v[1])}
                for lb, v in sorted(out, key=lambda kv: (kv[1][0], label_idx.get(kv[0], 0)))]

    def station_downtime(s: Station) -> List[Dict[str, Any]]:
        step_of = {m: nm for m, nm in s.real_machines}                 # SMT LINE: which step the machine belongs to
        evs = [_dt_json({**e, "machine_name": machine_info.get(mid, {}).get("name", mid),
                         "step": step_of[mid] if s.kind == "LINE" else None})
               for mid in dict.fromkeys(m for m, _ in s.real_machines) for e in downtime.get(mid, [])]
        sname = dict(zip(s.step_ids, s.steps)) if s.kind == "LINE" else {}
        lane_of = {r: i for i, o in enumerate(s.options) for r in o["resources"]}
        for e in evs:
            e["lane"] = lane_of.get(e["machine"])                        # the machine's own lane in the row
        evs += [_dt_json({**e, "process": s.name, "step": sname.get(e["stage_id"]), "lane": None}) for e in s.material]
        return sorted(evs, key=lambda e: e["start"])

    rows: List[Dict[str, Any]] = []
    for role in ROLES:
        for key in section_rows[role]:
            s = stations[key]
            parts = parts_by_row[(role, key)]
            real = list(dict.fromkeys(m for m, _ in s.real_machines))
            rows.append({
                "row_id": f"{role}:{key}", "station_id": key, "name": s.name, "kind": s.kind, "section": role,
                "role": role, "part_number": parts[0], "part_numbers": parts,
                "flow_step_ids": s.step_ids, "steps": s.steps,
                "shifts": s.shifts, "mins_per_shift": int(s.hps * 60), "machines": len(s.options),
                "machine_names": s.machines, "has_machine": bool(real), "real_machines": real,
                "real_machine_names": [machine_info[m]["name"] for m in real],
                "operators_per_shift": s.operators, "process_mode": s.mode, "is_batch": s.mode == "BATCH",
                "batch_why": batch_rule.get(s.step_ids[0], (None, ""))[1] if s.kind != "LINE" else None,
                "batch_size": batch_size_for(parts[0], s.step_ids[0]) if s.mode == "BATCH" else None,
                "day_start_hour": round(s.win.start_h, 2), "day_end_hour": round(s.win.start_h + s.win.cap_min / 60.0, 2),
                "break": ({"start": _hours_to_hm(s.win.brk_h), "minutes": s.win.brk_min} if s.win.brk_h is not None else None),
                "working_hours": round(s.cap_min / 60.0, 2), "shift_source": s.shift_source,
                "workcenter": s.workcenter, "workcenter_name": s.wc_name,
                "lanes": [{"no": i, "name": o["name"] or (s.name if len(s.options) == 1 else f"#{i + 1}"),
                           "machines": [mid for mid, _ in o["phys"]],
                           "virtual": any(machine_info.get(mid, {}).get("virtual") for mid, _ in o["phys"])}
                          for i, o in enumerate(s.options)],
                "shared_with": [r for r in ROLES if r != role and r in roles_of_station[key]],
                "cells": cells_for(key, role), "po_runs": runs_for(key, role),
                "segments": [sg for sg in segments.get(key, []) if sg["role"] == role],
                "downtime": station_downtime(s),
            })

    # ---------------- machine rows (PO on Machines), grouped by process in flow order ----------------
    machine_rows: List[Dict[str, Any]] = []
    placed: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        s = stations[row["station_id"]]
        for mid, step in s.real_machines:
            if mid in placed:
                if s.name not in placed[mid]["processes"]:
                    placed[mid]["processes"].append(s.name)
                if row["role"] not in placed[mid]["roles"]:
                    placed[mid]["roles"].append(row["role"])
                continue
            info = machine_info.get(mid, {"name": mid})
            segs = sorted(machine_segments.get(mid, []), key=lambda x: x["start"])
            mr = {
                "row_id": f"M:{mid}", "machine_id": mid, "name": info.get("name") or mid, "eqpt_no": info.get("eqpt_no"),
                "make": info.get("make"), "model": info.get("model"), "workcenter": info.get("workcenter"),
                "group": s.key, "group_name": s.name, "group_kind": s.kind, "step": step if s.kind == "LINE" else None,
                "processes": [s.name], "roles": [row["role"]], "shifts": s.shifts,
                "day_start_hour": round(s.win.start_h, 2), "day_end_hour": round(s.win.start_h + s.win.cap_min / 60.0, 2),
                "is_batch": s.mode == "BATCH",
                "segments": segs, "downtime": [_dt_json(e) for e in downtime.get(mid, [])],
                # a batch shared by 2 POs is 2 bars at the same time - count the oven time once
                "busy_minutes": round(sum({(x["start"], x["end"]): x["minutes"] for x in segs}.values()), 1),
            }
            placed[mid] = mr
            machine_rows.append(mr)
    manual_processes = [r["name"] for r in rows if not r["has_machine"]]
    if manual_processes:
        warnings.append("No machine mapped in equipment_details for: " + ", ".join(
            dict.fromkeys(f"{r['name']} (step {', '.join(str(x) for x in r['flow_step_ids'])})" for r in rows if not r["has_machine"])))

    for s in stations.values():
        for e in s.material:
            if e["start"].date() > last_day:                 # years away - not relevant for this schedule
                continue
            warnings.append(f"Consumable not available - {s.name} does not run from {e['start']:%d-%m-%Y %H:%M} to "
                            f"{e['end']:%d-%m-%Y %H:%M}: {e['note']}")

    # most important first: forced main POs, consumable shortages, children still in process
    first = ("is not assigned yet", "have no child PCB", "Consumable not available", "still in process", "Breakdown repair waits")
    warnings.sort(key=lambda w: next((i for i, k in enumerate(first) if k in w), len(first)))

    all_down = [_dt_json({**e, "machine_name": machine_info.get(mid, {}).get("name", mid)})
                for mid in placed for e in downtime.get(mid, [])]

    wins = [s.win for s in stations.values()] or [default_win]
    day_start = min(w.start_h for w in wins)
    day_end = max(w.start_h + w.cap_min / 60.0 for w in wins)
    line_text = "; ".join(f"{g} = {', '.join(n)}" for g, n in LINE_GROUPS.items()) or "none configured"
    wd = ["Mondays", "Tuesdays", "Wednesdays", "Thursdays", "Fridays", "Saturdays", "Sundays"]
    off_text = ", ".join([wd[i] for i in WEEKLY_OFF_DAYS]
                         + ([" and ".join(f"{n}{'st' if n == 1 else 'nd' if n == 2 else 'rd' if n == 3 else 'th'}"
                                          for n in ALT_SATURDAYS_OFF) + " Saturdays"] if ALT_SATURDAYS_OFF else [])) or "none"
    win_text = sorted({f"{_hours_to_hm(s.win.start_h)} + {s.cap_min / 60:g} h ({s.shift_source})" for s in stations.values()})
    assumptions = [
        f"Scheduling starts {start_dt:%d-%m-%Y %H:%M}" + (" (the moment the schedule was made)." if start_at is None and start_date is None else "."),
        "Child / main comes from product_type_master (sub product type), else PcbData.Type (e.g. OCTA-CHILD); a main part is "
        "fed by the child part of the same product type, else bom_items, else the extra links in the settings.",
        "Each part follows its flow from product_workflow_mapping (step sequence), else part_process_time in step order. "
        "Linked child / main POs are scheduled as one chain; a main PO starts after the child PO(s) that feed it are finished.",
        "Child -> main link by SERIAL number first (PcbData.serialNo, the same check as PCB assignment): the main PCB needs the "
        "child PCB with the same serial. Main POs without a serial match use first come, first served by quantity.",
        "Child PO not in this schedule: PCBs done -> no wait; in process (pcb_assignment.current_step_id) -> the main waits for "
        "the estimated end of the rest of the child flow; NOT assigned -> the main is scheduled without waiting (forced) and "
        "the warning says on which day the child must be assigned and from when the main can really start.",
        "Unit of work is the whole PO quantity; a PO moves through its processes as a block.",
        f"Lines ({line_text}): the steps run one after the other (step 1 for the whole PO, then step 2 ...); line time = sum "
        "of the step times. " + ("A line run must fit inside one working day - if it does not fit in what is left of a day "
                                 "it starts the next working day." if LINE_IN_ONE_DAY else "A line run may continue the next day."),
        "Machines come from equipment_details; the same machine serving several processes is shared between them.",
        "Machine breakdowns (machine_breakdown_logs: until ready date, else + downtime hours, else open = "
        f"{OPEN_BREAKDOWN_HOURS:g} h from now) and pending preventive maintenance (maintenance_schedules: the whole day) "
        "block the machine.",
        "Spares (inventorty_spares): an open breakdown whose machine has a spare out of stock lasts at least the spare's "
        f"procurement lead time (default {DEFAULT_SPARE_LEAD_DAYS} d). A running machine is not blocked by a missing spare (warning only).",
        "Consumables (consumables, by process): out of stock or past shelf life -> the process (all its machines, or the "
        f"process without machine) is blocked for {CONSUMABLE_RESTOCK_DAYS} days; stock that expires blocks it from the day "
        "after expiry. Stock is checked as available yes / no (the table has no use per PCB). Low stock = warning.",
        "Capacity per process from SAP (sap_workcenter_capacity) through process_flow_master.workcenter_code "
        "(else product_plant_workcenter_routing): number_of_individuals = machines (one lane each, batches run side by side).",
        "Working hours a day per process: work centre operating_time, else its shift end - shift start minus "
        f"{BREAK_MINUTES:g} min break" + (f" (break at {_hours_to_hm(BREAK_START)})" if BREAK_START is not None else
                                           " (taken off the end of the shift)")
        + "; without a work centre: the active shifts of shift_definition, else the fallback settings. Used here: "
        + "; ".join(win_text) + ".",
        "POs whose PCBs all have a status in " + ", ".join(sorted(PCB_OPEN_STATUSES)) + " (PcbData) are scheduled.",
        f"Off days: {off_text}, public holidays and calendar 'Holiday' exceptions; 'Working' reopens a day, 'Half-Day' halves it.",
        f"Time per unit = {'actual' if time_source == 'actual' else 'SAP'} time (fallback to the other, routing, stage_capacity) "
        "+ machine hours of part_process_time.",
        "Batch processes (process_type.process_type_batch" + (", or the name contains " + " / ".join(BATCH_NAME_KEYWORDS)
                                                              if BATCH_NAME_KEYWORDS else "") + "): batch size PCBs go in "
        "together and come out together - e.g. 70 PCBs / batch 30 = 3 batches (30, 30, 10), each one bar, run on free "
        "machines side by side. A batch with room left takes PCBs of another PO when they are ready before it starts. "
        f"Batch size = part_process_time.batch_size, else stage_schedule_config.batch_size, else {DEFAULT_BATCH_SIZE}.",
        f"Plant filter: only POs, machines and process times of plant {plant or '(all)'}.",
        "Operators per shift is informational; it does not limit the schedule.",
    ]
    if locked_info:
        assumptions.append(f"{len(locked_info)} PO(s) already assigned from a saved plan keep their slots (locked); "
                           "the other POs are scheduled around them.")
    return {
        "meta": {
            "plant": plant, "number_of_pos": len(pos), "locked_pos": len(locked_info),
            "start_date": start_day.isoformat(), "finish_date": last_day.isoformat(),
            "working_days": working_nos, "time_source": time_source, "label_mode": label_mode,
            "generated_at": _iso(now),
            "params": {"plant": plant, "production_order": [p["po"] for p in pos] if explicit else None,
                       "start_date": start_date.isoformat() if start_date else None, "time_source": time_source,
                       "label_mode": label_mode, "start_at": _iso(start_dt)},
            "start_at": _iso(start_dt),
            "day_window": {"start_hour": round(day_start, 2), "end_hour": round(day_end, 2)},
            "calendar": {"weekly_off_days": list(WEEKLY_OFF_DAYS), "alt_saturdays_off": list(ALT_SATURDAYS_OFF)},
            "line_groups": {g: list(n) for g, n in LINE_GROUPS.items()},
            "machines_down": len({e["machine"] for e in all_down}),
            "downtime_events": len(all_down),
            "manual_processes": manual_processes,
            "material_shortages": [_dt_json({**e, "process": s.name}) for s in stations.values() for e in s.material
                                   if e["start"].date() <= last_day],
            "pos": [{"label": p["label"], "production_order": p["po"], "part_number": p["part"], "role": p["role"],
                     "quantity": p["qty"], "depends_on": depends_on.get(p["po"], []), "handoff": handoff.get(p["po"]), "route": route[p["po"]],
                     "chain": chain_no[chain_key[p["po"]]],
                     "link_by": link_by.get(p["po"]),                         # serial | quantity | None (not a main PO)
                     "child_outside": child_notes.get(p["po"], []),           # child POs not in this schedule
                     "forced": any(n.get("forced") for n in child_notes.get(p["po"], [])),
                     "moved_by_downtime": sorted(delayed_by_downtime.get(p["po"], [])),
                     "locked": bool(p.get("locked")),
                     "lock": ({k: p["lock"][k] for k in ("version_id", "version_name", "reference", "locked_at", "locked_by")}
                              if p.get("locked") else None),
                     "start": _iso(po_span[p["po"]][0]), "end": _iso(po_span[p["po"]][1])} for p in pos],
        },
        "days": days, "stations": rows, "machines": machine_rows, "downtime": all_down, "runs": run_list,
        "bookings": bookings,
        "warnings": warnings, "assumptions": assumptions,
    }


# --------------------------------------------------------------------------------------
# Saved plans
# --------------------------------------------------------------------------------------
class PlanSave(BaseModel):
    """Save the schedule as a plan version. base_version_id given -> a new revision of that plan (REV02, REV03 ...);
    else a new plan (REV01). The name is made automatically: <PLAN_NAME_PREFIX>_<first day>-<last day>_REVnn."""
    name: Optional[str] = None                 # optional plan name for a NEW plan (default: automatic)
    plan_name: Optional[str] = None            # same as name
    base_version_id: Optional[int] = None      # revise this saved version
    remarks: Optional[str] = None
    set_baseline: bool = True                  # the saved version becomes the current plan of the plant
    created_by: Optional[str] = None
    plant: Optional[str] = None
    production_order: Optional[List[str]] = None
    start_at: Optional[datetime] = None        # exact start (default: now)
    start_date: Optional[date] = None          # legacy: from the start of that day
    time_source: str = "actual"
    label_mode: str = "po"
    shift_start: Optional[float] = None        # not used any more


def _auto_plan_name(start: date, finish: date) -> str:
    rng = f"{start:%d%b%Y}" if start == finish else f"{start:%d%b%Y}-{finish:%d%b%Y}"
    return f"{PLAN_NAME_PREFIX}_{rng}" if PLAN_NAME_PREFIX else rng


def _versions(db: Session, ids) -> Dict[int, SchedulePlanVersion]:
    ids = [i for i in ids if i is not None]
    if not ids:
        return {}
    return {v.version_id: v for v in db.query(SchedulePlanVersion).filter(SchedulePlanVersion.version_id.in_(ids)).all()}


def _version_json(v: Optional[SchedulePlanVersion]) -> Dict[str, Any]:
    if v is None:
        return {"plan_id": None, "version_id": None, "version_no": None, "previous_version_id": None,
                "plan_name": None, "version_name": None, "reference": None, "plan_reference": None}
    return {"plan_id": v.plan_id, "version_id": v.version_id, "version_no": v.version_no,
            "previous_version_id": v.previous_version_id, "plan_name": v.plan_name, "version_name": v.version_name,
            "reference": v.reference, "plan_reference": v.plan_reference}


def _plan_header(p: SchedulePlan, v: Optional[SchedulePlanVersion] = None) -> Dict[str, Any]:
    return {"id": p.id, "name": p.name, "plant": p.plant_code, "is_baseline": bool(p.is_baseline), "status": p.status,
            "time_source": p.time_source, "label_mode": p.label_mode,
            "start_date": p.start_date.isoformat() if p.start_date else None,
            "finish_date": p.finish_date.isoformat() if p.finish_date else None,
            "number_of_pos": p.number_of_pos, "working_days": p.working_days, "remarks": p.remarks,
            "created_by": p.created_by, "created_at": _iso(p.created_at), "params": p.params, **_version_json(v)}


def _without_locked(result: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
    """The POs already assigned from an earlier plan (locked) blocked their slots while this schedule was built, but they
    belong to that earlier plan: take them out of what is saved for the new plan."""
    meta = result["meta"]
    locked = {p["production_order"] for p in meta.get("pos", []) if p.get("locked")}
    if not locked:
        return result, []
    keep = lambda sg: sg.get("po") not in locked
    out = dict(result)
    out["stations"] = [r for r in ({**r, "segments": [sg for sg in r.get("segments", []) if keep(sg)]}
                                   for r in result.get("stations", [])) if r["segments"] or r.get("downtime")]
    out["machines"] = [{**m, "segments": [sg for sg in m.get("segments", []) if keep(sg)]} for m in result.get("machines", [])]
    out["runs"] = [r for r in result.get("runs", []) if r.get("po") not in locked]
    out["bookings"] = [b for b in result.get("bookings", []) if b.get("po") not in locked]
    pos = [p for p in meta.get("pos", []) if p["production_order"] not in locked]
    starts = [r["start"] for r in out["runs"]]
    ends = [r["end"] for r in out["runs"]]
    m2 = {**meta, "pos": pos, "number_of_pos": len(pos), "locked_pos": 0,
          "excluded_assigned_pos": sorted(locked)}
    if starts:
        m2["start_date"], m2["finish_date"] = min(starts)[:10], max(ends)[:10]
    out["meta"] = m2
    return out, sorted(locked)


def save_plan(db: Session, body: PlanSave) -> Dict[str, Any]:
    """Build the schedule again with the same inputs (so what is stored is consistent) and store it as a NEW version.
    Earlier versions are never changed. POs already assigned from an earlier plan are NOT part of the new plan."""
    ensure_plan_tables(db.get_bind())
    result = build_po_gantt(db, body.production_order, body.plant, body.start_date, body.time_source,
                            body.label_mode, True, start_at=body.start_at)
    result, excluded = _without_locked(result)
    meta = result["meta"]
    if not meta["pos"]:
        raise PoGanttError(400, "Nothing new to save: every PO of this schedule is already assigned from an earlier plan")
    now = datetime.now()
    sd, fd = date.fromisoformat(meta["start_date"]), date.fromisoformat(meta["finish_date"])
    if body.base_version_id:
        base = db.query(SchedulePlanVersion).filter(SchedulePlanVersion.version_id == body.base_version_id).first()
        if base is None:
            raise PoGanttError(404, f"Plan version {body.base_version_id} not found")
        plan_id, prev = base.plan_id, base.version_id
        no = (db.query(func.max(SchedulePlanVersion.version_no)).filter(SchedulePlanVersion.plan_id == plan_id).scalar() or 0) + 1
        plan_name, plan_ref = base.plan_name, base.plan_reference
    else:
        plan_id, prev, no = None, None, 1
        plan_name = (body.plan_name or body.name or "").strip() or _auto_plan_name(sd, fd)
        plan_ref = _next_plan_reference(db, now.year)
    version_name = f"{plan_name}_REV{no:02d}"
    reference = f"{plan_ref}-REV-{no:02d}"
    if body.set_baseline:
        q = db.query(SchedulePlan).filter(SchedulePlan.is_baseline.is_(True))
        q = q.filter(SchedulePlan.plant_code == body.plant) if body.plant else q.filter(SchedulePlan.plant_code.is_(None))
        q.update({SchedulePlan.is_baseline: False}, synchronize_session=False)
    plan = SchedulePlan(
        name=version_name, plant_code=body.plant, is_baseline=bool(body.set_baseline), status="SAVED",
        time_source=body.time_source, label_mode=body.label_mode, start_date=sd, finish_date=fd,
        number_of_pos=meta["number_of_pos"], working_days=meta["working_days"], params=meta["params"],
        snapshot=result, remarks=body.remarks, created_by=body.created_by, created_at=now,
    )
    db.add(plan)
    db.flush()
    ver = SchedulePlanVersion(version_id=plan.id, plan_id=plan_id or plan.id, version_no=no, previous_version_id=prev,
                              plan_name=plan_name, version_name=version_name, plan_reference=plan_ref,
                              reference=reference, created_at=now, created_by=body.created_by)
    db.add(ver)
    db.add_all([SchedulePlanItem(
        plan_id=plan.id, seq=r["seq"], production_order=r["po"], part_number=r["part"], label=r["label"],
        role=r["role"], quantity=r["quantity"], row_id=r["row_id"], station_name=r["station"], station_kind=r["kind"],
        flow_step_ids=r["flow_step_ids"], machine=r["machine"], machines=r["machines"],
        planned_start=datetime.strptime(r["start"], ISO), planned_end=datetime.strptime(r["end"], ISO),
        run_minutes=r["minutes"]) for r in result["runs"]])
    db.commit()
    return {"plan": _plan_header(plan, ver), "items": len(result["runs"]), "excluded_assigned_pos": excluded}


def list_plans(db: Session, plant: Optional[str]) -> Dict[str, Any]:
    """Every saved version (newest first) with its Plan_ID / Version_ID / Previous_Version_ID, name and reference."""
    use_settings(db)
    q = db.query(SchedulePlan.id, SchedulePlan.name, SchedulePlan.plant_code, SchedulePlan.is_baseline,
                 SchedulePlan.status, SchedulePlan.start_date, SchedulePlan.finish_date, SchedulePlan.number_of_pos,
                 SchedulePlan.working_days, SchedulePlan.created_by, SchedulePlan.created_at, SchedulePlan.remarks,
                 SchedulePlan.time_source)
    if plant:
        q = q.filter(SchedulePlan.plant_code == plant)
    rows = q.order_by(SchedulePlan.created_at.desc(), SchedulePlan.id.desc()).all()
    vers = _versions(db, [r.id for r in rows])
    latest: Dict[int, int] = {}
    for v in vers.values():
        latest[v.plan_id] = max(latest.get(v.plan_id, 0), v.version_no)
    locks = defaultdict(int)
    for (vid,) in db.query(SchedulePoLock.version_id).filter(SchedulePoLock.released_at.is_(None)).all():
        locks[vid] += 1
    out = []
    for r in rows:
        v = vers.get(r.id)
        out.append({"id": r.id, "name": r.name, "plant": r.plant_code, "is_baseline": bool(r.is_baseline),
                    "status": r.status, "start_date": r.start_date.isoformat() if r.start_date else None,
                    "finish_date": r.finish_date.isoformat() if r.finish_date else None,
                    "number_of_pos": r.number_of_pos, "working_days": r.working_days, "created_by": r.created_by,
                    "created_at": _iso(r.created_at), "remarks": r.remarks, "time_source": r.time_source,
                    "is_latest_version": bool(v and latest.get(v.plan_id) == v.version_no),
                    "locked_pos": locks.get(r.id, 0), **_version_json(v)})
    return {"plans": out, "naming": {"plan_name_prefix": PLAN_NAME_PREFIX, "reference_prefix": PLAN_REF_PREFIX}}


def _get_plan(db: Session, plan_id: int) -> SchedulePlan:
    ensure_plan_tables(db.get_bind())
    p = db.query(SchedulePlan).filter(SchedulePlan.id == plan_id).first()
    if not p:
        raise PoGanttError(404, f"Saved plan {plan_id} not found")
    return p


def set_baseline(db: Session, plan_id: int) -> Dict[str, Any]:
    p = _get_plan(db, plan_id)
    q = db.query(SchedulePlan).filter(SchedulePlan.is_baseline.is_(True), SchedulePlan.id != p.id)
    q = q.filter(SchedulePlan.plant_code == p.plant_code) if p.plant_code else q.filter(SchedulePlan.plant_code.is_(None))
    q.update({SchedulePlan.is_baseline: False}, synchronize_session=False)
    p.is_baseline = True
    db.commit()
    return {"plan": _plan_header(p, _versions(db, [p.id]).get(p.id))}


def delete_plan(db: Session, plan_id: int) -> Dict[str, Any]:
    """Only the newest version of a plan can be deleted, and only while no PO is assigned (locked) from it:
    the version history stays complete."""
    p = _get_plan(db, plan_id)
    v = _versions(db, [p.id]).get(p.id)
    if v is not None:
        newer = db.query(SchedulePlanVersion).filter(SchedulePlanVersion.plan_id == v.plan_id,
                                                     SchedulePlanVersion.version_no > v.version_no).first()
        if newer is not None:
            raise PoGanttError(409, f"{v.version_name} has a later version ({newer.version_name}) - earlier versions are kept")
    if db.query(SchedulePoLock).filter(SchedulePoLock.version_id == p.id, SchedulePoLock.released_at.is_(None)).first():
        raise PoGanttError(409, f"PCBs were assigned from {p.name} - it cannot be deleted")
    db.query(SchedulePlanItem).filter(SchedulePlanItem.plan_id == p.id).delete(synchronize_session=False)
    db.query(SchedulePlanVersion).filter(SchedulePlanVersion.version_id == p.id).delete(synchronize_session=False)
    db.delete(p)
    db.commit()
    return {"deleted": plan_id}


def _current_plans(db: Session, plant: Optional[str]) -> List[SchedulePlan]:
    """The plan in force for each plant: its baseline, else its newest saved version."""
    q = db.query(SchedulePlan.id, SchedulePlan.plant_code)
    if plant:
        q = q.filter(SchedulePlan.plant_code == plant)
    picked: Dict[Optional[str], int] = {}
    for r in q.order_by(SchedulePlan.is_baseline.desc(), SchedulePlan.created_at.desc(), SchedulePlan.id.desc()).all():
        picked.setdefault(r.plant_code, r.id)
    plans = db.query(SchedulePlan).filter(SchedulePlan.id.in_(list(picked.values()))).all() if picked else []
    return sorted(plans, key=lambda p: (p.plant_code or ""))


# --------------------------------------------------------------------------------------
# Slot locks: a PO whose PCBs were assigned from a saved plan keeps that plan's slots
# --------------------------------------------------------------------------------------
class LockBody(BaseModel):
    production_order: List[str]
    version_id: Optional[int] = None           # the plan version the PCBs were assigned from (None = current plan)
    plant: Optional[str] = None
    locked_by: Optional[str] = None


def _snapshot_pos(snap: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    return {m["production_order"]: m for m in (snap or {}).get("meta", {}).get("pos", [])}


def lock_pos(db: Session, body: LockBody) -> Dict[str, Any]:
    use_settings(db)
    plans = [_get_plan(db, body.version_id)] if body.version_id else _current_plans(db, body.plant)
    if not plans:
        raise PoGanttError(404, "No saved plan - save a plan on the Production Schedule page first")
    pos_of = [(p, _snapshot_pos(p.snapshot)) for p in plans]
    now = datetime.now()
    locked, skipped = [], []
    for raw in body.production_order:
        po = _norm(raw) or str(raw)
        plan = next((p for p, m in pos_of if po in m), None)
        if plan is None:
            skipped.append({"production_order": raw, "why": "not in the saved plan"})
            continue
        active = db.query(SchedulePoLock).filter(SchedulePoLock.production_order == po,
                                                 SchedulePoLock.released_at.is_(None)).all()
        if any(a.version_id == plan.id for a in active):
            locked.append({"production_order": po, "version_id": plan.id, "already": True})
            continue
        for a in active:
            a.released_at, a.released_by = now, f"re-assigned from plan {plan.id}"
        db.add(SchedulePoLock(version_id=plan.id, production_order=po, plant_code=plan.plant_code,
                              locked_at=now, locked_by=body.locked_by))
        locked.append({"production_order": po, "version_id": plan.id, "already": False})
    db.commit()
    vers = _versions(db, [x["version_id"] for x in locked])
    for x in locked:
        v = vers.get(x["version_id"])
        x.update({"version_name": v.version_name if v else None, "reference": v.reference if v else None})
    return {"locked": locked, "skipped": skipped}


def list_locks(db: Session, plant: Optional[str]) -> Dict[str, Any]:
    ensure_plan_tables(db.get_bind())
    q = db.query(SchedulePoLock).filter(SchedulePoLock.released_at.is_(None))
    if plant:
        q = q.filter(or_(SchedulePoLock.plant_code == plant, SchedulePoLock.plant_code.is_(None)))
    rows = q.order_by(SchedulePoLock.locked_at.desc()).all()
    vers = _versions(db, [r.version_id for r in rows])
    return {"locks": [{"production_order": r.production_order, "version_id": r.version_id, "plant": r.plant_code,
                       "locked_at": _iso(r.locked_at), "locked_by": r.locked_by,
                       "version_name": vers[r.version_id].version_name if r.version_id in vers else None,
                       "reference": vers[r.version_id].reference if r.version_id in vers else None} for r in rows]}


def unlock_po(db: Session, po: str, released_by: Optional[str]) -> Dict[str, Any]:
    ensure_plan_tables(db.get_bind())
    n = 0
    for r in db.query(SchedulePoLock).filter(SchedulePoLock.production_order == (_norm(po) or po),
                                             SchedulePoLock.released_at.is_(None)).all():
        r.released_at, r.released_by = datetime.now(), released_by
        n += 1
    db.commit()
    return {"production_order": po, "released": n}


def _bookings_from_segments(snap: Dict[str, Any], po: str) -> List[Dict[str, Any]]:
    """Plans saved before bookings were stored: rebuild the slots of a PO from its bars."""
    seen, out = set(), []

    def add(r, a, b):
        if r and a and b and (r, a, b) not in seen:
            seen.add((r, a, b))
            out.append({"po": po, "resource": r, "start": a, "end": b})
    for row in snap.get("stations", []):
        key = row.get("station_id") or str(row.get("row_id", "")).split(":", 1)[-1]
        for sg in row.get("segments", []):
            if sg.get("po") != po:
                continue
            batch = sg.get("batch") or {}
            a, b = batch.get("start") or sg.get("run_start"), batch.get("end") or sg.get("run_end")
            if row.get("kind") == "LINE":
                add(f"LINE-{key}-{sg.get('machine_no', 0)}", sg.get("run_start"), sg.get("run_end"))
                a, b = sg.get("step_start") or a, sg.get("step_end") or b
            for m in sg.get("machines") or []:
                add(m, a, b)
    return out


# def _locked_slots(db: Session, plant: Optional[str], start_dt: datetime, warnings: List[str]) -> Dict[str, Dict[str, Any]]:
#     """Active locks -> {po: slots of its plan version from start_dt on (bookings, bars, runs) + plan info}."""
#     try:
#         q = db.query(SchedulePoLock).filter(SchedulePoLock.released_at.is_(None))
#         if plant:
#             q = q.filter(or_(SchedulePoLock.plant_code == plant, SchedulePoLock.plant_code.is_(None)))
#         locks = q.all()
#     except Exception:
#         db.rollback()
#         return {}
#     if not locks:
#         return {}
#     snaps = {p.id: p for p in db.query(SchedulePlan).filter(SchedulePlan.id.in_({l.version_id for l in locks})).all()}
#     vers = _versions(db, list(snaps))
#     day0 = start_dt.date().isoformat()
#     out: Dict[str, Dict[str, Any]] = {}
#     for lk in locks:
#         plan = snaps.get(lk.version_id)
#         po = lk.production_order
#         meta = _snapshot_pos(plan.snapshot if plan else {}).get(po)
#         if not plan or not meta:
#             warnings.append(f"PO {po} is assigned (locked) from a plan that no longer has it - scheduled normally")
#             continue
#         snap = plan.snapshot or {}
#         start, end = _parse_dt(meta.get("start")), _parse_dt(meta.get("end"))
#         bks = [b for b in snap.get("bookings") or [] if b.get("po") == po] or _bookings_from_segments(snap, po)
#         segs: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
#         for row in snap.get("stations", []):
#             key = row.get("station_id") or str(row.get("row_id", "")).split(":", 1)[-1]
#             segs[key] += [sg for sg in row.get("segments", []) if sg.get("po") == po and sg.get("date", "") >= day0]
#         msegs = {mr["machine_id"]: [sg for sg in mr.get("segments", []) if sg.get("po") == po and sg.get("date", "") >= day0]
#                  for mr in snap.get("machines", []) if mr.get("machine_id")}
#         v = vers.get(plan.id)
#         info = {"part": meta.get("part_number"), "qty": meta.get("quantity") or 0, "role": meta.get("role"),
#                 "start": start, "end": end, "version_id": plan.id,
#                 "version_name": v.version_name if v else plan.name, "reference": v.reference if v else None,
#                 "locked_at": _iso(lk.locked_at), "locked_by": lk.locked_by,
#                 "bookings": [b for b in bks if (_parse_dt(b["end"]) or start_dt) > start_dt],
#                 "segments": {k: v_ for k, v_ in segs.items() if v_}, "machine_segments": {k: v_ for k, v_ in msegs.items() if v_},
#                 "runs": [r for r in snap.get("runs", []) if r.get("po") == po]}
#         if end and end <= start_dt:
#             info["past"] = True
#         out[po] = info
#     return out


def _locked_slots(db: Session, plant: Optional[str], start_dt: datetime, warnings: List[str]) -> Dict[str, Dict[str, Any]]:
    """Active locks -> {po: slots of its plan version from start_dt on (bookings, bars, runs) + plan info}."""
    try:
        q = db.query(SchedulePoLock).filter(SchedulePoLock.released_at.is_(None))
        if plant:
            q = q.filter(or_(SchedulePoLock.plant_code == plant, SchedulePoLock.plant_code.is_(None)))
        locks = q.all()
    except Exception:
        db.rollback()
        locks = []

    # Automatically include POs that have active assignments in PCBAssignment
    try:
        assigned_po_rows = db.query(PcbData.productionOrder).join(
            PCBAssignment, PCBAssignment.assigned_pcb_id == PcbData.PCBserialNoPartNumber
        ).filter(
            PCBAssignment.overall_status != "COMPLETED",
            PcbData.productionOrder.isnot(None),
            PcbData.productionOrder != ""
        ).distinct().all()
        
        locked_pos_set = {l.production_order for l in locks}
        current_plans = _current_plans(db, plant)
        
        if current_plans and current_plans[0].snapshot:
            snap_pos = _snapshot_pos(current_plans[0].snapshot)
            for (po_val,) in assigned_po_rows:
                norm_po = _norm(po_val) or po_val
                if norm_po not in locked_pos_set and norm_po in snap_pos:
                    class VirtualLock:
                        version_id = current_plans[0].id
                        production_order = norm_po
                        plant_code = plant
                        locked_at = datetime.now()
                        locked_by = "auto-assigned"
                    locks.append(VirtualLock())
    except Exception:
        db.rollback()

    if not locks:
        return {}

    snaps = {p.id: p for p in db.query(SchedulePlan).filter(SchedulePlan.id.in_({l.version_id for l in locks})).all()}
    vers = _versions(db, list(snaps))
    day0 = start_dt.date().isoformat()
    out: Dict[str, Dict[str, Any]] = {}
    for lk in locks:
        plan = snaps.get(lk.version_id)
        po = lk.production_order
        meta = _snapshot_pos(plan.snapshot if plan else {}).get(po)
        if not plan or not meta:
            warnings.append(f"PO {po} is assigned (locked) from a plan that no longer has it - scheduled normally")
            continue
        snap = plan.snapshot or {}
        start, end = _parse_dt(meta.get("start")), _parse_dt(meta.get("end"))
        bks = [b for b in snap.get("bookings") or [] if b.get("po") == po] or _bookings_from_segments(snap, po)
        segs: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        for row in snap.get("stations", []):
            key = row.get("station_id") or str(row.get("row_id", "")).split(":", 1)[-1]
            segs[key] += [sg for sg in row.get("segments", []) if sg.get("po") == po and sg.get("date", "") >= day0]
        msegs = {mr["machine_id"]: [sg for sg in mr.get("segments", []) if sg.get("po") == po and sg.get("date", "") >= day0]
                 for mr in snap.get("machines", []) if mr.get("machine_id")}
        v = vers.get(plan.id)
        info = {"part": meta.get("part_number"), "qty": meta.get("quantity") or 0, "role": meta.get("role"),
                "start": start, "end": end, "version_id": plan.id,
                "version_name": v.version_name if v else plan.name, "reference": v.reference if v else None,
                "locked_at": _iso(lk.locked_at), "locked_by": lk.locked_by,
                "bookings": [b for b in bks if (_parse_dt(b["end"]) or start_dt) > start_dt],
                "segments": {k: v_ for k, v_ in segs.items() if v_}, "machine_segments": {k: v_ for k, v_ in msegs.items() if v_},
                "runs": [r for r in snap.get("runs", []) if r.get("po") == po]}
        if end and end <= start_dt:
            info["past"] = True
        out[po] = info
    return out

def plan_pos(db: Session, plan_id: Optional[int] = None, plant: Optional[str] = None) -> Dict[str, Any]:
    """GET /schedule/plans/pos - EVERY PO of a saved plan (no date range), in plan order: the list Assign PCB assigns in
    one go. plan_id = a version; none = the current plan of each plant. POs assigned from ANOTHER plan are left out;
    POs assigned from this plan are flagged (assigned = True)."""
    use_settings(db)
    plans = [_get_plan(db, plan_id)] if plan_id is not None else _current_plans(db, plant)
    vers = _versions(db, [p.id for p in plans])
    locks = {l.production_order: l for l in db.query(SchedulePoLock).filter(SchedulePoLock.released_at.is_(None)).all()}
    out = []
    for p in plans:
        v = vers.get(p.id)
        for m in (p.snapshot or {}).get("meta", {}).get("pos", []):
            po = m["production_order"]
            lk = locks.get(po)
            if m.get("locked") or (lk is not None and lk.version_id != p.id):
                continue                                   # belongs to the plan it was assigned from
            out.append({"production_order": po, "part_number": m.get("part_number"), "role": m.get("role"),
                        "quantity": m.get("quantity"), "start": m.get("start"), "end": m.get("end"),
                        "forced": bool(m.get("forced")), "label": m.get("label"), "plant": p.plant_code,
                        "assigned": lk is not None, "plan_id": p.id,
                        "plan_reference": v.reference if v else None, "plan_name": v.version_name if v else p.name})
    out.sort(key=lambda x: (x["start"] or "", x["production_order"]))
    return {"plans": [{"id": p.id, "name": p.name, "plant": p.plant_code, "is_baseline": bool(p.is_baseline),
                       "created_at": _iso(p.created_at), **_version_json(vers.get(p.id))} for p in plans],
            "pos": out}


def view_schedule(db: Session, date_from: date, date_to: date, plant: Optional[str] = None,
                  plan_id: Optional[int] = None, now: Optional[datetime] = None, all_plans: bool = False) -> Dict[str, Any]:
    """Read-only view of SAVED plans between two dates (Assign PCB page).
      one plan  : plan_id (a version), else the current plan of each plant (baseline, else the newest version).
                  Only the plan's OWN POs: a PO assigned (locked) from another plan is not shown here.
      all_plans : the whole factory schedule - the newest version of every plan + the versions POs were assigned from.
                  Every PO once: an assigned PO from the plan it was assigned from, any other PO from its newest plan.
                  Every bar carries its plan (plan_id / plan_reference) so the page can highlight one plan.
    Returns process rows, machine rows, the days (working / off + why), machine down-time and the assigned POs."""
    use_settings(db)
    now = now or datetime.now()
    if date_to < date_from:
        date_from, date_to = date_to, date_from
    if (date_to - date_from).days + 1 > VIEW_MAX_DAYS:
        raise PoGanttError(400, f"Pick at most {VIEW_MAX_DAYS} days")
    lock_rows = db.query(SchedulePoLock).filter(SchedulePoLock.released_at.is_(None)).all()
    locks = {l.production_order: l for l in lock_rows}
    lock_vers = _versions(db, [l.version_id for l in lock_rows])

    if all_plans:
        q = db.query(SchedulePlan)
        if plant:
            q = q.filter(SchedulePlan.plant_code == plant)
        every = q.order_by(SchedulePlan.created_at.desc(), SchedulePlan.id.desc()).all()
        ev = _versions(db, [p.id for p in every])
        newest: Dict[int, SchedulePlan] = {}
        for p in every:                                   # newest version of each plan (Plan_ID)
            key = ev[p.id].plan_id if p.id in ev else p.id
            cur = newest.get(key)
            if cur is None or (ev.get(p.id) and ev.get(cur.id) and ev[p.id].version_no > ev[cur.id].version_no):
                newest[key] = p
        wanted = {p.id for p in newest.values()} | {l.version_id for l in lock_rows}
        plans = [p for p in every if p.id in wanted]      # newest first
    else:
        plans = [_get_plan(db, plan_id)] if plan_id is not None else _current_plans(db, plant)
    vers = _versions(db, [p.id for p in plans])

    # which plan each PO is shown from
    owner: Dict[str, int] = {}
    plan_ids = {x.id for x in plans}
    for p in plans:                                       # all_plans: newest plan first
        for po in _snapshot_pos(p.snapshot):
            lk = locks.get(po)
            if lk is not None and lk.version_id != p.id and (not all_plans or lk.version_id in plan_ids):
                continue                                  # assigned from another plan -> belongs to that plan
            owner.setdefault(po, p.id)

    lo, hi = date_from.isoformat(), date_to.isoformat()
    many = len({p.plant_code for p in plans}) > 1

    def in_range(ev_):                                     # a down-time event overlapping the range
        return (ev_.get("start") or "")[:10] <= hi and (ev_.get("end") or ev_.get("start") or "")[:10] >= lo

    def seg_json(sg, p):
        lk = locks.get(sg["po"])
        v = vers.get(p.id)
        return {"po": sg["po"], "part": sg["part"], "label": sg["label"], "role": sg["role"],
                "date": sg["date"], "start": sg["start"], "end": sg["end"], "minutes": sg["minutes"],
                "machine": sg.get("machine"), "step": sg.get("step"), "operation": sg.get("operation"),
                "locked": lk is not None, "plan_id": p.id, "plan_reference": v.reference if v else None,
                "batch": ({"no": sg["batch"]["no"], "count": sg["batch"]["count"], "qty": sg["batch"]["qty"],
                           "size": sg["batch"]["size"]} if sg.get("batch") else None)}

    rows: Dict[str, Dict[str, Any]] = {}
    mrows: Dict[str, Dict[str, Any]] = {}
    pos, start_h, end_h = {}, None, None
    per_plan: Dict[int, set] = defaultdict(set)
    for p in plans:
        snap = p.snapshot or {}
        meta = snap.get("meta", {})
        win = meta.get("day_window") or {}
        if win.get("start_hour") is not None:
            start_h = win["start_hour"] if start_h is None else min(start_h, win["start_hour"])
        if win.get("end_hour") is not None:
            end_h = win["end_hour"] if end_h is None else max(end_h, win["end_hour"])
        mine = lambda sg: owner.get(sg["po"]) == p.id and lo <= sg["date"] <= hi
        pref = f"{p.plant_code} · " if many and p.plant_code else ""
        for row in snap.get("stations", []):
            segs = [seg_json(sg, p) for sg in row.get("segments", []) if mine(sg)]
            if not segs:
                continue
            per_plan[p.id].update(s_["po"] for s_ in segs)
            key = (f"{p.plant_code}:{row['row_id']}" if all_plans else f"{p.id}:{row['row_id']}")
            r = rows.get(key)
            if r is None:
                r = rows[key] = {"row_id": key, "name": row["name"], "section": row.get("section"), "kind": row.get("kind"),
                                 "plant": p.plant_code, "plan_id": p.id, "title": pref + row["name"],
                                 "steps": row.get("steps") or [],
                                 "machines": row.get("real_machine_names") or row.get("machine_names") or [],
                                 "segments": [], "downtime": [ev_ for ev_ in row.get("downtime", []) if in_range(ev_)]}
            r["segments"] += segs
        for mr in snap.get("machines", []):
            segs = [seg_json(sg, p) for sg in mr.get("segments", []) if mine(sg)]
            key = (f"{p.plant_code}:{mr['row_id']}" if all_plans else f"{p.id}:{mr['row_id']}")
            if not segs and (key in mrows or not [ev_ for ev_ in mr.get("downtime", []) if in_range(ev_)]):
                continue
            r = mrows.get(key)
            if r is None:
                r = mrows[key] = {"row_id": key, "machine_id": mr.get("machine_id"), "title": pref + (mr.get("name") or ""),
                                  "name": mr.get("name"), "group": mr.get("group_name"), "step": mr.get("step"),
                                  "section": (mr.get("roles") or [None])[0], "segments": [],
                                  "downtime": [ev_ for ev_ in mr.get("downtime", []) if in_range(ev_)]}
            r["segments"] += segs
        v = vers.get(p.id)
        for m in meta.get("pos", []):
            po = m["production_order"]
            if po in per_plan[p.id] and po not in pos:
                lk = locks.get(po)
                lv = lock_vers.get(lk.version_id) if lk else None
                pos[po] = {
                    "production_order": po, "part_number": m["part_number"], "role": m["role"],
                    "quantity": m["quantity"], "start": m["start"], "end": m["end"], "forced": bool(m.get("forced")),
                    "plant": p.plant_code, "locked": lk is not None, "label": m.get("label"),
                    "plan_id": p.id, "plan_reference": v.reference if v else None,
                    "plan_name": v.version_name if v else p.name,
                    "lock": ({"version_id": lk.version_id, "reference": lv.reference if lv else None,
                              "version_name": lv.version_name if lv else None, "locked_at": _iso(lk.locked_at),
                              "locked_by": lk.locked_by} if lk else None)}

    order = {"CHILD": 0, "MAIN": 1}
    row_list = sorted(rows.values(), key=lambda r: order.get(r["section"], 2))       # stable: plan order inside a section
    mrow_list = list(mrows.values())

    # the calendar of the range (off days and why) - of the plant shown
    cal_plant = plant or (plans[0].plant_code if len({p.plant_code for p in plans}) == 1 and plans else None)
    cal = _load_calendar(db, cal_plant)
    days, d = [], date_from
    while d <= date_to:
        f = cal.factor(d)
        days.append({"date": d.isoformat(), "weekday": d.strftime("%a"), "working": f > 0, "factor": f,
                     "off_reason": None if f >= 1 else cal.off_reason(d),
                     "holiday": f <= 0 and (d in cal.holidays or cal.exceptions.get(d) == "holiday")})
        d += timedelta(days=1)
    dw_default = _default_win(db)[0]
    return {
        "range": {"from": lo, "to": hi}, "now": _iso(now), "all_plans": all_plans,
        "plans": [{"id": p.id, "name": p.name, "plant": p.plant_code, "is_baseline": bool(p.is_baseline),
                   "status": p.status, "created_at": _iso(p.created_at),
                   "start_date": p.start_date.isoformat() if p.start_date else None,
                   "finish_date": p.finish_date.isoformat() if p.finish_date else None,
                   "pos_in_range": len(per_plan.get(p.id, ())),
                   **_version_json(vers.get(p.id))} for p in plans],
        "day_window": {"start_hour": start_h if start_h is not None else dw_default.start_h,
                       "end_hour": end_h if end_h is not None else dw_default.start_h + dw_default.cap_min / 60.0},
        "days": days,
        "rows": row_list,
        "machines": mrow_list,
        "pos": sorted(pos.values(), key=lambda x: (x["start"] or "", x["production_order"])),
        "locked_count": sum(1 for x in pos.values() if x["locked"]),
    }


# --------------------------------------------------------------------------------------
# Actual (what the operators did) and Planned vs Actual
# --------------------------------------------------------------------------------------
_MACHINE_KEYS = ("machine_id", "machineId", "machine", "machine_name", "equipment", "eqpt_no", "equipment_id")


def load_actuals(db: Session, po_numbers: List[str]):
    """Returns (pcb_qty {po: total pieces}, agg {(po, flow_step_id): {...}}) from operator_log, then pcb_process_log
    (via pcb_assignment) for PCB x step pairs operator_log does not have."""
    pos = sorted({_norm(p) for p in po_numbers if p})
    pcbs: Dict[str, Tuple[str, int]] = {}
    serial_to_pcb: Dict[str, str] = {}
    pcb_qty: Dict[str, int] = defaultdict(int)
    norm_col = func.ltrim(func.trim(PcbData.productionOrder), "0")
    for chunk in _chunks(pos):
        for pcb, serial, po, qty in db.query(PcbData.PCBserialNoPartNumber, PcbData.serialNo, PcbData.productionOrder,
                                             PcbData.quantity).filter(norm_col.in_(chunk)).all():
            q = qty if qty and qty > 0 else 1
            n = _norm(po)
            pcbs[pcb] = (n, q)
            pcb_qty[n] += q
            if serial:
                serial_to_pcb.setdefault(serial, pcb)

    events: Dict[Tuple[str, int], Dict[str, Any]] = {}
    keys = list(pcbs)
    for chunk in _chunks(keys):
        for r in db.query(OperatorLog).filter(OperatorLog.PCBserialNoPartNumber.in_(chunk)).all():
            st, en = _parse_dt(r.start_time), _parse_dt(r.end_time)
            if not en and (r.Task_Status or "").strip().lower() in DONE_STATUSES:
                en = st
            if not st and not en:
                continue
            machine = None
            if isinstance(r.log_Data, dict):
                machine = next((str(r.log_Data[k]) for k in _MACHINE_KEYS if r.log_Data.get(k)), None)
            events[(r.PCBserialNoPartNumber, r.current_step_id)] = {
                "start": st or en, "end": en, "operator": r.operator_name or r.operator_staff_no, "machine": machine}

    assign: Dict[int, str] = {}
    lookup = keys + [s for s in serial_to_pcb if s not in pcbs]
    for chunk in _chunks(lookup):
        for aid, pid in db.query(PCBAssignment.assignment_id, PCBAssignment.assigned_pcb_id).filter(
                PCBAssignment.assigned_pcb_id.in_(chunk)).all():
            pcb = pid if pid in pcbs else serial_to_pcb.get(pid)
            if pcb:
                assign[aid] = pcb
    for chunk in _chunks(list(assign)):
        for r in db.query(PCBProcessLog).filter(PCBProcessLog.assignment_id.in_(chunk)).all():
            k = (assign[r.assignment_id], r.flow_step_id)
            if k in events:
                continue
            st, en = _parse_dt(r.start_time), _parse_dt(r.end_time)
            if not en and (r.process_status or "").strip().lower() in DONE_STATUSES:
                en = st
            if not st and not en:
                continue
            events[k] = {"start": st or en, "end": en, "operator": r.assigned_operator_staff_no, "machine": None}

    agg: Dict[Tuple[str, int], Dict[str, Any]] = {}
    for (pcb, sid), ev in events.items():
        po, q = pcbs[pcb]
        a = agg.setdefault((po, sid), {"start": None, "end": None, "done": 0, "wip": 0,
                                       "operators": set(), "machines": set()})
        a["start"] = min(a["start"], ev["start"]) if a["start"] else ev["start"]
        if ev["end"]:
            a["done"] += q
            a["end"] = max(a["end"], ev["end"]) if a["end"] else ev["end"]
        else:
            a["wip"] += q
        if ev["operator"]:
            a["operators"].add(ev["operator"])
        if ev["machine"]:
            a["machines"].add(ev["machine"])
    return pcb_qty, agg


def _status(ps, pe, a_start, a_end, complete, now) -> Tuple[str, Optional[float]]:
    tol = timedelta(minutes=LATE_TOLERANCE_MIN)
    mins = lambda d: round(d.total_seconds() / 60.0, 1)
    if complete:
        return ("DONE_LATE" if a_end > pe + tol else "DONE_ON_TIME"), mins(a_end - pe)
    if a_start:
        return ("RUNNING_LATE" if now > pe + tol else "RUNNING"), (mins(now - pe) if now > pe else None)
    if now > ps + tol:
        return "START_OVERDUE", mins(now - ps)
    return "UPCOMING", None


def compare_plan(db: Session, plan_id: int, now: Optional[datetime] = None) -> Dict[str, Any]:
    use_settings(db)
    plan = _get_plan(db, plan_id)
    snap = plan.snapshot or {}
    now = now or datetime.now()
    runs = snap.get("runs") or []
    if not runs:                                             # a plan saved without runs -> rebuild from items
        runs = [{"seq": i.seq, "label": i.label, "po": i.production_order, "part": i.part_number, "role": i.role,
                 "quantity": i.quantity, "row_id": i.row_id, "station": i.station_name, "kind": i.station_kind,
                 "flow_step_ids": i.flow_step_ids or [], "machine": i.machine, "machines": i.machines or [],
                 "start": _iso(i.planned_start), "end": _iso(i.planned_end), "minutes": i.run_minutes}
                for i in db.query(SchedulePlanItem).filter(SchedulePlanItem.plan_id == plan.id).all()]
    pcb_qty, agg = load_actuals(db, [r["po"] for r in runs])

    by_row: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    by_po: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for r in runs:
        ps, pe = datetime.strptime(r["start"], ISO), datetime.strptime(r["end"], ISO)
        total = pcb_qty.get(r["po"]) or r["quantity"] or 1
        acts = [agg.get((r["po"], sid)) for sid in r["flow_step_ids"]]
        got = [a for a in acts if a]
        a_start = min(a["start"] for a in got) if got else None
        done_qty = min((a["done"] if a else 0) for a in acts) if acts else 0
        complete = bool(acts) and all(a and a["done"] >= total for a in acts)
        a_end = max(a["end"] for a in got if a["end"]) if complete else None
        status, var = _status(ps, pe, a_start, a_end, complete, now)
        item = {
            "label": r["label"], "po": r["po"], "part": r["part"], "role": r["role"], "quantity": r["quantity"],
            "seq": r["seq"], "row_id": r["row_id"], "station": r["station"], "machine": r["machine"],
            "planned_start": r["start"], "planned_end": r["end"], "planned_minutes": r["minutes"],
            "actual_start": _iso(a_start), "actual_end": _iso(a_end), "actual_until": _iso(a_end or (now if a_start else None)),
            "done_qty": done_qty, "total_qty": total,
            "wip_qty": max((a["wip"] for a in got), default=0),
            "start_variance_min": round((a_start - ps).total_seconds() / 60.0, 1) if a_start else None,
            "variance_min": var, "status": status,
            "operators": sorted({o for a in got for o in a["operators"]}),
            "actual_machines": sorted({m for a in got for m in a["machines"]}),
        }
        by_row[r["row_id"]].append(item)
        by_po[r["po"]].append(item)

    rows = []
    for st in snap.get("stations", []):
        items = sorted(by_row.get(st["row_id"], []), key=lambda x: x["planned_start"])
        row = {k: st.get(k) for k in ("row_id", "station_id", "name", "kind", "section", "role", "steps",
                                      "part_numbers", "shifts", "has_machine", "real_machine_names",
                                      "machines", "flow_step_ids")}
        row["items"] = items
        rows.append(row)

    po_meta = {p["production_order"]: p for p in snap.get("meta", {}).get("pos", [])}
    pos_out, kpi = [], defaultdict(int)
    for po, items in by_po.items():
        items.sort(key=lambda x: x["seq"])
        ps = min(i["planned_start"] for i in items)
        pe = max(i["planned_end"] for i in items)
        starts = [i["actual_start"] for i in items if i["actual_start"]]
        complete = all(i["status"].startswith("DONE") for i in items)
        a_end = max(i["actual_end"] for i in items) if complete else None
        status, var = _status(datetime.strptime(ps, ISO), datetime.strptime(pe, ISO),
                              datetime.strptime(min(starts), ISO) if starts else None,
                              datetime.strptime(a_end, ISO) if a_end else None, complete, now)
        current = next((i for i in items if not i["status"].startswith("DONE")), None)
        kpi[status] += 1
        m = po_meta.get(po, {})
        pos_out.append({
            "po": po, "label": items[0]["label"], "part": items[0]["part"], "role": items[0]["role"],
            "quantity": items[0]["quantity"], "planned_start": ps, "planned_end": pe,
            "actual_start": min(starts) if starts else None, "actual_end": a_end, "status": status, "variance_min": var,
            "current_process": current["station"] if current else None,
            "current_status": current["status"] if current else None,
            "processes_done": sum(1 for i in items if i["status"].startswith("DONE")), "processes": len(items),
            "late_processes": sum(1 for i in items if i["status"] in ("DONE_LATE", "RUNNING_LATE", "START_OVERDUE")),
            "depends_on": m.get("depends_on", []), "handoff": m.get("handoff"),
        })
    order = {p["production_order"]: i for i, p in enumerate(snap.get("meta", {}).get("pos", []))}
    pos_out.sort(key=lambda p: order.get(p["po"], 10 ** 6))
    process_kpi = defaultdict(int)
    for items in by_row.values():
        for i in items:
            process_kpi[i["status"]] += 1

    actual_ends = [i["actual_until"] for items in by_row.values() for i in items if i["actual_until"]]
    return {
        "plan": _plan_header(plan), "now": _iso(now),
        "days": snap.get("days", []),
        "meta": dict({k: snap.get("meta", {}).get(k) for k in ("day_window", "calendar", "line_groups", "pos", "start_date",
                                                               "finish_date", "working_days", "number_of_pos")},
                     actual_last=max(actual_ends) if actual_ends else None),
        "rows": rows, "pos": pos_out,
        "kpis": {"pos": dict(kpi), "processes": dict(process_kpi), "total_pos": len(pos_out),
                 "total_runs": sum(len(v) for v in by_row.values())},
    }


# --------------------------------------------------------------------------------------
# Excel export
# --------------------------------------------------------------------------------------
def build_po_gantt_xlsx(result: Dict[str, Any]) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter

    font = lambda **kw: Font(name="Arial", size=10, **kw)
    thin = Side(style="thin", color="BFBFBF")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    head = PatternFill("solid", start_color="DDE3EE")
    off = PatternFill("solid", start_color="D9D9D9")
    down = PatternFill("solid", start_color="F4CCCC")
    machine_fill = PatternFill("solid", start_color="FFF4DB")
    section_fill = {"CHILD": PatternFill("solid", start_color="D3F9D8"), "MAIN": PatternFill("solid", start_color="D0EBFF")}
    fills = {BLUE: PatternFill("solid", start_color="9FC5E8"), ORANGE: PatternFill("solid", start_color="F6B26B")}
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    days = result["days"]
    last_col = 2 + len(days)

    def header(ws, first_col_title):
        ws.column_dimensions["A"].width = 36
        ws.column_dimensions["B"].width = 12
        for i, label in enumerate(("Working day #", "Date", "Day"), start=1):
            c = ws.cell(row=i, column=1, value=first_col_title if i == 3 else label)
            c.font, c.fill, c.border = font(bold=True), head, border
            ws.cell(row=i, column=2).fill = head
            ws.cell(row=i, column=2).border = border
        for j, d in enumerate(days, start=3):
            ws.column_dimensions[get_column_letter(j)].width = 11
            dt = date.fromisoformat(d["date"])
            vals = ("Off" if d["is_holiday"] else d["working_day_no"], dt.strftime("%d-%b"), d["weekday"])
            for i, v in enumerate(vals, start=1):
                c = ws.cell(row=i, column=j, value=v)
                c.font, c.border, c.alignment = font(bold=(i == 1)), border, center
                c.fill = off if d["is_holiday"] else head
        ws.freeze_panes = "C4"

    def band(ws, r, text, fill):
        for j in range(1, last_col + 1):
            c = ws.cell(row=r, column=j)
            c.fill, c.border = fill, border
        ws.cell(row=r, column=1, value=text).font = font(bold=True)

    def day_cells(ws, r, segs, downs):
        col_of_date = {d["date"]: j for j, d in enumerate(days, start=3)}
        for j, d in enumerate(days, start=3):
            c = ws.cell(row=r, column=j)
            c.border = border
            if d["is_holiday"]:
                c.fill = off
        for e in downs:
            dd = date.fromisoformat(e["start"][:10])
            while dd.isoformat() <= e["end"][:10]:
                j = col_of_date.get(dd.isoformat())
                if j and not (dd.isoformat() == e["end"][:10] and e["end"][11:] == "00:00:00" and e["end"][:10] != e["start"][:10]):
                    c = ws.cell(row=r, column=j, value="DOWN")
                    c.fill, c.font, c.alignment = down, font(bold=True, color="990000"), center
                dd += timedelta(days=1)
        per_day: Dict[str, List[str]] = defaultdict(list)
        for s in segs:
            if s["label"] not in per_day[s["date"]]:
                per_day[s["date"]].append(s["label"])
        for dstr, labels in per_day.items():
            j = col_of_date.get(dstr)
            if not j:
                continue
            c = ws.cell(row=r, column=j, value=" ".join(labels))
            c.fill = fills[ORANGE if len(labels) >= 2 else BLUE]
            c.font, c.alignment = font(bold=True), center

    wb = Workbook()
    ws = wb.active
    ws.title = "PO on Process"
    header(ws, "Process")
    r, current = 4, None
    for st in result["stations"]:
        if st["section"] != current:
            current = st["section"]
            band(ws, r, f"{current} PROCESSES", section_fill.get(current, head))
            r += 1
        name = st["name"] + (f"  ({len(st['steps'])} steps, same day)" if st.get("kind") == "LINE" else "")
        a = ws.cell(row=r, column=1, value=name)
        a.font, a.border = font(bold=True), border
        if st.get("has_machine"):
            a.fill = machine_fill
        b = ws.cell(row=r, column=2, value=f"{st['shifts']} shift" + (f" · {len(st['real_machines'])} m/c" if st.get("real_machines") else ""))
        b.font, b.border, b.alignment = font(), border, center
        day_cells(ws, r, st["segments"], [])
        r += 1

    r += 1
    ws.cell(row=r, column=1, value="Legend").font = font(bold=True)
    for k, (txt, fill) in enumerate((("1 PO on the process", fills[BLUE]), ("2 or more POs share the process", fills[ORANGE]),
                                     ("Process with machine(s)", machine_fill)), 1):
        ws.cell(row=r + k, column=1, value=txt).font = font()
        ws.cell(row=r + k, column=2).fill = fill
    r += 5
    for j, h in enumerate(("Label", "Production order", "Part number", "Child / Main", "Quantity", "Start", "End"), start=1):
        c = ws.cell(row=r, column=j, value=h)
        c.font, c.fill, c.border = font(bold=True), head, border
    for k, p in enumerate(result["meta"]["pos"], start=1):
        for j, v in enumerate((p["label"], p["production_order"], p["part_number"], p["role"], p["quantity"],
                               p["start"], p["end"]), start=1):
            c = ws.cell(row=r + k, column=j, value=v)
            c.font, c.border = font(), border

    ws2 = wb.create_sheet("PO on Machines")
    header(ws2, "Machine")
    r, current = 4, None
    for m in result.get("machines", []):
        if m["group"] != current:
            current = m["group"]
            band(ws2, r, m["group_name"], machine_fill)
            r += 1
        a = ws2.cell(row=r, column=1, value=f"{m['name']} ({m['machine_id']})" + (f" · {m['step']}" if m.get("step") else ""))
        a.font, a.border = font(bold=True), border
        b = ws2.cell(row=r, column=2, value=f"{round(m['busy_minutes'] / 60, 1)} h")
        b.font, b.border, b.alignment = font(), border, center
        day_cells(ws2, r, m["segments"], m["downtime"])
        r += 1

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


# --------------------------------------------------------------------------------------
# Router
# --------------------------------------------------------------------------------------
def create_po_gantt_router(init_db, verify_token=None, engine=None) -> APIRouter:
    """Pass `engine` so machine_hours / batch_size are added to part_process_time and the plan tables are created
    at start-up (otherwise they are created on first use)."""
    if engine is not None:
        ensure_part_process_time_columns(engine)
        try:
            ensure_plan_tables(engine)
        except Exception as exc:
            print(f"[po_gantt] could not create schedule_plan tables: {exc}")
    router = APIRouter()
    deps = [Depends(verify_token)] if verify_token else []

    def _guard(fn, db=None):
        try:
            return fn()
        except PoGanttError as e:
            if db is not None:
                db.rollback()
            raise HTTPException(status_code=e.status_code, detail=e.detail)

    def _run(db, production_order, plant, start_date, time_source, label_mode, show_holidays, start_at=None):
        return _guard(lambda: build_po_gantt(db, production_order, plant, start_date, time_source, label_mode,
                                             show_holidays, start_at=start_at))

    # ---------- settings (Configure button) ----------
    @router.get("/schedule/settings", dependencies=deps)
    def settings_get(db: Session = Depends(init_db)):
        return _guard(lambda: get_settings(db))

    @router.put("/schedule/settings", dependencies=deps)
    def settings_put(body: SettingsSave, db: Session = Depends(init_db)):
        return _guard(lambda: save_settings(db, body), db)

    @router.get("/schedule/po-gantt/process-check", dependencies=deps)
    def po_gantt_process_check(plant: Optional[str] = Query(None), db: Session = Depends(init_db)):
        use_settings(db)
        return _guard(lambda: process_check(db, plant))

    @router.get("/schedule/po-gantt/plants", dependencies=deps)
    def po_gantt_plants(db: Session = Depends(init_db)):
        return list_plants(db)

    @router.get("/schedule/part-process-time", dependencies=deps)
    def part_process_time_list(plant: Optional[str] = Query(None), part_no: Optional[str] = Query(None),
                               db: Session = Depends(init_db)):
        use_settings(db)
        return list_part_process_times(db, plant, part_no)

    @router.put("/schedule/part-process-time", dependencies=deps)
    def part_process_time_save(body: PartTimeSave, db: Session = Depends(init_db)):
        return _guard(lambda: save_part_process_times(db, body), db)

    @router.get("/schedule/po-gantt/orders", dependencies=deps)
    def po_gantt_orders(plant: Optional[str] = Query(None), db: Session = Depends(init_db)):
        use_settings(db)
        return list_open_orders(db, plant)

    @router.get("/schedule/po-gantt", dependencies=deps)
    def po_gantt(
        request: Request,
        production_order: Optional[List[str]] = Query(None, description="PO numbers to load; order = load priority"),
        plant: Optional[str] = Query(None),
        start_at: Optional[datetime] = Query(None, description="exact start, e.g. 2026-11-05T14:30 (default: now)"),
        start_date: Optional[date] = Query(None, description="legacy: from the start of this day"),
        time_source: str = Query("actual"),
        label_mode: str = Query("seq", description="'seq' = B1, B2... | 'po' = PO number"),
        show_holidays: bool = Query(True, description="send off days as flagged columns"),
        db: Session = Depends(init_db),
    ):
        return _send(_run(db, production_order, plant, start_date, time_source, label_mode, show_holidays, start_at),
                     request, drop_for_page=True)

    @router.get("/schedule/po-gantt/export", dependencies=deps)
    def po_gantt_export(
        production_order: Optional[List[str]] = Query(None),
        plant: Optional[str] = Query(None),
        start_at: Optional[datetime] = Query(None),
        start_date: Optional[date] = Query(None),
        time_source: str = Query("actual"),
        label_mode: str = Query("seq"),
        show_holidays: bool = Query(True),
        db: Session = Depends(init_db),
    ):
        result = _run(db, production_order, plant, start_date, time_source, label_mode, show_holidays, start_at)
        return StreamingResponse(
            io.BytesIO(build_po_gantt_xlsx(result)),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": 'attachment; filename="po_gantt.xlsx"'},
        )

    # ---------- batch size per process (Configure > Process rules) ----------
    @router.get("/schedule/batch-sizes", dependencies=deps)
    def batch_sizes_get(plant: Optional[str] = Query(None), db: Session = Depends(init_db)):
        return _guard(lambda: list_batch_sizes(db, plant))

    @router.put("/schedule/batch-sizes", dependencies=deps)
    def batch_sizes_put(body: BatchSizeSave, db: Session = Depends(init_db)):
        return _guard(lambda: save_batch_sizes(db, body), db)

    # ---------- slot locks (PCBs assigned from a saved plan) ----------
    @router.post("/schedule/locks", dependencies=deps)
    def locks_add(body: LockBody, db: Session = Depends(init_db)):
        return _guard(lambda: lock_pos(db, body), db)

    @router.get("/schedule/locks", dependencies=deps)
    def locks_list(plant: Optional[str] = Query(None), db: Session = Depends(init_db)):
        return list_locks(db, plant)

    @router.delete("/schedule/locks/{production_order}", dependencies=deps)
    def locks_release(production_order: str, released_by: Optional[str] = Query(None), db: Session = Depends(init_db)):
        return _guard(lambda: unlock_po(db, production_order, released_by), db)

    @router.post("/schedule/plans", dependencies=deps)
    def plans_save(body: PlanSave, db: Session = Depends(init_db)):
        return _guard(lambda: save_plan(db, body), db)

    @router.get("/schedule/plans", dependencies=deps)
    def plans_list(plant: Optional[str] = Query(None), db: Session = Depends(init_db)):
        return list_plans(db, plant)

    # must stay ABOVE /schedule/plans/{plan_id}, else "pos" is read as a plan id
    @router.get("/schedule/plans/pos", dependencies=deps)
    def plans_pos(plan_id: Optional[int] = Query(None), plant: Optional[str] = Query(None), db: Session = Depends(init_db)):
        return _guard(lambda: plan_pos(db, plan_id, plant))

    # must stay ABOVE /schedule/plans/{plan_id}, else "view" is read as a plan id
    @router.get("/schedule/plans/view", dependencies=deps)
    def plans_view(request: Request,
                   date_from: date = Query(..., description="first day, YYYY-MM-DD"),
                   date_to: date = Query(..., description="last day, YYYY-MM-DD"),
                   plant: Optional[str] = Query(None),
                   plan_id: Optional[int] = Query(None, description="a saved plan; default = baseline plan of each plant"),
                   all_plans: bool = Query(False, description="every plan together (each PO once)"),
                   db: Session = Depends(init_db)):
        return _send(_guard(lambda: view_schedule(db, date_from, date_to, plant, plan_id, all_plans=all_plans)), request)

    @router.get("/schedule/plans/{plan_id}", dependencies=deps)
    def plans_get(plan_id: int, db: Session = Depends(init_db)):
        def go():
            p = _get_plan(db, plan_id)
            return {"plan": _plan_header(p, _versions(db, [p.id]).get(p.id)), "snapshot": p.snapshot}
        return _guard(go)

    @router.put("/schedule/plans/{plan_id}/baseline", dependencies=deps)
    def plans_baseline(plan_id: int, db: Session = Depends(init_db)):
        return _guard(lambda: set_baseline(db, plan_id), db)

    @router.delete("/schedule/plans/{plan_id}", dependencies=deps)
    def plans_delete(plan_id: int, db: Session = Depends(init_db)):
        return _guard(lambda: delete_plan(db, plan_id), db)

    @router.get("/schedule/plans/{plan_id}/compare", dependencies=deps)
    def plans_compare(plan_id: int, request: Request, db: Session = Depends(init_db)):
        return _send(_guard(lambda: compare_plan(db, plan_id)), request)
        
    @router.put("/schedule/plans/{plan_id}/approve", dependencies=deps)
    def plans_approve(plan_id: int, db: Session = Depends(init_db)):
        def go():
            p = _get_plan(db, plan_id)
            p.status = "APPROVED"
            db.commit()
            return {"plan": _plan_header(p, _versions(db, [p.id]).get(p.id))}
        return _guard(go)

    

    return router