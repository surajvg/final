

// import React, { useState, useEffect, useMemo } from "react";
// import axios from "../../AxiosInstance/axiosInstance";
// import {
//     Box,
//     Button,
//     Typography,
//     Table,
//     TableHead,
//     TableRow,
//     TableCell,
//     TableBody,
//     Paper,
//     Alert,
//     CircularProgress,
//     TableContainer,
//     Checkbox,
//     Stack,
//     FormControl,
//     InputLabel,
//     Select,
//     MenuItem,
//     Chip,
//     Snackbar,
//     TextField,
//     InputAdornment,
//     Divider,
//     IconButton,
//     Collapse,
//     Tabs,
//     Tab,Dialog,
//     DialogTitle,
//     DialogContent,
//     Tooltip
// } from "@mui/material";
// import ClearIcon from "@mui/icons-material/Clear";

// // Icons
// import AssignmentTurnedInIcon from "@mui/icons-material/AssignmentTurnedIn";
// import ListAltIcon from "@mui/icons-material/ListAlt";
// import PersonIcon from "@mui/icons-material/Person";
// import SearchIcon from "@mui/icons-material/Search";
// import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
// import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
// import PrecisionManufacturingIcon from "@mui/icons-material/PrecisionManufacturing";
// import AccountTreeIcon from "@mui/icons-material/AccountTree";
// import EngineeringIcon from "@mui/icons-material/Engineering";

// import { useSelector } from "react-redux";
// import { CheckCircleIcon } from "lucide-react";
// import AssignmentInd from "@mui/icons-material/AssignmentInd";
// import TimelineIcon from '@mui/icons-material/Timeline';

// import CloseIcon from '@mui/icons-material/Close';
// import VisibilityIcon from '@mui/icons-material/Visibility';
// import WarningAmberIcon from '@mui/icons-material/WarningAmber';
// import RefreshIcon from '@mui/icons-material/Refresh';
// // --- Configuration & Constants ---

// const BUTTON_OPTS = [
//     {
//         id: "1",
//         name: "TO BE ASSIGNED",
//         icon: <ListAltIcon sx={{ color: "#b26a00" }} />,
//         color: "warning"
//     },
//     {
//         id: "2",
//         name: "ASSIGNED",
//         icon: <AssignmentInd sx={{ color: "#455a64" }} />,
//         color: "info"
//     },
//     {
//         id: "3",
//         name: "COMPLETED",
//         icon: <CheckCircleIcon sx={{ color: "#2e7d32" }} />,
//         color: "success"
//     }
// ];

// // categories come from the PCBs themselves (PcbData.Type) - nothing fixed here

// const formatHeader = (key) => {
//     const map = {
//         PCBserialNoPartNumber: "Serial / Part No",
//         productionOrderNumber: "Prod. Order No",
//         orderNumber: "Order No",
//         createdAt: "Created Date",
//         updatedAt: "Last Updated",
//         serialNumber: "Serial No",
//         partNumber: "Part No",
//         type: "Type",
//         quantity: "Qty"
//     };
//     if (map[key]) return map[key];

//     return key
//         .replace(/([A-Z])/g, " $1")
//         .replace(/_/g, " ")
//         .replace(/^./, (str) => str.toUpperCase())
//         .trim();
// };

// const getAuthHeader = () => {
//     const token = localStorage.getItem("token");
//     return token ? { headers: { Authorization: `Bearer ${token}` } } : {};
// };

// // Process times are stored and returned in HOURS (e.g. 0.1, 1, 5.6) - no HH:MM:SS
// const formatHours = (hours) => `${(Number(hours) || 0).toFixed(2)} h`;




// // =====================================================================================
// // Read-only Gantt of the SAVED production schedule for a date range ("View Schedule" button)
// // Backend: GET {apiBase}/schedule/plans/view?date_from=YYYY-MM-DD&date_to=YYYY-MM-DD[&plan_id=]
// //          (default = baseline plan of each plant)   GET {apiBase}/schedule/plans -> plan picker
// // =====================================================================================
// const PALETTE = ["#2563eb", "#16a34a", "#d97706", "#9333ea", "#dc2626", "#0891b2", "#db2777", "#65a30d",
//     "#7c3aed", "#ea580c", "#0d9488", "#4f46e5", "#b45309", "#be123c", "#15803d", "#1d4ed8"];
// const LABEL_W = 250;      // left column (process names)
// const LANE_H = 22;        // one bar lane
// const ROW_PAD = 6;
// const MAX_DAYS = 62;

// /* ---------- small date helpers (all on "YYYY-MM-DD" / "YYYY-MM-DDTHH:MM:SS" strings, no time-zone shifts) ---------- */
// const pad = (n) => String(n).padStart(2, "0");
// const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
// const addDays = (s, n) => { const d = new Date(`${s}T00:00:00`); d.setDate(d.getDate() + n); return ymd(d); };
// const daysBetween = (a, b) => Math.round((new Date(`${b}T00:00:00`) - new Date(`${a}T00:00:00`)) / 86400000);
// const hourOf = (iso) => Number(iso.slice(11, 13)) + Number(iso.slice(14, 16)) / 60;
// const hm = (iso) => (iso ? iso.slice(11, 16) : "");
// const dayLabel = (s) => new Date(`${s}T00:00:00`).toLocaleDateString("en-GB", { weekday: "short", day: "2-digit", month: "short" });
// const fmt = (iso) => (iso ? `${new Date(iso.slice(0, 10) + "T00:00:00").toLocaleDateString("en-GB", { day: "2-digit", month: "short" })} ${hm(iso)}` : "-");
// const hourText = (h) => `${pad(Math.floor(h))}:${pad(Math.round((h % 1) * 60))}`;

// /* bars that overlap in one row (parallel machines, shared batch) go on separate lanes */
// function assignLanes(segs) {
//     const ends = [];
//     const out = [...segs].sort((a, b) => (a.start < b.start ? -1 : a.start > b.start ? 1 : 0)).map((s) => {
//         let lane = ends.findIndex((e) => e <= s.start);
//         if (lane < 0) { lane = ends.length; ends.push(s.end); } else ends[lane] = s.end;
//         return { ...s, lane };
//     });
//     return { segs: out, lanes: Math.max(1, ends.length) };
// }

// /* ---------- shared pieces of the read-only Gantt (same look as the Production Schedule page) ---------- */
// const OFF_W = 64;                                         // width of an off day column
// export const planLabel = (p) => (p ? `${p.version_name || p.name}${p.reference ? ` · ${p.reference}` : ""}${p.plant ? ` · ${p.plant}` : ""}${p.is_baseline ? " · current" : ""}` : "");

// /* plan version picker: "Current plan" + every saved version (name, reference) */
// function PlanSelect({ value, onChange, plans, label = "Plan", sx }) {
//     return (
//         <FormControl size="small" sx={{ minWidth: 300, ...sx }}>
//             <InputLabel>{label}</InputLabel>
//             <Select value={value} label={label} onChange={(e) => onChange(e.target.value)}
//                 renderValue={(v) => (v === "base" ? "Current plan" : planLabel((plans || []).find((p) => p.id === v)) || v)}>
//                 <MenuItem value="base">Current plan (of each plant)</MenuItem>
//                 {(plans || []).map((p) => (
//                     <MenuItem key={p.id} value={p.id} sx={{ display: "block" }}>
//                         <Box sx={{ fontWeight: 700, fontSize: 13.5 }}>{p.version_name || p.name}{p.is_baseline ? "  ★" : ""}</Box>
//                         <Box sx={{ fontSize: 12, color: "#64748b" }}>
//                             {p.reference || "-"}{p.plant ? ` · plant ${p.plant}` : ""}{p.locked_pos ? ` · 🔒 ${p.locked_pos} PO assigned` : ""}
//                         </Box>
//                     </MenuItem>
//                 ))}
//             </Select>
//         </FormControl>
//     );
// }

// /* Process / Machines toggle */
// function ViewToggle({ value, onChange }) {
//     return (
//         <Stack direction="row" sx={{ bgcolor: "#f1f5f9", borderRadius: 2, p: 0.4 }}>
//             {[["process", "PO on Process", <AccountTreeIcon key="a" sx={{ fontSize: 16 }} />],
//               ["machines", "PO on Machines", <PrecisionManufacturingIcon key="m" sx={{ fontSize: 16 }} />]].map(([v, l, ic]) => (
//                 <Button key={v} size="small" startIcon={ic} onClick={() => onChange(v)}
//                     sx={{ textTransform: "none", fontWeight: 700, borderRadius: 1.5, px: 1.5,
//                           bgcolor: value === v ? "#fff" : "transparent", color: value === v ? "#0f172a" : "#64748b",
//                           boxShadow: value === v ? "0 1px 3px rgba(0,0,0,.12)" : "none", "&:hover": { bgcolor: value === v ? "#fff" : "#e2e8f0" } }}>
//                     {l}
//                 </Button>
//             ))}
//         </Stack>
//     );
// }

// /* the chart: days (off days / holidays narrow and shaded), working window per day, now line, bars, machine down-time */
// function GanttBoard({ data, view, from, to, colorOf, focusPo, matches = () => true, keep = null, onHoverPo, onPinPo }) {
//     const today = ymd(new Date());
//     const days = useMemo(() => {
//         if (data?.days?.length) return data.days;
//         const n = from && to ? daysBetween(from, to) + 1 : 0;
//         return Array.from({ length: Math.max(n, 0) }, (_, i) => ({ date: addDays(from, i), working: true, factor: 1 }));
//     }, [data, from, to]);
//     const nWork = Math.max(1, days.filter((d) => d.working).length);
//     const dayW = Math.max(120, Math.min(280, Math.floor(1300 / nWork)));
//     const geo = useMemo(() => {
//         const x = {}; let acc = 0;
//         days.forEach((d) => { x[d.date] = { x: acc, w: d.working ? dayW : OFF_W, d }; acc += d.working ? dayW : OFF_W; });
//         return { x, total: acc };
//     }, [days, dayW]);
//     const winStart = data?.day_window?.start_hour ?? 0;
//     const winEnd = data?.day_window?.end_hour ?? 24;
//     const winLen = Math.max(1, winEnd - winStart);
//     const first = days[0]?.date, last = days[days.length - 1]?.date;

//     const xOf = (iso) => {
//         if (!iso) return null;
//         const dt = iso.slice(0, 10);
//         if (first && dt < first) return 0;
//         if (last && dt > last) return geo.total;
//         const g = geo.x[dt];
//         if (!g) return null;
//         let h = hourOf(iso);
//         if (h < winStart && winEnd > 24) h += 24;            // after midnight of a day that runs past midnight
//         return g.x + Math.min(1, Math.max(0, (h - winStart) / winLen)) * g.w;
//     };

//     const rawRows = view === "machines" ? data?.machines || [] : data?.rows || [];
//     const rows = useMemo(() => rawRows
//         .map((r) => ({ ...r, segments: keep ? (r.segments || []).filter((sg) => keep.has(sg.po)) : r.segments || [] }))
//         .filter((r) => r.segments.length > 0 || (!keep && (r.downtime || []).length > 0))
//         .map((r) => ({ ...r, ...assignLanes(r.segments) })), [rawRows, keep]); // eslint-disable-line react-hooks/exhaustive-deps
//     const nowX = data?.now && first && data.now.slice(0, 10) >= first && data.now.slice(0, 10) <= last ? xOf(data.now) : null;
//     const sectionOf = (r) => (view === "machines" ? r.group : r.section);
//     let lastSection = null;

//     if (!rows.length) return null;
//     return (
//         <Box sx={{ width: LABEL_W + geo.total, position: "relative" }}>
//             {/* header: days, hours, off days with their reason */}
//             <Box sx={{ display: "flex", position: "sticky", top: 0, zIndex: 3, bgcolor: "#f8fafc", borderBottom: "1px solid #e2e8f0" }}>
//                 <Box sx={{ width: LABEL_W, flexShrink: 0, position: "sticky", left: 0, zIndex: 4, bgcolor: "#f8fafc", borderRight: "1px solid #e2e8f0", px: 1.5, display: "flex", alignItems: "center" }}>
//                     <Typography variant="caption" sx={{ fontWeight: 700, color: "#475569" }}>{view === "machines" ? "MACHINE" : "PROCESS"}</Typography>
//                 </Box>
//                 {days.map((d) => {
//                     const g = geo.x[d.date];
//                     const hol = !d.working && !!d.holiday;
//                     return (
//                         <Box key={d.date} sx={{ width: g.w, flexShrink: 0, borderRight: "1px solid #e2e8f0", overflow: "hidden",
//                             bgcolor: d.date === today ? "#eff6ff" : !d.working ? (hol ? "#fef2f2" : "#f1f5f9") : undefined }}>
//                             <Typography variant="caption" noWrap sx={{ display: "block", textAlign: "center", fontWeight: 700, pt: 0.5, px: 0.25,
//                                 color: d.date === today ? "#1d4ed8" : !d.working ? (hol ? "#b91c1c" : "#64748b") : "#334155" }}>
//                                 {d.working ? dayLabel(d.date) : `${d.date.slice(8, 10)} ${dayLabel(d.date).slice(0, 3)}`}
//                             </Typography>
//                             {d.working ? (
//                                 <Box sx={{ display: "flex", justifyContent: "space-between", px: 0.5, pb: 0.3 }}>
//                                     {[winStart, winStart + winLen / 2, winEnd].map((h, i) => (
//                                         <Typography key={i} sx={{ fontSize: 10, color: d.factor < 1 ? "#b45309" : "#94a3b8" }}>{i === 1 && d.factor < 1 ? "half day" : hourText(h % 24)}</Typography>
//                                     ))}
//                                 </Box>
//                             ) : (
//                                 <Tooltip title={d.off_reason || "Off"}>
//                                     <Typography noWrap sx={{ fontSize: 10, textAlign: "center", px: 0.25, pb: 0.3, fontWeight: 700, color: hol ? "#b91c1c" : "#64748b" }}>
//                                         {d.off_reason || "Off"}
//                                     </Typography>
//                                 </Tooltip>
//                             )}
//                         </Box>
//                     );
//                 })}
//             </Box>

//             {/* rows */}
//             {rows.map((r) => {
//                 const h = r.lanes * LANE_H + ROW_PAD * 2 + ((r.downtime || []).length ? 7 : 0);
//                 const sec = sectionOf(r);
//                 const header = sec && sec !== lastSection;
//                 lastSection = sec;
//                 return (
//                     <React.Fragment key={r.row_id}>
//                         {header && (
//                             <Box sx={{ display: "flex", bgcolor: "#f1f5f9", borderBottom: "1px solid #e2e8f0" }}>
//                                 <Box sx={{ width: LABEL_W, position: "sticky", left: 0, bgcolor: "#f1f5f9", px: 1.5, py: 0.3 }}>
//                                     <Typography variant="caption" noWrap title={sec} sx={{ display: "block", fontWeight: 800, letterSpacing: 0.5, color: "#475569" }}>{sec}</Typography>
//                                 </Box>
//                             </Box>
//                         )}
//                         <Box sx={{ display: "flex", borderBottom: "1px solid #f1f5f9", height: h }}>
//                             <Box sx={{ width: LABEL_W, flexShrink: 0, position: "sticky", left: 0, zIndex: 2, bgcolor: "#fff", borderRight: "1px solid #e2e8f0", px: 1.5, display: "flex", flexDirection: "column", justifyContent: "center", minWidth: 0 }}>
//                                 <Typography variant="body2" noWrap title={r.title} sx={{ fontWeight: 600, fontSize: 12.5, color: "#1e293b" }}>
//                                     {r.title}
//                                     {r.kind === "LINE" && <Chip label="LINE" size="small" sx={{ ml: 0.75, height: 16, fontSize: 9 }} />}
//                                 </Typography>
//                                 {view === "machines" && (r.machine_id || r.step) && (
//                                     <Typography noWrap sx={{ fontSize: 11, color: "#64748b" }}>{[r.machine_id, r.step].filter(Boolean).join(" · ")}</Typography>
//                                 )}
//                                 {(r.downtime || []).length > 0 && (
//                                     <Typography noWrap sx={{ fontSize: 11, color: "#b91c1c", fontWeight: 600 }}>⚠ {(r.downtime || []).length} machine stop(s) in range</Typography>
//                                 )}
//                             </Box>
//                             <Box sx={{ position: "relative", width: geo.total, flexShrink: 0 }}>
//                                 {days.map((d) => {
//                                     const g = geo.x[d.date];
//                                     const hol = !d.working && !!d.holiday;
//                                     return <Box key={d.date} sx={{ position: "absolute", top: 0, bottom: 0, left: g.x, width: g.w, borderRight: "1px solid #f1f5f9",
//                                         background: !d.working ? `repeating-linear-gradient(135deg, ${hol ? "#fee2e2" : "#f1f5f9"} 0 6px, ${hol ? "#fecaca" : "#e2e8f0"} 6px 8px)`
//                                             : d.date === today ? "rgba(59,130,246,.05)" : undefined }} />;
//                                 })}
//                                 {(r.downtime || []).map((e, k) => {
//                                     const x1 = xOf(e.start), x2 = xOf(e.end || e.start);
//                                     if (x1 == null || x2 == null) return null;
//                                     return (
//                                         <Tooltip key={`d${k}`} arrow title={<Box sx={{ fontSize: 12 }}><b>{e.label || e.kind || "Down"}</b>{e.machine_name || e.machine ? ` · ${e.machine_name || e.machine}` : ""}<br />{fmt(e.start)} → {fmt(e.end)}{e.note ? <><br />{e.note}</> : null}</Box>}>
//                                             <Box sx={{ position: "absolute", left: x1, width: Math.max(4, x2 - x1), bottom: 2, height: 5, borderRadius: 1,
//                                                 background: "repeating-linear-gradient(135deg, #dc2626 0 4px, #fecaca 4px 7px)" }} />
//                                         </Tooltip>
//                                     );
//                                 })}
//                                 {r.segs.map((sg, k) => {
//                                     const x1 = xOf(sg.start), x2 = xOf(sg.end);
//                                     if (x1 === null || x2 === null) return null;
//                                     const w = Math.max(3, x2 - x1);
//                                     const dim = (focusPo && sg.po !== focusPo) || !matches(sg);
//                                     const tip = (
//                                         <Box sx={{ fontSize: 12, lineHeight: 1.5 }}>
//                                             <b>PO {sg.po}</b> · {sg.part} ({sg.role}){sg.locked ? " · 🔒 assigned - slot kept" : ""}<br />
//                                             {view === "machines" ? sg.operation || r.group : r.name}{sg.step ? ` → ${sg.step}` : ""}<br />
//                                             {fmt(sg.start)} – {hm(sg.end)} ({Math.round(sg.minutes)} min)<br />
//                                             {sg.machine ? <>Machine: {sg.machine}<br /></> : null}
//                                             {sg.batch ? <>Batch {sg.batch.no}/{sg.batch.count}: {sg.batch.qty} of {sg.batch.size} PCBs</> : null}
//                                         </Box>
//                                     );
//                                     const c = colorOf(sg.po);
//                                     return (
//                                         <Tooltip key={k} title={tip} arrow placement="top" disableInteractive>
//                                             <Box onMouseEnter={() => onHoverPo && onHoverPo(sg.po)} onMouseLeave={() => onHoverPo && onHoverPo(null)}
//                                                 onClick={() => onPinPo && onPinPo(sg.po)}
//                                                 sx={{
//                                                     position: "absolute", left: x1, width: w, top: ROW_PAD + sg.lane * LANE_H + 1, height: LANE_H - 3,
//                                                     bgcolor: c, borderRadius: "4px", opacity: dim ? 0.18 : 1, cursor: "pointer",
//                                                     backgroundImage: sg.locked ? "repeating-linear-gradient(135deg, rgba(255,255,255,0.32) 0 4px, transparent 4px 10px)" : "none",
//                                                     color: "#fff", fontSize: 10.5, fontWeight: 600, lineHeight: `${LANE_H - 3}px`, px: 0.5,
//                                                     overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis",
//                                                     boxShadow: focusPo === sg.po ? "0 0 0 2px #0f172a" : "inset 0 0 0 1px rgba(255,255,255,.35)",
//                                                     transition: "opacity .12s",
//                                                 }}>
//                                                 {w > 46 ? `${sg.locked ? "🔒 " : ""}${sg.step && r.kind === "LINE" ? `${sg.po} · ${sg.step}` : sg.po}` : ""}
//                                             </Box>
//                                         </Tooltip>
//                                     );
//                                 })}
//                                 {nowX != null && <Box sx={{ position: "absolute", top: 0, bottom: 0, left: nowX, width: 2, bgcolor: "#ef4444", zIndex: 1 }} />}
//                             </Box>
//                         </Box>
//                     </React.Fragment>
//                 );
//             })}
//             {nowX != null && (
//                 <Box sx={{ position: "absolute", top: 24, left: LABEL_W + nowX - 15, zIndex: 5, bgcolor: "#ef4444", color: "#fff", fontSize: 9.5, fontWeight: 800, px: 0.5, borderRadius: 1, lineHeight: "14px" }}>NOW</Box>
//             )}
//         </Box>
//     );
// }

// /* what the colours / patterns mean */
// function GanttLegend() {
//     const item = (bg, text) => (
//         <Stack direction="row" alignItems="center" spacing={0.6} key={text}>
//             <Box sx={{ width: 22, height: 12, borderRadius: 0.5, background: bg, border: "1px solid #e2e8f0" }} />
//             <Typography sx={{ fontSize: 12, color: "#475569" }}>{text}</Typography>
//         </Stack>
//     );
//     return (
//         <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap alignItems="center">
//             {item("repeating-linear-gradient(135deg, #64748b 0 4px, #94a3b8 4px 10px)", "🔒 Assigned - slot kept")}
//             {item("repeating-linear-gradient(135deg, #f1f5f9 0 6px, #e2e8f0 6px 8px)", "Weekly off day")}
//             {item("repeating-linear-gradient(135deg, #fee2e2 0 6px, #fecaca 6px 8px)", "Holiday")}
//             {item("repeating-linear-gradient(135deg, #dc2626 0 4px, #fecaca 4px 7px)", "Machine down / maintenance / consumable")}
//             {item("#ef4444", "Now")}
//         </Stack>
//     );
// }

// function ScheduleGanttView({ open, onClose, apiBase, authHeaders }) {
//     const today = ymd(new Date());
//     const [from, setFrom] = useState(today);
//     const [to, setTo] = useState(addDays(today, 6));
//     const [planId, setPlanId] = useState("base");         // "base" = the current plan of each plant
//     const [plans, setPlans] = useState([]);
//     const [data, setData] = useState(null);
//     const [loading, setLoading] = useState(false);
//     const [error, setError] = useState(null);
//     const [search, setSearch] = useState("");
//     const [hoverPo, setHoverPo] = useState(null);
//     const [pinPo, setPinPo] = useState(null);
//     const [view, setView] = useState("process");

//     const headers = () => (authHeaders ? authHeaders() : { "x-access-token": localStorage.getItem("token") || "" });
//     const nDays = from && to ? daysBetween(from, to) + 1 : 0;
//     const rangeError = !from || !to ? "Pick both dates"
//         : nDays < 1 ? "'To' must be on or after 'From'"
//             : nDays > MAX_DAYS ? `Pick at most ${MAX_DAYS} days` : null;

//     useEffect(() => {
//         if (!open) return;
//         axios.get(`${apiBase}/schedule/plans`, { headers: headers() })
//             .then((r) => setPlans(r.data?.plans || []))
//             .catch(() => setPlans([]));
//         // eslint-disable-next-line react-hooks/exhaustive-deps
//     }, [open, apiBase]);

//     useEffect(() => {
//         if (!open || rangeError) return;
//         let alive = true;
//         setLoading(true);
//         setError(null);
//         const params = { date_from: from, date_to: to };
//         if (planId !== "base") params.plan_id = planId;
//         axios.get(`${apiBase}/schedule/plans/view`, { headers: headers(), params })
//             .then((r) => { if (alive) setData(r.data); })
//             .catch((e) => { if (alive) { setData(null); setError(e.response?.data?.detail || "Could not load the schedule."); } })
//             .finally(() => { if (alive) setLoading(false); });
//         return () => { alive = false; };
//         // eslint-disable-next-line react-hooks/exhaustive-deps
//     }, [open, apiBase, from, to, planId, rangeError]);

//     const colorOf = useMemo(() => {
//         const m = {};
//         (data?.pos || []).forEach((p, i) => { m[p.production_order] = PALETTE[i % PALETTE.length]; });
//         return (po) => m[po] || "#64748b";
//     }, [data]);
//     const q = search.trim().toLowerCase();
//     const matches = (sg) => !q || sg.po.toLowerCase().includes(q) || (sg.part || "").toLowerCase().includes(q);
//     const setPreset = (n) => { setFrom(today); setTo(addDays(today, n - 1)); };
//     const setMonth = () => {
//         const d = new Date();
//         setFrom(ymd(new Date(d.getFullYear(), d.getMonth(), 1)));
//         setTo(ymd(new Date(d.getFullYear(), d.getMonth() + 1, 0)));
//     };
//     const plan = data?.plans?.[0];
//     const empty = !loading && !error && !rangeError && data && !(view === "machines" ? data.machines : data.rows)?.length;

//     return (
//         <Dialog open={open} onClose={onClose} fullWidth maxWidth="xl" PaperProps={{ sx: { borderRadius: 3, height: "92vh" } }}>
//             <DialogTitle sx={{ display: "flex", alignItems: "center", gap: 1.5, py: 1.5 }}>
//                 <Typography variant="h6" sx={{ fontWeight: 700 }}>Production Schedule</Typography>
//                 <Chip icon={<VisibilityIcon />} label="View only" size="small" variant="outlined" />
//                 {data?.locked_count > 0 && <Chip size="small" label={`🔒 ${data.locked_count} PO assigned - slots kept`} sx={{ bgcolor: "#ffedd5", color: "#7c2d12", fontWeight: 700 }} />}
//                 <Box sx={{ flex: 1 }} />
//                 <ViewToggle value={view} onChange={setView} />
//                 <IconButton onClick={onClose} size="small"><CloseIcon /></IconButton>
//             </DialogTitle>
//             <Divider />
//             <DialogContent sx={{ display: "flex", flexDirection: "column", gap: 1.5, pt: 2 }}>
//                 <Stack direction="row" spacing={1.5} alignItems="center" flexWrap="wrap" useFlexGap>
//                     <TextField label="From" type="date" size="small" value={from} onChange={(e) => setFrom(e.target.value)}
//                         InputLabelProps={{ shrink: true }} sx={{ width: 160 }} />
//                     <TextField label="To" type="date" size="small" value={to} onChange={(e) => setTo(e.target.value)}
//                         InputLabelProps={{ shrink: true }} sx={{ width: 160 }} inputProps={{ min: from }} />
//                     <Stack direction="row" spacing={0.5}>
//                         <Chip label="7 days" size="small" onClick={() => setPreset(7)} />
//                         <Chip label="14 days" size="small" onClick={() => setPreset(14)} />
//                         <Chip label="This month" size="small" onClick={setMonth} />
//                     </Stack>
//                     <PlanSelect value={planId} onChange={setPlanId} plans={plans} />
//                     <TextField placeholder="Find PO / part" size="small" value={search} onChange={(e) => setSearch(e.target.value)}
//                         sx={{ width: 200 }}
//                         InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }} />
//                     <Box sx={{ flex: 1 }} />
//                     {plan && (
//                         <Typography variant="caption" color="text.secondary">
//                             {data.plans.length > 1 ? `${data.plans.length} plans (one per plant)` : `${plan.version_name || plan.name}${plan.reference ? ` · ${plan.reference}` : ""}`}
//                             {plan.created_at ? ` · saved ${fmt(plan.created_at)}` : ""}
//                         </Typography>
//                     )}
//                 </Stack>

//                 {rangeError && <Alert severity="warning">{rangeError}</Alert>}
//                 {error && <Alert severity="error">{error}</Alert>}

//                 <Box sx={{ flex: 1, minHeight: 0, border: "1px solid #e2e8f0", borderRadius: 2, overflow: "auto", position: "relative", bgcolor: "#fff" }}>
//                     {loading && (
//                         <Box sx={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", bgcolor: "rgba(255,255,255,.6)", zIndex: 6 }}>
//                             <CircularProgress size={36} />
//                         </Box>
//                     )}
//                     {empty && (
//                         <Box sx={{ p: 6, textAlign: "center", color: "text.secondary" }}>
//                             {data.plans.length === 0 ? "No saved schedule yet. Save a plan on the Production Schedule page first." : "Nothing is scheduled between these dates."}
//                         </Box>
//                     )}
//                     {!rangeError && data && (
//                         <GanttBoard data={data} view={view} from={from} to={to} colorOf={colorOf} focusPo={hoverPo || pinPo} matches={matches}
//                             onHoverPo={setHoverPo} onPinPo={(po) => setPinPo((p) => (p === po ? null : po))} />
//                     )}
//                 </Box>
//                 <GanttLegend />

//                 {(data?.pos || []).length > 0 && (
//                     <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap alignItems="center">
//                         <Typography variant="caption" sx={{ fontWeight: 700, color: "#475569", mr: 0.5 }}>POs in range:</Typography>
//                         {data.pos.map((p) => (
//                             <Tooltip key={p.production_order} arrow
//                                 title={`${p.part_number} · ${p.role} · qty ${p.quantity} · plan ${fmt(p.start)} → ${fmt(p.end)}${p.forced ? " · scheduled without child PCBs" : ""}${p.locked ? ` · assigned from ${p.lock?.reference || "a saved plan"} - slots kept` : ""}`}>
//                                 <Chip size="small"
//                                     onMouseEnter={() => setHoverPo(p.production_order)} onMouseLeave={() => setHoverPo(null)}
//                                     onClick={() => setPinPo((x) => (x === p.production_order ? null : p.production_order))}
//                                     icon={p.forced ? <WarningAmberIcon sx={{ color: "#b45309 !important" }} /> : undefined}
//                                     label={`${p.locked ? "🔒 " : ""}${p.production_order} · ${p.part_number}`}
//                                     variant={pinPo === p.production_order ? "filled" : "outlined"}
//                                     sx={{ borderColor: colorOf(p.production_order), borderLeft: `6px solid ${colorOf(p.production_order)}`, fontWeight: 600 }} />
//                             </Tooltip>
//                         ))}
//                         {pinPo && <Button size="small" onClick={() => setPinPo(null)}>Clear highlight</Button>}
//                     </Stack>
//                 )}
//             </DialogContent>
//         </Dialog>
//     );
// }


// /* =====================================================================================
//    SCHEDULED POs TAB  (self-contained - owns all of its own state, touches nothing else)
//    ===================================================================================== */

// /* PO numbers can come with / without leading zeros - compare them normalised */
// const normPo = (v) => String(v ?? "").trim().replace(/^0+/, "");
// const PO_KEYS = ["productionOrderNumber", "productionOrder", "ProductionOrder", "production_order", "orderNumber", "order_number", "poNumber", "po_number"];
// const pcbPoOf = (pcb) => {
//     for (const k of PO_KEYS) {
//         if (pcb[k] !== undefined && pcb[k] !== null && String(pcb[k]).trim() !== "") return normPo(pcb[k]);
//     }
//     const k2 = Object.keys(pcb).find((k) => /(prod.*order|^po[_ ]?(no|num))/i.test(k) && String(pcb[k] ?? "").trim() !== "");
//     return k2 ? normPo(pcb[k2]) : "";
// };

// /* Gantt for ONE or SEVERAL chosen POs (read-only), same chart as the full schedule. */
// function PoGanttDialog({ open, onClose, apiBase, plans, initialPlanId, poList, initialFrom, initialTo }) {
//     const [from, setFrom] = useState(initialFrom || ymd(new Date()));
//     const [to, setTo] = useState(initialTo || ymd(new Date()));
//     const [planId, setPlanId] = useState(initialPlanId || "base");
//     const [data, setData] = useState(null);
//     const [loading, setLoading] = useState(false);
//     const [error, setError] = useState(null);
//     const [showAll, setShowAll] = useState(false);
//     const [hoverPo, setHoverPo] = useState(null);
//     const [pinPo, setPinPo] = useState(null);
//     const [view, setView] = useState("process");

//     const headers = () => ({ "x-access-token": localStorage.getItem("token") || "" });
//     const listKey = (poList || []).join("|");

//     useEffect(() => {
//         if (!open) return;
//         setShowAll(false);
//         setPinPo(poList && poList.length === 1 ? poList[0] : null);
//         setPlanId(initialPlanId || "base");
//         if (initialFrom && initialTo) { setFrom(initialFrom); setTo(initialTo); }
//         // eslint-disable-next-line react-hooks/exhaustive-deps
//     }, [open, listKey, initialFrom, initialTo, initialPlanId]);

//     const nDays = from && to ? daysBetween(from, to) + 1 : 0;
//     const rangeError = !from || !to ? "Pick both dates"
//         : nDays < 1 ? "'To' must be on or after 'From'"
//             : nDays > MAX_DAYS ? `Pick at most ${MAX_DAYS} days` : null;

//     useEffect(() => {
//         if (!open || rangeError) return;
//         let alive = true;
//         setLoading(true);
//         setError(null);
//         const params = { date_from: from, date_to: to };
//         if (planId !== "base") params.plan_id = planId;
//         axios.get(`${apiBase}/schedule/plans/view`, { headers: headers(), params })
//             .then((r) => { if (alive) setData(r.data); })
//             .catch((e) => { if (alive) { setData(null); setError(e.response?.data?.detail || "Could not load the schedule."); } })
//             .finally(() => { if (alive) setLoading(false); });
//         return () => { alive = false; };
//         // eslint-disable-next-line react-hooks/exhaustive-deps
//     }, [open, apiBase, from, to, planId, rangeError]);

//     const colorOf = useMemo(() => {
//         const m = {};
//         (data?.pos || []).forEach((p, i) => { m[p.production_order] = PALETTE[i % PALETTE.length]; });
//         return (po) => m[po] || "#64748b";
//     }, [data]);
//     const scoped = poList && poList.length > 0 && !showAll;
//     const keep = useMemo(() => (scoped ? new Set(poList) : null), [scoped, listKey]); // eslint-disable-line react-hooks/exhaustive-deps
//     const shownPos = (data?.pos || []).filter((p) => !keep || keep.has(p.production_order));
//     const label = poList && poList.length === 1 ? `PO ${poList[0]}` : `${(poList || []).length} selected POs`;
//     const hasRows = data && ((view === "machines" ? data.machines : data.rows) || []).some((r) => (r.segments || []).some((sg) => !keep || keep.has(sg.po)));

//     return (
//         <Dialog open={open} onClose={onClose} fullWidth maxWidth="xl" PaperProps={{ sx: { borderRadius: 3, height: "92vh" } }}>
//             <DialogTitle sx={{ display: "flex", alignItems: "center", gap: 1.5, py: 1.5 }}>
//                 <Typography variant="h6" sx={{ fontWeight: 700 }}>
//                     {scoped ? `Production Schedule - ${label}` : "Production Schedule"}
//                 </Typography>
//                 <Chip icon={<VisibilityIcon />} label="View only" size="small" variant="outlined" />
//                 {poList && poList.length > 0 && (
//                     <Button size="small" onClick={() => setShowAll((v) => !v)} sx={{ textTransform: "none", fontWeight: 600 }}>
//                         {showAll ? `Only ${label}` : "Show all POs"}
//                     </Button>
//                 )}
//                 <Box sx={{ flex: 1 }} />
//                 <ViewToggle value={view} onChange={setView} />
//                 <IconButton onClick={onClose} size="small"><CloseIcon /></IconButton>
//             </DialogTitle>
//             <Divider />
//             <DialogContent sx={{ display: "flex", flexDirection: "column", gap: 1.5, pt: 2 }}>
//                 <Stack direction="row" spacing={1.5} alignItems="center" flexWrap="wrap" useFlexGap>
//                     <TextField label="From" type="date" size="small" value={from} onChange={(e) => setFrom(e.target.value)}
//                         InputLabelProps={{ shrink: true }} sx={{ width: 160 }} />
//                     <TextField label="To" type="date" size="small" value={to} onChange={(e) => setTo(e.target.value)}
//                         InputLabelProps={{ shrink: true }} sx={{ width: 160 }} inputProps={{ min: from }} />
//                     <PlanSelect value={planId} onChange={setPlanId} plans={plans} />
//                 </Stack>

//                 {rangeError && <Alert severity="warning">{rangeError}</Alert>}
//                 {error && <Alert severity="error">{error}</Alert>}

//                 <Box sx={{ flex: 1, minHeight: 0, border: "1px solid #e2e8f0", borderRadius: 2, overflow: "auto", position: "relative", bgcolor: "#fff" }}>
//                     {loading && (
//                         <Box sx={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", bgcolor: "rgba(255,255,255,.6)", zIndex: 6 }}>
//                             <CircularProgress size={36} />
//                         </Box>
//                     )}
//                     {!loading && !error && !rangeError && data && !hasRows && (
//                         <Box sx={{ p: 6, textAlign: "center", color: "text.secondary" }}>
//                             {data.plans.length === 0 ? "No saved schedule yet. Save a plan on the Production Schedule page first."
//                                 : scoped ? `${label} not scheduled between these dates on this plan.` : "Nothing is scheduled between these dates."}
//                         </Box>
//                     )}
//                     {!rangeError && data && (
//                         <GanttBoard data={data} view={view} from={from} to={to} colorOf={colorOf} focusPo={hoverPo || pinPo} keep={keep}
//                             onHoverPo={setHoverPo} onPinPo={(po) => setPinPo((p) => (p === po ? null : po))} />
//                     )}
//                 </Box>
//                 <GanttLegend />

//                 {shownPos.length > 0 && (
//                     <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap alignItems="center">
//                         <Typography variant="caption" sx={{ fontWeight: 700, color: "#475569", mr: 0.5 }}>POs shown:</Typography>
//                         {shownPos.map((p) => (
//                             <Chip key={p.production_order} size="small"
//                                 onMouseEnter={() => setHoverPo(p.production_order)} onMouseLeave={() => setHoverPo(null)}
//                                 onClick={() => setPinPo((x) => (x === p.production_order ? null : p.production_order))}
//                                 label={`${p.locked ? "🔒 " : ""}${p.production_order} · ${p.part_number}`}
//                                 variant={pinPo === p.production_order ? "filled" : "outlined"}
//                                 sx={{ borderColor: colorOf(p.production_order), borderLeft: `6px solid ${colorOf(p.production_order)}`, fontWeight: 600 }} />
//                         ))}
//                         {pinPo && <Button size="small" onClick={() => setPinPo(null)}>Clear highlight</Button>}
//                     </Stack>
//                 )}
//             </DialogContent>
//         </Dialog>
//     );
// }

// function ScheduledPOsTab({ active, busy, dbPCBs, getPcbId, apiBase, assignUrl, onAssigned, notify, onViewFull }) {
//     const [from, setFrom] = useState(() => addDays(ymd(new Date()), -7));
//     const [to, setTo] = useState(() => addDays(ymd(new Date()), MAX_DAYS - 8));   // 62 days in total
//     const [planId, setPlanId] = useState("base");            // "base" = baseline plan of each plant
//     const [plans, setPlans] = useState([]);
//     const [pos, setPos] = useState([]);
//     const [plan, setPlan] = useState(null);
//     const [loading, setLoading] = useState(false);
//     const [error, setError] = useState(null);
//     const [search, setSearch] = useState("");
//     const [selected, setSelected] = useState(() => new Set());
//     const [expanded, setExpanded] = useState(null);
//     const [assigning, setAssigning] = useState(null);
//     const [gantt, setGantt] = useState(null);                // { pos:[...], from, to }
//     const [reloadKey, setReloadKey] = useState(0);

//     const headers = () => ({ "x-access-token": localStorage.getItem("token") || "" });

//     const nDays = from && to ? daysBetween(from, to) + 1 : 0;
//     const rangeError = !from || !to ? "Pick both dates"
//         : nDays < 1 ? "'To' must be on or after 'From'"
//             : nDays > MAX_DAYS ? `Pick at most ${MAX_DAYS} days` : null;

//     /* saved plans for the picker */
//     useEffect(() => {
//         if (!active) return;
//         let alive = true;
//         axios.get(`${apiBase}/schedule/plans`, { headers: headers() })
//             .then((r) => { if (alive) setPlans(r.data?.plans || []); })
//             .catch(() => { if (alive) setPlans([]); });
//         return () => { alive = false; };
//         // eslint-disable-next-line react-hooks/exhaustive-deps
//     }, [active, apiBase]);

//     /* scheduled POs of the chosen plan / range */
//     useEffect(() => {
//         if (!active || rangeError) return;
//         let alive = true;
//         setLoading(true);
//         setError(null);
//         const params = { date_from: from, date_to: to };
//         if (planId !== "base") params.plan_id = planId;
//         axios.get(`${apiBase}/schedule/plans/view`, { headers: headers(), params })
//             .then((r) => {
//                 if (!alive) return;
//                 const seen = new Set();
//                 const list = (r.data?.pos || []).filter((p) => {
//                     if (seen.has(p.production_order)) return false;
//                     seen.add(p.production_order);
//                     return true;
//                 });
//                 list.sort((a, b) => String(a.start || "").localeCompare(String(b.start || "")));
//                 setPos(list);
//                 setPlan(r.data?.plans?.[0] || null);
//             })
//             .catch((e) => {
//                 if (!alive) return;
//                 setPos([]);
//                 setPlan(null);
//                 setError(e.response?.data?.detail || "Could not load the scheduled production orders.");
//             })
//             .finally(() => { if (alive) setLoading(false); });
//         return () => { alive = false; };
//         // eslint-disable-next-line react-hooks/exhaustive-deps
//     }, [active, apiBase, from, to, planId, rangeError, reloadKey]);

//     /* un-assigned PCBs (the list the "Assign to Operator" tab shows) grouped by PO */
//     const pcbsByPo = useMemo(() => {
//         const m = {};
//         (dbPCBs || []).forEach((pcb, i) => {
//             const k = pcbPoOf(pcb);
//             if (!k) return;
//             (m[k] = m[k] || []).push({ pcb, id: getPcbId(pcb, i) });
//         });
//         return m;
//         // eslint-disable-next-line react-hooks/exhaustive-deps
//     }, [dbPCBs]);
//     const readyFor = (po) => pcbsByPo[normPo(po)] || [];

//     const rows = useMemo(() => {
//         const q = search.trim().toLowerCase();
//         return pos.filter((p) => !q || String(p.production_order).toLowerCase().includes(q) || String(p.part_number || "").toLowerCase().includes(q));
//     }, [pos, search]);

//     const allSelected = rows.length > 0 && rows.every((p) => selected.has(p.production_order));
//     const someSelected = rows.some((p) => selected.has(p.production_order)) && !allSelected;
//     const readyTotal = rows.filter((p) => readyFor(p.production_order).length > 0).length;

//     const toggle = (po) => setSelected((prev) => { const n = new Set(prev); n.has(po) ? n.delete(po) : n.add(po); return n; });
//     const toggleAll = (checked) => setSelected((prev) => {
//         const n = new Set(prev);
//         rows.forEach((p) => (checked ? n.add(p.production_order) : n.delete(p.production_order)));
//         return n;
//     });

//     /* same request the "Assign Selected" button of the Assign to Operator tab sends */
//     const assignPOs = async (poList, busyKey) => {
//         const user = JSON.parse(localStorage.getItem("user"));
//         if (!user) { notify("User details not found. Please log in.", "error"); return; }
//         const withPcbs = poList.filter((po) => readyFor(po).length > 0);
//         const serials = [];
//         withPcbs.forEach((po) => readyFor(po).forEach((x) => serials.push(x.pcb.PCBserialNoPartNumber)));
//         if (serials.length === 0) { notify("No unassigned PCBs found for the selected PO(s).", "warning"); return; }
//         setAssigning(busyKey);
//         try {
//             await axios.post(assignUrl, { supervisor_staff_no: user?.id, pcb_serial_parts: serials });
//             // the PCBs were assigned from this plan: keep the POs' slots so later schedules plan around them
//             let lockNote = "";
//             try {
//                 const lk = await axios.post(`${apiBase}/schedule/locks`, {
//                     production_order: withPcbs, version_id: planId !== "base" ? planId : null, locked_by: user?.id || null,
//                 }, { headers: headers() });
//                 const n = (lk.data?.locked || []).length;
//                 if (n) lockNote = ` Their schedule slots are kept (${lk.data.locked[0].reference || "saved plan"}).`;
//             } catch (e) {
//                 lockNote = " (Could not keep their schedule slots - the next schedule may move them.)";
//             }
//             const skipped = poList.length - withPcbs.length;
//             notify(`Successfully assigned ${serials.length} PCBs from ${withPcbs.length} PO${withPcbs.length > 1 ? "s" : ""}.${skipped ? ` ${skipped} PO(s) had no PCBs to assign.` : ""}${lockNote}`, "success");
//             setReloadKey((k) => k + 1);
//             setSelected((prev) => { const n = new Set(prev); poList.forEach((po) => n.delete(po)); return n; });
//             onAssigned();
//         } catch (err) {
//             notify(err.response?.data?.detail || "An error occurred during assignment.", "error");
//         } finally {
//             setAssigning(null);
//         }
//     };

//     const openGantt = (list) => {
//         if (!list.length) return;
//         const starts = list.map((x) => (x.start || "").slice(0, 10)).filter(Boolean).sort();
//         const ends = list.map((x) => (x.end || "").slice(0, 10)).filter(Boolean).sort();
//         const f = starts[0] || ymd(new Date());
//         let t = ends[ends.length - 1] || f;
//         if (t < f) t = f;
//         if (daysBetween(f, t) + 1 > MAX_DAYS) t = addDays(f, MAX_DAYS - 1);
//         setGantt({ pos: list.map((x) => x.production_order), from: f, to: t });
//     };

//     const cellSx = { py: 0.75, px: 1, fontSize: "0.85rem" };
//     const headSx = { ...cellSx, bgcolor: "#f8f9fa", fontWeight: 700, whiteSpace: "nowrap" };
//     const preset = (a, b) => { const t = ymd(new Date()); setFrom(addDays(t, a)); setTo(addDays(t, b)); };
//     const picked = pos.filter((p) => selected.has(p.production_order));

//     return (
//         <Box sx={{ display: active && !busy ? "block" : "none" }}>
//             {/* ---------- filters ---------- */}
//             <Paper elevation={0} sx={{ p: 1.5, mb: 1.5, borderRadius: 2.5, border: "1px solid #e2e8f0", bgcolor: "white" }}>
//                 <Stack direction="row" spacing={1.5} alignItems="center" flexWrap="wrap" useFlexGap>
//                     <PlanSelect label="Schedule plan" value={planId} plans={plans} sx={{ flex: "1 1 260px", maxWidth: 380 }}
//                         onChange={(v) => { setPlanId(v); setSelected(new Set()); setExpanded(null); }} />
//                     <TextField label="From" type="date" size="small" value={from} onChange={(e) => setFrom(e.target.value)}
//                         InputLabelProps={{ shrink: true }} sx={{ width: 150 }} />
//                     <TextField label="To" type="date" size="small" value={to} onChange={(e) => setTo(e.target.value)}
//                         InputLabelProps={{ shrink: true }} sx={{ width: 150 }} inputProps={{ min: from }} />
//                     <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap>
//                         <Chip label="Next 7 days" size="small" onClick={() => preset(0, 6)} />
//                         <Chip label="Next 14 days" size="small" onClick={() => preset(0, 13)} />
//                         <Chip label="Widest" size="small" onClick={() => preset(-7, MAX_DAYS - 8)} />
//                     </Stack>
//                     <TextField
//                         placeholder="Search PO / part no"
//                         size="small"
//                         value={search}
//                         onChange={(e) => setSearch(e.target.value)}
//                         sx={{ flex: "1 1 180px", maxWidth: 260 }}
//                         InputProps={{
//                             startAdornment: (<InputAdornment position="start"><SearchIcon color="action" /></InputAdornment>),
//                             endAdornment: search && (<ClearIcon fontSize="small" onClick={() => setSearch("")} style={{ cursor: "pointer" }} />)
//                         }}
//                     />
//                 </Stack>

//                 <Divider sx={{ my: 1.25 }} />

//                 <Stack direction="row" spacing={1.5} alignItems="center" justifyContent="space-between" flexWrap="wrap" useFlexGap>
//                     <Typography variant="body2" sx={{ color: "text.secondary" }}>
//                         <b>{rows.length}</b> PO{rows.length === 1 ? "" : "s"} scheduled · <b>{readyTotal}</b> with PCBs ready
//                         {plan ? ` · ${plan.version_name || plan.name}${plan.reference ? ` (${plan.reference})` : ""}` : ""}
//                         {selected.size > 0 ? ` · ${selected.size} selected` : ""}
//                     </Typography>
//                     <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
//                         <Tooltip title="Reload schedule and PCB list">
//                             <span>
//                                 <IconButton size="small" disabled={loading} onClick={() => { setReloadKey((k) => k + 1); onAssigned(); }}>
//                                     <RefreshIcon fontSize="small" />
//                                 </IconButton>
//                             </span>
//                         </Tooltip>
//                         <Button size="small" variant="outlined" startIcon={<TimelineIcon />} onClick={onViewFull}
//                             sx={{ borderRadius: 2, textTransform: "none", fontWeight: 600 }}>
//                             Full Schedule
//                         </Button>
//                         <Button size="small" variant="outlined" startIcon={<TimelineIcon />} disabled={selected.size === 0}
//                             onClick={() => openGantt(picked)}
//                             sx={{ borderRadius: 2, textTransform: "none", fontWeight: 600 }}>
//                             {selected.size > 0 ? `Gantt (${selected.size})` : "Gantt (selected)"}
//                         </Button>
//                         <Button size="small" variant="contained" disabled={selected.size === 0 || assigning !== null}
//                             startIcon={assigning === "__bulk__" ? <CircularProgress size={14} color="inherit" /> : <AssignmentTurnedInIcon />}
//                             onClick={() => assignPOs(Array.from(selected), "__bulk__")}
//                             sx={{ borderRadius: 2, textTransform: "none", fontWeight: 600 }}>
//                             Assign Selected
//                         </Button>
//                     </Stack>
//                 </Stack>
//             </Paper>

//             {rangeError && <Alert severity="warning" sx={{ mb: 1.5 }}>{rangeError}</Alert>}
//             {error && <Alert severity="error" sx={{ mb: 1.5 }}>{error}</Alert>}

//             {/* ---------- PO list ---------- */}
//             <Paper sx={{ width: "100%", overflow: "hidden", borderRadius: 2.5, border: "1px solid #e2e8f0", boxShadow: "none", position: "relative" }}>
//                 {loading && (
//                     <Box sx={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", bgcolor: "rgba(255,255,255,.6)", zIndex: 5 }}>
//                         <CircularProgress size={36} />
//                     </Box>
//                 )}
//                 <TableContainer sx={{ maxHeight: "58vh", overflowX: "auto" }}>
//                     <Table stickyHeader size="small" sx={{ minWidth: 720 }}>
//                         <TableHead>
//                             <TableRow>
//                                 <TableCell padding="checkbox" sx={{ bgcolor: "#f8f9fa" }}>
//                                     <Checkbox color="primary" size="small" indeterminate={someSelected} checked={allSelected}
//                                         disabled={rows.length === 0} onChange={(e) => toggleAll(e.target.checked)} />
//                                 </TableCell>
//                                 <TableCell sx={{ ...headSx, width: 36 }} />
//                                 <TableCell sx={headSx}>Production Order</TableCell>
//                                 <TableCell sx={headSx}>Part No</TableCell>
//                                 <TableCell sx={headSx}>Type</TableCell>
//                                 <TableCell sx={headSx} align="right">Qty</TableCell>
//                                 <TableCell sx={headSx}>Planned (start → end)</TableCell>
//                                 <TableCell sx={headSx}>PCBs Ready</TableCell>
//                                 <TableCell sx={headSx} align="right">Actions</TableCell>
//                             </TableRow>
//                         </TableHead>
//                         <TableBody>
//                             {rows.length === 0 ? (
//                                 <TableRow>
//                                     <TableCell colSpan={9} align="center" sx={{ py: 6, color: "#64748b" }}>
//                                         {loading ? "Loading..." : error || rangeError ? "" : plan === null
//                                             ? "No saved schedule yet. Save a plan on the Production Schedule page first."
//                                             : "No production orders are scheduled between these dates."}
//                                     </TableCell>
//                                 </TableRow>
//                             ) : rows.map((p) => {
//                                 const po = p.production_order;
//                                 const ready = readyFor(po);
//                                 const isSel = selected.has(po);
//                                 const isOpen = expanded === po;
//                                 return (
//                                     <React.Fragment key={po}>
//                                         <TableRow hover selected={isSel} onClick={() => toggle(po)}
//                                             sx={{ cursor: "pointer", "&.Mui-selected": { bgcolor: "#eff6ff" } }}>
//                                             <TableCell padding="checkbox">
//                                                 <Checkbox color="primary" size="small" checked={isSel}
//                                                     onClick={(e) => e.stopPropagation()} onChange={() => toggle(po)} />
//                                             </TableCell>
//                                             <TableCell sx={{ ...cellSx, px: 0.5 }}>
//                                                 <IconButton size="small" disabled={ready.length === 0}
//                                                     onClick={(e) => { e.stopPropagation(); setExpanded(isOpen ? null : po); }}>
//                                                     {isOpen ? <KeyboardArrowUpIcon fontSize="small" /> : <KeyboardArrowDownIcon fontSize="small" />}
//                                                 </IconButton>
//                                             </TableCell>
//                                             <TableCell sx={{ ...cellSx, fontWeight: 700, whiteSpace: "nowrap" }}>
//                                                 {po}
//                                                 {p.forced && (
//                                                     <Tooltip title="Scheduled without child PCBs">
//                                                         <WarningAmberIcon sx={{ ml: 0.5, fontSize: 16, color: "#b45309", verticalAlign: "text-bottom" }} />
//                                                     </Tooltip>
//                                                 )}
//                                                 {p.locked && (
//                                                     <Tooltip title={`PCBs assigned from ${p.lock?.version_name || "a saved plan"}${p.lock?.reference ? ` (${p.lock.reference})` : ""} - its slots are kept, new schedules plan around them`}>
//                                                         <Chip label="🔒 Slots kept" size="small" sx={{ ml: 0.75, height: 20, fontSize: 11, fontWeight: 700, bgcolor: "#ffedd5", color: "#7c2d12" }} />
//                                                     </Tooltip>
//                                                 )}
//                                             </TableCell>
//                                             <TableCell sx={{ ...cellSx, fontWeight: 600 }}>{p.part_number}</TableCell>
//                                             <TableCell sx={cellSx}>
//                                                 <Chip label={p.role || "-"} size="small" sx={{ bgcolor: "#f1f5f9", fontWeight: 600, height: 22 }} />
//                                             </TableCell>
//                                             <TableCell sx={cellSx} align="right">{p.quantity}</TableCell>
//                                             <TableCell sx={{ ...cellSx, whiteSpace: "nowrap" }}>{fmt(p.start)} → {fmt(p.end)}</TableCell>
//                                             <TableCell sx={cellSx}>
//                                                 {ready.length > 0
//                                                     ? <Chip label={`${ready.length} ready`} size="small" sx={{ fontWeight: 600, height: 22, bgcolor: "#fff7ed", color: "#c2410c" }} />
//                                                     : <Chip label="None" size="small" variant="outlined" sx={{ fontWeight: 600, height: 22, color: "#64748b" }} />}
//                                             </TableCell>
//                                             <TableCell sx={{ ...cellSx, whiteSpace: "nowrap" }} align="right">
//                                                 <Button size="small" variant="outlined" startIcon={<TimelineIcon />}
//                                                     onClick={(e) => { e.stopPropagation(); openGantt([p]); }}
//                                                     sx={{ borderRadius: 2, textTransform: "none", fontWeight: 600, mr: 0.75 }}>
//                                                     Gantt
//                                                 </Button>
//                                                 <Tooltip title={ready.length === 0 ? "No unassigned PCBs found for this PO" : ""}>
//                                                     <span>
//                                                         <Button size="small" variant="contained"
//                                                             startIcon={assigning === po ? <CircularProgress size={14} color="inherit" /> : <AssignmentTurnedInIcon />}
//                                                             disabled={ready.length === 0 || assigning !== null}
//                                                             onClick={(e) => { e.stopPropagation(); assignPOs([po], po); }}
//                                                             sx={{ borderRadius: 2, textTransform: "none", fontWeight: 600 }}>
//                                                             Assign
//                                                         </Button>
//                                                     </span>
//                                                 </Tooltip>
//                                             </TableCell>
//                                         </TableRow>
//                                         <TableRow>
//                                             <TableCell colSpan={9} sx={{ py: 0, px: 1, borderBottom: isOpen ? undefined : "none" }}>
//                                                 <Collapse in={isOpen} timeout="auto" unmountOnExit>
//                                                     <Box sx={{ m: 1, p: 1.5, bgcolor: "#f8fafc", borderRadius: 2, border: "1px solid #e2e8f0" }}>
//                                                         <Typography variant="caption" sx={{ display: "block", mb: 0.75, fontWeight: 700, color: "#475569" }}>
//                                                             PCBs of PO {po} that will be assigned
//                                                         </Typography>
//                                                         <Table size="small" sx={{ bgcolor: "white", borderRadius: 1 }}>
//                                                             <TableHead>
//                                                                 <TableRow>
//                                                                     <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>Serial No</TableCell>
//                                                                     <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>Part No</TableCell>
//                                                                     <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>Category</TableCell>
//                                                                 </TableRow>
//                                                             </TableHead>
//                                                             <TableBody>
//                                                                 {ready.map(({ pcb, id }) => (
//                                                                     <TableRow key={id}>
//                                                                         <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem", fontWeight: 600 }}>{pcb.serialNo || pcb.serialNumber || id}</TableCell>
//                                                                         <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem" }}>{pcb.partNumber}</TableCell>
//                                                                         <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem" }}>{pcb.Type || "UNKNOWN"}</TableCell>
//                                                                     </TableRow>
//                                                                 ))}
//                                                             </TableBody>
//                                                         </Table>
//                                                     </Box>
//                                                 </Collapse>
//                                             </TableCell>
//                                         </TableRow>
//                                     </React.Fragment>
//                                 );
//                             })}
//                         </TableBody>
//                     </Table>
//                 </TableContainer>
//             </Paper>

//             <PoGanttDialog
//                 open={!!gantt}
//                 onClose={() => setGantt(null)}
//                 apiBase={apiBase}
//                 plans={plans}
//                 initialPlanId={planId}
//                 poList={gantt?.pos || null}
//                 initialFrom={gantt?.from || null}
//                 initialTo={gantt?.to || null}
//             />
//         </Box>
//     );
// }


// function AssignPCB() {
//     // --- State Management ---
//     const [dbPCBs, setDbPCBs] = useState([]);
//     const [assignedPCBs, setAssignedPCBs] = useState([]);

//     const [isLoading, setIsLoading] = useState(false);
//     const [error, setError] = useState(null);
//     const [Bid, SetBid] = React.useState("1");

//     // Sub-tab for "TO BE ASSIGNED" section
//     const [subTab, setSubTab] = useState("workload");

//     const [snackbar, setSnackbar] = useState({ open: false, msg: "", type: "info" });

//     const [selectedIds, setSelectedIds] = useState(new Set());
//     const [filterCategory, setFilterCategory] = useState("All");
//     const filterCategories = useMemo(
//         () => ["All", ...Array.from(new Set((dbPCBs || []).map((p) => p.Type).filter((t) => t && t !== "UNKNOWN"))).sort()],
//         [dbPCBs],
//     );
//     const [searchQuery, setSearchQuery] = useState("");
//     const [ganttOpen, setGanttOpen] = useState(false);  // "View Schedule" dialog (read-only)


//     // Workload State
//     const [workloadData, setWorkloadData] = useState({ processLoad: {}, operatorLoad: {}, machineLoad: {} });
//     const [loadingWorkload, setLoadingWorkload] = useState(false);

//     // Expanded Row State for Workload Drill-down
//     const [expandedProcess, setExpandedProcess] = useState(null);
//     const [expandedOperator, setExpandedOperator] = useState(null);
//     const [expandedMachine, setExpandedMachine] = useState(null);

//     // --- Redux & API Configuration ---
//     const configDetails = useSelector((state) => state.MROTDataSavingReducer?.configDetails);

//     var API1 = "/supervisor/assign";
//     var API2 = "/api/pcb/filter?status=Inaction";
//     var API3 = "/supervisor/view";

//     var PythonServer = "http://127.0.0.1:2000" + API1;
//     var PythonServerViewandAssigned = "http://192.168.0.20:2000" + API3;
//     var NodeServerIP = "http://192.168.0.20:8082" + API2;
//     var ScheduleServer = "http://192.168.0.20:2000";

//     if (configDetails !== undefined) {
//         if (configDetails.project && configDetails.project[0].ServerIP) {
//             const serverIPs = configDetails.project[0].ServerIP[0];
//             if (serverIPs.PythonServerIP) {
//                 PythonServer = serverIPs.PythonServerIP + API1;
//                 PythonServerViewandAssigned = serverIPs.PythonServerIP + API3;
//                 NodeServerIP = serverIPs.NodeServerIP + API2;
//                 ScheduleServer = serverIPs.PythonServerIP;

//             }
//         }
//     }

//     function dataSelection(id) {
//         SetBid(id);
//         setError(null);
//         setSearchQuery("");
//         setSelectedIds(new Set());
//         setExpandedProcess(null);
//         setExpandedOperator(null);
//         setExpandedMachine(null);
//         if (id === "1") {
//             setSubTab("workload");
//         }
//     }

//     useEffect(() => {
//         if (Bid === "1") {
//             fetchInactionPCBs();
//             fetchAssignedPCBs(); // Required for Workload Calculation
//         } else if (Bid === "2" || Bid === "3") {
//             fetchAssignedPCBs();
//         }
//     }, [Bid]);

//     useEffect(() => {
//         if (Bid === "1" && assignedPCBs.length > 0) {
//             calculateWorkload();
//         } else if (Bid === "1" && assignedPCBs.length === 0) {
//             setWorkloadData({ processLoad: {}, operatorLoad: {}, machineLoad: {} });
//         }
//     }, [Bid, assignedPCBs, configDetails]);

//     const fetchInactionPCBs = async () => {
//         setIsLoading(true);
//         try {
//             const resp = await axios.get(NodeServerIP);
//             const data = resp.data;

//             const processedData = data.map((each_pcb) => {
//                 let compositeType = each_pcb.Type;
//                 if (!compositeType && each_pcb.type && each_pcb.source) {
//                     compositeType = `${each_pcb.type}`.toUpperCase();
//                 }
//                 return { ...each_pcb, Type: compositeType || "UNKNOWN" };
//             });
//             setDbPCBs(processedData);
//         } catch (error) {
//             setError(error.message || "failed to fetch data");
//             setDbPCBs([]);
//         } finally {
//             setIsLoading(false);
//         }
//     };

//     const fetchAssignedPCBs = async () => {
//         setIsLoading(true);
//         setError(null);
//         const user = JSON.parse(localStorage.getItem("user"));
//         const requestParams = { staff_no: user?.id };

//         try {
//             const response = await axios.get(PythonServerViewandAssigned, { params: requestParams });
//             if (response.data && response.data.pcbs) {
//                 setAssignedPCBs(response.data.pcbs);
//             } else {
//                 setAssignedPCBs([]);
//             }
//         } catch (err) {
//             setError("Failed to load assigned tasks.");
//             setAssignedPCBs([]);
//         } finally {
//             setIsLoading(false);
//         }
//     };


//     // --- Batch Configuration ---
//     const CHILD_BATCH_LIMIT = 30; // Up to 30 child PCBs complete in the same batch time
//     const MAIN_BATCH_LIMIT = 30;   // Placeholder for MAIN processes (1 = one by one until configured)

//     // Optional fallback: Add lowercase stage names here if an API doesn't return process_type="batch"
//     const KNOWN_BATCH_STAGES = new Set([
//         // e.g., "cleaning of pcba", "conformal coating", "hass"
//     ]);

//     // Helper to convert either "HH:MM:SS" or numeric hours into decimal hours
//     const parseProcessTimeToHours = (timeVal) => {
//         if (timeVal === null || timeVal === undefined) return 0;
//         if (typeof timeVal === "number") return timeVal;

//         const str = String(timeVal).trim();
//         if (str.includes(":")) {
//             const parts = str.split(":").map(Number);
//             const [hours = 0, minutes = 0, seconds = 0] = parts;
//             return (hours || 0) + (minutes || 0) / 60 + (seconds || 0) / 3600;
//         }
//         return Number(str) || 0;
//     };

//     // Detects whether a machine/stage is "batch" or "serial"
//     const resolveProcessType = (eqOrStep = {}, normalizedStage = "") => {
//         // 1. Check boolean flags (from process_type table: process_type_batch)
//         if (
//             eqOrStep.process_type_batch === true ||
//             eqOrStep.is_batch === true ||
//             String(eqOrStep.process_type_batch).toLowerCase() === "true"
//         ) {
//             return "batch";
//         }

//         // 2. Check string field (from equipment_details: process_type)
//         const rawType = String(eqOrStep.process_type || eqOrStep.processType || "").trim().toLowerCase();
//         if (rawType.includes("batch")) return "batch";
//         if (rawType.includes("serial") || rawType.includes("series")) return "serial";

//         // 3. Check fallback set
//         if (normalizedStage && KNOWN_BATCH_STAGES.has(normalizedStage)) {
//             return "batch";
//         }

//         return "serial";
//     };

//     // --- Workload Calculation with Individual Operator Grouping ---
//     // const calculateWorkload = async () => {
//     //     setLoadingWorkload(true);
//     //     try {
//     //         const activePCBs = assignedPCBs.filter((pcb) => pcb.Overall_PCB_status !== "COMPLETED");
//     //         const uniquePartNums = [...new Set(activePCBs.map((p) => p.partNumber).filter(Boolean))];

//     //         let pythonServerIp = "http://127.0.0.1:2000";
//     //         if (configDetails?.project?.[0]?.ServerIP?.[0]?.PythonServerIP) {
//     //             pythonServerIp = configDetails.project[0].ServerIP[0].PythonServerIP;
//     //         }

//     //         const timeSource = configDetails?.project?.[0]?.time_source === "sap" ? "sap" : "actual";

//     //         const eqPromise = axios
//     //             .get(`${pythonServerIp}/get_equipment_det_stagenames`, {
//     //                 ...getAuthHeader()
//     //             })
//     //             .catch(() => ({ data: [] }));

//     //         const timePromises = uniquePartNums.map((partNum) =>
//     //             axios
//     //                 .get(`${pythonServerIp}/api/flow/${partNum}`, {
//     //                     ...getAuthHeader(),
//     //                     params: { time_source: timeSource }
//     //                 })
//     //                 .catch(() => ({ data: [] }))
//     //         );

//     //         const [eqResponse, ...responses] = await Promise.all([eqPromise, ...timePromises]);

//     //         const timeMap = {};

//     //         uniquePartNums.forEach((partNum, index) => {
//     //             timeMap[partNum] = {};
//     //             const flowData = Array.isArray(responses[index]?.data) ? responses[index].data : [];

//     //             flowData.forEach((step) => {
//     //                 const hours = parseProcessTimeToHours(step.process_time);
//     //                 const processName = step.step_name || (step.process_detail && step.process_detail.step_name);
//     //                 if (processName) {
//     //                     timeMap[partNum][processName.trim().toLowerCase()] = hours;
//     //                 }
//     //             });
//     //         });

//     //         const processLoad = {};
//     //         const operatorLoad = {};
//     //         const machineLoad = {};
//     //         const processToMachines = {};

//     //         const equipments = Array.isArray(eqResponse.data) ? eqResponse.data : [];
//     //         equipments.forEach((eq) => {
//     //             const machineName = eq.eqpt_name || `Machine ${eq.eqpt_no}`;
//     //             if (!machineLoad[machineName]) {
//     //                 machineLoad[machineName] = { count: 0, totalHours: 0, pcbs: [] };
//     //             }

//     //             if (eq.stage_name) {
//     //                 const normalizedProcess = eq.stage_name.trim().toLowerCase();
//     //                 if (!processToMachines[normalizedProcess]) {
//     //                     processToMachines[normalizedProcess] = [];
//     //                 }
//     //                 if (!processToMachines[normalizedProcess].includes(machineName)) {
//     //                     processToMachines[normalizedProcess].push(machineName);
//     //                 }
//     //             }
//     //         });

//     //         activePCBs.forEach((pcb) => {
//     //             const partNum = pcb.partNumber;
//     //             const rawProcessName = pcb.currentProcessName || pcb.current_step || "Unknown Process";
//     //             const normalizedProcess = rawProcessName.trim().toLowerCase();

//     //             let opNamesArray = [];
//     //             if (Array.isArray(pcb.currentProcessOpeName)) {
//     //                 opNamesArray = pcb.currentProcessOpeName;
//     //             } else if (typeof pcb.currentProcessOpeName === "string" && pcb.currentProcessOpeName.trim()) {
//     //                 opNamesArray = pcb.currentProcessOpeName
//     //                     .split(",")
//     //                     .map((name) => name.trim())
//     //                     .filter(Boolean);
//     //             } else if (pcb.operator && pcb.operator.name && pcb.operator.name !== "YET TO START") {
//     //                 opNamesArray = [pcb.operator.name];
//     //             }

//     //             if (opNamesArray.length === 0) {
//     //                 opNamesArray = ["Unassigned"];
//     //             }

//     //             const timeRequired =
//     //                 timeMap[partNum] && timeMap[partNum][normalizedProcess]
//     //                     ? timeMap[partNum][normalizedProcess]
//     //                     : 0;

//     //             const pcbDetail = {
//     //                 serialNo: pcb.serialNo || "N/A",
//     //                 partNumber: pcb.partNumber || "N/A",
//     //                 poNumber: pcb.Production_order || pcb.productionOrder || pcb.productionOrderNumber || "N/A",
//     //                 processName: rawProcessName,
//     //                 operatorName: opNamesArray.join(", "),
//     //                 timeHours: timeRequired
//     //             };

//     //             // Process Wise Grouping
//     //             if (!processLoad[rawProcessName]) processLoad[rawProcessName] = { count: 0, totalHours: 0, pcbs: [] };
//     //             processLoad[rawProcessName].count += 1;
//     //             processLoad[rawProcessName].totalHours += timeRequired;
//     //             processLoad[rawProcessName].pcbs.push(pcbDetail);

//     //             // Machine Wise Grouping
//     //             const mappedMachines = processToMachines[normalizedProcess];
//     //             if (mappedMachines && mappedMachines.length > 0) {
//     //                 mappedMachines.forEach((machineName) => {
//     //                     if (machineLoad[machineName]) {
//     //                         machineLoad[machineName].count += 1;
//     //                         machineLoad[machineName].totalHours += timeRequired;
//     //                         machineLoad[machineName].pcbs.push(pcbDetail);
//     //                     }
//     //                 });
//     //             }

//     //             // Operator Wise Grouping
//     //             opNamesArray.forEach((singleOpName) => {
//     //                 if (!operatorLoad[singleOpName])
//     //                     operatorLoad[singleOpName] = { count: 0, totalHours: 0, pcbsByProcess: {} };
//     //                 operatorLoad[singleOpName].count += 1;
//     //                 operatorLoad[singleOpName].totalHours += timeRequired;

//     //                 if (!operatorLoad[singleOpName].pcbsByProcess[rawProcessName]) {
//     //                     operatorLoad[singleOpName].pcbsByProcess[rawProcessName] = [];
//     //                 }
//     //                 operatorLoad[singleOpName].pcbsByProcess[rawProcessName].push(pcbDetail);
//     //             });
//     //         });

//     //         setWorkloadData({ processLoad, operatorLoad, machineLoad });
//     //     } catch (error) {
//     //         console.error("Failed to calculate workload", error);
//     //         setSnackbar({ open: true, msg: "Failed to calculate workload. Refer to console.", type: "error" });
//     //         setWorkloadData({ processLoad: {}, operatorLoad: {}, machineLoad: {} });
//     //     } finally {
//     //         setLoadingWorkload(false);
//     //     }
//     // };
//     // --- Workload Calculation with Complete Machine Inventory ---
//     // const calculateWorkload = async () => {
//     //         setLoadingWorkload(true);
//     //         try {
//     //             const activePCBs = assignedPCBs.filter((pcb) => pcb.Overall_PCB_status !== "COMPLETED");
//     //             const uniquePartNums = [...new Set(activePCBs.map((p) => p.partNumber).filter(Boolean))];

//     //             let pythonServerIp = "http://192.168.0.20:2000";
//     //             if (configDetails?.project?.[0]?.ServerIP?.[0]?.PythonServerIP) {
//     //                 pythonServerIp = configDetails.project[0].ServerIP[0].PythonServerIP;
//     //             }

//     //             const timeSource = configDetails?.project?.[0]?.time_source === "sap" ? "sap" : "actual";

//     //             const invEquipPromise = axios
//     //                 .get(`${pythonServerIp}/inventory/equipments`, {
//     //                     ...getAuthHeader()
//     //                 })
//     //                 .catch(() => ({ data: [] }));

//     //             const stageEquipPromise = axios
//     //                 .get(`${pythonServerIp}/get_equipment_det_stagenames`, {
//     //                     ...getAuthHeader()
//     //                 })
//     //                 .catch(() => ({ data: [] }));

//     //             const timePromises = uniquePartNums.map((partNum) =>
//     //                 axios
//     //                     .get(`${pythonServerIp}/api/flow/${partNum}`, {
//     //                         ...getAuthHeader(),
//     //                         params: { time_source: timeSource }
//     //                     })
//     //                     .catch(() => ({ data: [] }))
//     //             );

//     //             const [invResponse, eqResponse, ...responses] = await Promise.all([
//     //                 invEquipPromise,
//     //                 stageEquipPromise,
//     //                 ...timePromises
//     //             ]);

//     //             const timeMap = {};
//     //             const stageProcessTypeMap = {}; // normalizedStage -> "batch" | "serial"

//     //             uniquePartNums.forEach((partNum, index) => {
//     //                 timeMap[partNum] = {};
//     //                 const flowData = Array.isArray(responses[index]?.data) ? responses[index].data : [];

//     //                 flowData.forEach((step) => {
//     //                     const hours = parseProcessTimeToHours(step.process_time);
//     //                     const processName = step.step_name || (step.process_detail && step.process_detail.step_name);
//     //                     if (processName) {
//     //                         const normName = processName.trim().toLowerCase();
//     //                         timeMap[partNum][normName] = hours;

//     //                         // Capture batch/serial info if returned by flow API
//     //                         const stepType = resolveProcessType(step, normName);
//     //                         if (stepType === "batch") {
//     //                             stageProcessTypeMap[normName] = "batch";
//     //                         }
//     //                     }
//     //                 });
//     //             });

//     //             const processLoad = {};
//     //             const operatorLoad = {};
//     //             const machineLoad = {};
//     //             const processToMachines = {};

//     //             const rawInvData = invResponse?.data;
//     //             const masterEquipments =
//     //                 rawInvData && rawInvData[0] && Array.isArray(rawInvData[0].items)
//     //                     ? rawInvData[0].items
//     //                     : Array.isArray(rawInvData)
//     //                     ? rawInvData
//     //                     : [];

//     //             const stageEquipments = Array.isArray(eqResponse?.data) ? eqResponse.data : [];

//     //             const registerMachine = (eq) => {
//     //                 const eqptNo = String(eq.eqpt_no || eq.equip_no || eq.machine_id || "").trim();
//     //                 const eqptName = (eq.eqpt_name || eq.name || "").trim();
//     //                 if (!eqptNo && !eqptName) return;

//     //                 const machineKey = eqptNo && eqptName
//     //                     ? `${eqptName} (${eqptNo})`
//     //                     : eqptName || `Machine ${eqptNo}`;

//     //                 // Determine stage name (avoid treating "Batch"/"Serial" in process_type as a stage name)
//     //                 const rawProcessTypeField = String(eq.process_type || "").trim().toLowerCase();
//     //                 const isProcessTypeMode = ["batch", "serial", "series"].includes(rawProcessTypeField);
//     //                 const stageOrProcess = eq.stage_name || eq.stage || (!isProcessTypeMode ? eq.process_type : "");
//     //                 const normalizedStage = stageOrProcess ? String(stageOrProcess).trim().toLowerCase() : "";

//     //                 const detectedType = resolveProcessType(eq, normalizedStage);
//     //                 if (normalizedStage && detectedType === "batch") {
//     //                     stageProcessTypeMap[normalizedStage] = "batch";
//     //                 }

//     //                 if (!machineLoad[machineKey]) {
//     //                     machineLoad[machineKey] = {
//     //                         eqptNo,
//     //                         eqptName: eqptName || `Machine ${eqptNo}`,
//     //                         processType: detectedType, // "batch" or "serial"
//     //                         count: 0,
//     //                         totalHours: 0,
//     //                         batchCount: 0,
//     //                         pcbs: []
//     //                     };
//     //                 } else if (detectedType === "batch") {
//     //                     machineLoad[machineKey].processType = "batch";
//     //                 }

//     //                 if (normalizedStage) {
//     //                     if (!processToMachines[normalizedStage]) {
//     //                         processToMachines[normalizedStage] = [];
//     //                     }
//     //                     if (!processToMachines[normalizedStage].includes(machineKey)) {
//     //                         processToMachines[normalizedStage].push(machineKey);
//     //                     }
//     //                 }
//     //             };

//     //             masterEquipments.forEach(registerMachine);
//     //             stageEquipments.forEach(registerMachine);

//     //             activePCBs.forEach((pcb) => {
//     //                 const partNum = pcb.partNumber;
//     //                 const rawProcessName = pcb.currentProcessName || pcb.current_step || "Unknown Process";
//     //                 const normalizedProcess = rawProcessName.trim().toLowerCase();
//     //                 const pcbCategory = String(pcb.Type || pcb.type || "").trim().toUpperCase(); // e.g., HEXA-CHILD, OCTA-MAIN

//     //                 let opNamesArray = [];
//     //                 if (Array.isArray(pcb.currentProcessOpeName)) {
//     //                     opNamesArray = pcb.currentProcessOpeName;
//     //                 } else if (typeof pcb.currentProcessOpeName === "string" && pcb.currentProcessOpeName.trim()) {
//     //                     opNamesArray = pcb.currentProcessOpeName
//     //                         .split(",")
//     //                         .map((name) => name.trim())
//     //                         .filter(Boolean);
//     //                 } else if (pcb.operator && pcb.operator.name && pcb.operator.name !== "YET TO START") {
//     //                     opNamesArray = [pcb.operator.name];
//     //                 }

//     //                 if (opNamesArray.length === 0) {
//     //                     opNamesArray = ["Unassigned"];
//     //                 }

//     //                 const timeRequired =
//     //                     timeMap[partNum] && timeMap[partNum][normalizedProcess] !== undefined
//     //                         ? timeMap[partNum][normalizedProcess]
//     //                         : 0;

//     //                 const pcbDetail = {
//     //                     serialNo: pcb.serialNo || "N/A",
//     //                     partNumber: pcb.partNumber || "N/A",
//     //                     pcbType: pcbCategory || "UNKNOWN",
//     //                     poNumber: pcb.Production_order || pcb.productionOrder || pcb.productionOrderNumber || "N/A",
//     //                     processName: rawProcessName,
//     //                     normalizedProcess,
//     //                     operatorName: opNamesArray.join(", "),
//     //                     timeHours: timeRequired
//     //                 };

//     //                 // 1. Process-Wise Grouping
//     //                 if (!processLoad[rawProcessName]) {
//     //                     processLoad[rawProcessName] = { count: 0, totalHours: 0, pcbs: [] };
//     //                 }
//     //                 processLoad[rawProcessName].count += 1;
//     //                 processLoad[rawProcessName].totalHours += timeRequired;
//     //                 processLoad[rawProcessName].pcbs.push(pcbDetail);

//     //                 // 2. Queue PCBs into Mapped Machines (Time is calculated below based on Batch vs Serial)
//     //                 const mappedMachines = processToMachines[normalizedProcess];
//     //                 if (mappedMachines && mappedMachines.length > 0) {
//     //                     mappedMachines.forEach((machineKey) => {
//     //                         if (machineLoad[machineKey]) {
//     //                             machineLoad[machineKey].count += 1;
//     //                             machineLoad[machineKey].pcbs.push(pcbDetail);
//     //                         }
//     //                     });
//     //                 }

//     //                 // 3. Operator-Wise Grouping
//     //                 opNamesArray.forEach((singleOpName) => {
//     //                     if (!operatorLoad[singleOpName]) {
//     //                         operatorLoad[singleOpName] = { count: 0, totalHours: 0, pcbsByProcess: {} };
//     //                     }
//     //                     operatorLoad[singleOpName].count += 1;
//     //                     operatorLoad[singleOpName].totalHours += timeRequired;

//     //                     if (!operatorLoad[singleOpName].pcbsByProcess[rawProcessName]) {
//     //                         operatorLoad[singleOpName].pcbsByProcess[rawProcessName] = [];
//     //                     }
//     //                     operatorLoad[singleOpName].pcbsByProcess[rawProcessName].push(pcbDetail);
//     //                 });
//     //             });

//     //             // --- Calculate Machine Total Hours Based on Process Type (Batch vs Serial) ---
//     //             Object.values(machineLoad).forEach((machine) => {
//     //                 if (machine.pcbs.length === 0) {
//     //                     machine.totalHours = 0;
//     //                     machine.batchCount = 0;
//     //                     return;
//     //                 }

//     //                 // Group queued PCBs on this machine by their stage
//     //                 const pcbsByStage = {};
//     //                 machine.pcbs.forEach((pcbItem) => {
//     //                     const stg = pcbItem.normalizedProcess;
//     //                     if (!pcbsByStage[stg]) pcbsByStage[stg] = [];
//     //                     pcbsByStage[stg].push(pcbItem);
//     //                 });

//     //                 let machineTotalHours = 0;
//     //                 let totalBatchesOnMachine = 0;

//     //                 Object.entries(pcbsByStage).forEach(([stg, pcbsInStage]) => {
//     //                     const isBatchStage =
//     //                         machine.processType === "batch" || stageProcessTypeMap[stg] === "batch";

//     //                     if (isBatchStage) {
//     //                         machine.processType = "batch";

//     //                         // Separate CHILD and MAIN PCBs
//     //                         const childPcbs = pcbsInStage.filter((p) => p.pcbType.includes("CHILD"));
//     //                         const mainPcbs = pcbsInStage.filter((p) => !p.pcbType.includes("CHILD"));

//     //                         // Child PCBs: up to 30 complete in the same cycle time
//     //                         if (childPcbs.length > 0) {
//     //                             const childBatches = Math.ceil(childPcbs.length / CHILD_BATCH_LIMIT);
//     //                             // Use the unit process time for the batch run
//     //                             const unitChildTime = Math.max(...childPcbs.map((p) => Number(p.timeHours) || 0));
//     //                             machineTotalHours += childBatches * unitChildTime;
//     //                             totalBatchesOnMachine += childBatches;
//     //                         }

//     //                         // Main PCBs: uses MAIN_BATCH_LIMIT (currently 1 = serial until specified)
//     //                         if (mainPcbs.length > 0) {
//     //                             if (MAIN_BATCH_LIMIT > 1) {
//     //                                 const mainBatches = Math.ceil(mainPcbs.length / MAIN_BATCH_LIMIT);
//     //                                 const unitMainTime = Math.max(...mainPcbs.map((p) => Number(p.timeHours) || 0));
//     //                                 machineTotalHours += mainBatches * unitMainTime;
//     //                                 totalBatchesOnMachine += mainBatches;
//     //                             } else {
//     //                                 machineTotalHours += mainPcbs.reduce((sum, p) => sum + (Number(p.timeHours) || 0), 0);
//     //                             }
//     //                         }
//     //                     } else {
//     //                         // SERIAL Process: happens one by one
//     //                         machineTotalHours += pcbsInStage.reduce((sum, p) => sum + (Number(p.timeHours) || 0), 0);
//     //                     }
//     //                 });

//     //                 machine.totalHours = machineTotalHours;
//     //                 machine.batchCount = totalBatchesOnMachine;
//     //             });

//     //             setWorkloadData({ processLoad, operatorLoad, machineLoad });
//     //         } catch (error) {
//     //             console.error("Failed to calculate workload", error);
//     //             setSnackbar({ open: true, msg: "Failed to calculate workload. Refer to console.", type: "error" });
//     //             setWorkloadData({ processLoad: {}, operatorLoad: {}, machineLoad: {} });
//     //         } finally {
//     //             setLoadingWorkload(false);
//     //         }
//     //     };
//     // --- Workload Calculation with Complete Machine, Process & Operator Batching ---
// // --- Workload Calculation with Complete Machine, Process & Operator Batching ---
//     const calculateWorkload = async () => {
//         setLoadingWorkload(true);
//         try {
//             const activePCBs = assignedPCBs.filter((pcb) => pcb.Overall_PCB_status !== "COMPLETED");
//             const uniquePartNums = [...new Set(activePCBs.map((p) => p.partNumber).filter(Boolean))];

//             let pythonServerIp = "http://192.168.0.20:2000";
//             if (configDetails?.project?.[0]?.ServerIP?.[0]?.PythonServerIP) {
//                 pythonServerIp = configDetails.project[0].ServerIP[0].PythonServerIP;
//             }

//             const timeSource = configDetails?.project?.[0]?.time_source === "sap" ? "sap" : "actual";

//             const invEquipPromise = axios
//                 .get(`${pythonServerIp}/inventory/equipments`, { ...getAuthHeader() })
//                 .catch(() => ({ data: [] }));

//             const stageEquipPromise = axios
//                 .get(`${pythonServerIp}/get_equipment_det_stagenames`, { ...getAuthHeader() })
//                 .catch(() => ({ data: [] }));

//             // NEW: Fetch process types (Batch vs Serial) dynamically from the database
//             const processTypePromise = axios
//                 .get(`${pythonServerIp}/processtype/all`, { ...getAuthHeader() })
//                 .catch(() => ({ data: [] }));

//             const timePromises = uniquePartNums.map((partNum) =>
//                 axios
//                     .get(`${pythonServerIp}/api/flow/${partNum}`, {
//                         ...getAuthHeader(),
//                         params: { time_source: timeSource }
//                     })
//                     .catch(() => ({ data: [] }))
//             );

//             const [invResponse, eqResponse, procTypeResponse, ...responses] = await Promise.all([
//                 invEquipPromise,
//                 stageEquipPromise,
//                 processTypePromise,
//                 ...timePromises
//             ]);

//             // Build Batch Stage IDs Set from dynamic DB fetch (no hardcoding needed)
//             const processTypes = Array.isArray(procTypeResponse?.data) ? procTypeResponse.data : [];
//             const batchStageIds = new Set();
//             processTypes.forEach(pt => {
//                 if (pt.process_type_batch) {
//                     batchStageIds.add(pt.stage_id);
//                 }
//             });

//             const timeMap = {};
//             const stageProcessTypeMap = {}; // normalizedStage -> "batch" | "serial"

//             uniquePartNums.forEach((partNum, index) => {
//                 timeMap[partNum] = {};
//                 const flowData = Array.isArray(responses[index]?.data) ? responses[index].data : [];

//                 flowData.forEach((step) => {
//                     const hours = parseProcessTimeToHours(step.process_time);
//                     const processName = step.step_name || (step.process_detail && step.process_detail.step_name);
//                     const stageId = step.flow_step_id || step.process_id || step.stage_id || (step.process_detail && step.process_detail.flow_step_id);

//                     if (processName) {
//                         const normName = processName.trim().toLowerCase();
//                         timeMap[partNum][normName] = hours;

//                         let stepType = resolveProcessType(step, normName);
//                         // Override with actual DB value if matched
//                         if (stageId && batchStageIds.has(stageId)) {
//                             stepType = "batch";
//                         }

//                         if (stepType === "batch") {
//                             stageProcessTypeMap[normName] = "batch";
//                         }
//                     }
//                 });
//             });

//             const processLoad = {};
//             const operatorLoad = {};
//             const machineLoad = {};
//             const processToMachines = {};

//             const rawInvData = invResponse?.data;
//             const masterEquipments =
//                 rawInvData && rawInvData[0] && Array.isArray(rawInvData[0].items)
//                     ? rawInvData[0].items
//                     : Array.isArray(rawInvData)
//                         ? rawInvData
//                         : [];
//             const stageEquipments = Array.isArray(eqResponse?.data) ? eqResponse.data : [];

//             const registerMachine = (eq) => {
//                 const eqptNo = String(eq.eqpt_no || eq.equip_no || eq.machine_id || "").trim();
//                 const eqptName = (eq.eqpt_name || eq.name || "").trim();
//                 if (!eqptNo && !eqptName) return;

//                 const machineKey = eqptNo && eqptName
//                     ? `${eqptName} (${eqptNo})`
//                     : eqptName || `Machine ${eqptNo}`;

//                 const rawProcessTypeField = String(eq.process_type || "").trim().toLowerCase();
//                 const isProcessTypeMode = ["batch", "serial", "series"].includes(rawProcessTypeField);
//                 const stageOrProcess = eq.stage_name || eq.stage || (!isProcessTypeMode ? eq.process_type : "");
//                 const normalizedStage = stageOrProcess ? String(stageOrProcess).trim().toLowerCase() : "";
//                 const stageId = eq.stage_id || eq.flow_step_id;

//                 let detectedType = resolveProcessType(eq, normalizedStage);
//                 // Override with actual DB value if matched
//                 if (stageId && batchStageIds.has(stageId)) {
//                     detectedType = "batch";
//                 }

//                 if (normalizedStage && detectedType === "batch") {
//                     stageProcessTypeMap[normalizedStage] = "batch";
//                 }

//                 if (!machineLoad[machineKey]) {
//                     machineLoad[machineKey] = {
//                         eqptNo,
//                         eqptName: eqptName || `Machine ${eqptNo}`,
//                         processType: detectedType,
//                         count: 0,
//                         totalHours: 0,
//                         batchCount: 0,
//                         pcbs: []
//                     };
//                 } else if (detectedType === "batch") {
//                     machineLoad[machineKey].processType = "batch";
//                 }

//                 if (normalizedStage) {
//                     if (!processToMachines[normalizedStage]) {
//                         processToMachines[normalizedStage] = [];
//                     }
//                     if (!processToMachines[normalizedStage].includes(machineKey)) {
//                         processToMachines[normalizedStage].push(machineKey);
//                     }
//                 }
//             };

//             masterEquipments.forEach(registerMachine);
//             stageEquipments.forEach(registerMachine);

//             // 1. Group PCBs into arrays without summing time yet
//             activePCBs.forEach((pcb) => {
//                 const partNum = pcb.partNumber;
//                 const rawProcessName = pcb.currentProcessName || pcb.current_step || "Unknown Process";
//                 const normalizedProcess = rawProcessName.trim().toLowerCase();
//                 const pcbCategory = String(pcb.Type || pcb.type || "").trim().toUpperCase();
//                 const stageId = pcb.currentStepOrder || pcb.current_step_order || pcb.currentStepId;

//                 // Final safety check to perfectly link the active PCB's stage to the batch map
//                 if (stageId && batchStageIds.has(stageId)) {
//                     stageProcessTypeMap[normalizedProcess] = "batch";
//                 }

//                 let opNamesArray = [];
//                 if (Array.isArray(pcb.currentProcessOpeName)) {
//                     opNamesArray = pcb.currentProcessOpeName;
//                 } else if (typeof pcb.currentProcessOpeName === "string" && pcb.currentProcessOpeName.trim()) {
//                     opNamesArray = pcb.currentProcessOpeName
//                         .split(",")
//                         .map((name) => name.trim())
//                         .filter(Boolean);
//                 } else if (pcb.operator && pcb.operator.name && pcb.operator.name !== "YET TO START") {
//                     opNamesArray = [pcb.operator.name];
//                 }

//                 if (opNamesArray.length === 0) {
//                     opNamesArray = ["Unassigned"];
//                 }

//                 const timeRequired =
//                     timeMap[partNum] && timeMap[partNum][normalizedProcess] !== undefined
//                         ? timeMap[partNum][normalizedProcess]
//                         : 0;

//                 const pcbDetail = {
//                     serialNo: pcb.serialNo || "N/A",
//                     partNumber: pcb.partNumber || "N/A",
//                     pcbType: pcbCategory || "UNKNOWN",
//                     poNumber: pcb.Production_order || pcb.productionOrder || pcb.productionOrderNumber || "N/A",
//                     processName: rawProcessName,
//                     normalizedProcess,
//                     operatorName: opNamesArray.join(", "),
//                     timeHours: timeRequired
//                 };

//                 // Process Wise Grouping
//                 if (!processLoad[rawProcessName]) {
//                     processLoad[rawProcessName] = { count: 0, totalHours: 0, pcbs: [] };
//                 }
//                 processLoad[rawProcessName].count += 1;
//                 processLoad[rawProcessName].pcbs.push(pcbDetail);

//                 // Machine Wise Grouping
//                 const mappedMachines = processToMachines[normalizedProcess];
//                 if (mappedMachines && mappedMachines.length > 0) {
//                     mappedMachines.forEach((machineKey) => {
//                         if (machineLoad[machineKey]) {
//                             machineLoad[machineKey].count += 1;
//                             machineLoad[machineKey].pcbs.push(pcbDetail);
//                         }
//                     });
//                 }

//                 // Operator Wise Grouping
//                 opNamesArray.forEach((singleOpName) => {
//                     if (!operatorLoad[singleOpName]) {
//                         operatorLoad[singleOpName] = { count: 0, totalHours: 0, pcbsByProcess: {} };
//                     }
//                     operatorLoad[singleOpName].count += 1;

//                     if (!operatorLoad[singleOpName].pcbsByProcess[rawProcessName]) {
//                         operatorLoad[singleOpName].pcbsByProcess[rawProcessName] = [];
//                     }
//                     operatorLoad[singleOpName].pcbsByProcess[rawProcessName].push(pcbDetail);
//                 });
//             });

//             // --- Helper Function for Batch Mathematics ---
//             const calculateGroupHours = (pcbList, isBatchMode) => {
//                 if (!isBatchMode) {
//                     return pcbList.reduce((sum, p) => sum + (Number(p.timeHours) || 0), 0);
//                 }

//                 let hours = 0;
//                 const childPcbs = pcbList.filter((p) => p.pcbType.includes("CHILD"));
//                 const mainPcbs = pcbList.filter((p) => !p.pcbType.includes("CHILD"));

//                 if (childPcbs.length > 0) {
//                     const childBatches = Math.ceil(childPcbs.length / CHILD_BATCH_LIMIT);
//                     const unitChildTime = Math.max(...childPcbs.map((p) => Number(p.timeHours) || 0));
//                     hours += childBatches * unitChildTime;
//                 }

//                 if (mainPcbs.length > 0) {
//                     if (MAIN_BATCH_LIMIT > 1) {
//                         const mainBatches = Math.ceil(mainPcbs.length / MAIN_BATCH_LIMIT);
//                         const unitMainTime = Math.max(...mainPcbs.map((p) => Number(p.timeHours) || 0));
//                         hours += mainBatches * unitMainTime;
//                     } else {
//                         hours += mainPcbs.reduce((sum, p) => sum + (Number(p.timeHours) || 0), 0);
//                     }
//                 }
//                 return hours;
//             };

//             // --- 2. Calculate Machine Totals ---
//             Object.values(machineLoad).forEach((machine) => {
//                 if (machine.pcbs.length === 0) return;

//                 const pcbsByStage = {};
//                 machine.pcbs.forEach((pcbItem) => {
//                     const stg = pcbItem.normalizedProcess;
//                     if (!pcbsByStage[stg]) pcbsByStage[stg] = [];
//                     pcbsByStage[stg].push(pcbItem);
//                 });

//                 let machineTotalHours = 0;
//                 let totalBatchesOnMachine = 0;

//                 Object.entries(pcbsByStage).forEach(([stg, pcbsInStage]) => {
//                     const isBatchStage = machine.processType === "batch" || stageProcessTypeMap[stg] === "batch";
//                     if (isBatchStage) machine.processType = "batch";

//                     machineTotalHours += calculateGroupHours(pcbsInStage, isBatchStage);

//                     if (isBatchStage) {
//                         const cCount = pcbsInStage.filter((p) => p.pcbType.includes("CHILD")).length;
//                         const mCount = pcbsInStage.filter((p) => !p.pcbType.includes("CHILD")).length;
//                         totalBatchesOnMachine += Math.ceil(cCount / CHILD_BATCH_LIMIT);
//                         if (MAIN_BATCH_LIMIT > 1) {
//                             totalBatchesOnMachine += Math.ceil(mCount / MAIN_BATCH_LIMIT);
//                         }
//                     }
//                 });
//                 machine.totalHours = machineTotalHours;
//                 machine.batchCount = totalBatchesOnMachine;
//             });

//             // --- 3. Calculate Process Totals ---
//             Object.values(processLoad).forEach((proc) => {
//                 const pcbsByStage = {};
//                 proc.pcbs.forEach((p) => {
//                     const stg = p.normalizedProcess;
//                     if (!pcbsByStage[stg]) pcbsByStage[stg] = [];
//                     pcbsByStage[stg].push(p);
//                 });

//                 let procTotal = 0;
//                 let totalBatches = 0;
//                 let isBatchProc = false;

//                 Object.entries(pcbsByStage).forEach(([stg, pcbsInStage]) => {
//                     const isBatchStage = stageProcessTypeMap[stg] === "batch";
//                     if (isBatchStage) isBatchProc = true;

//                     procTotal += calculateGroupHours(pcbsInStage, isBatchStage);

//                     if (isBatchStage) {
//                         const cCount = pcbsInStage.filter((p) => p.pcbType.includes("CHILD")).length;
//                         const mCount = pcbsInStage.filter((p) => !p.pcbType.includes("CHILD")).length;
//                         totalBatches += Math.ceil(cCount / CHILD_BATCH_LIMIT);
//                         if (MAIN_BATCH_LIMIT > 1) {
//                             totalBatches += Math.ceil(mCount / MAIN_BATCH_LIMIT);
//                         }
//                     }
//                 });
//                 proc.totalHours = procTotal;
//                 proc.processType = isBatchProc ? "batch" : "serial";
//                 proc.batchCount = totalBatches;
//             });

//             // --- 4. Calculate Operator Totals ---
//             Object.values(operatorLoad).forEach((op) => {
//                 let opTotal = 0;
//                 op.processStats = {}; // Store batch/serial flag for each expanded stage

//                 Object.entries(op.pcbsByProcess).forEach(([procName, pcbList]) => {
//                     const pcbsByStage = {};
//                     pcbList.forEach((p) => {
//                         const stg = p.normalizedProcess;
//                         if (!pcbsByStage[stg]) pcbsByStage[stg] = [];
//                         pcbsByStage[stg].push(p);
//                     });

//                     let pTotal = 0;
//                     let pBatches = 0;
//                     let pIsBatch = false;

//                     Object.entries(pcbsByStage).forEach(([stg, pcbsInStage]) => {
//                         const isBatchStage = stageProcessTypeMap[stg] === "batch";
//                         if (isBatchStage) pIsBatch = true;

//                         pTotal += calculateGroupHours(pcbsInStage, isBatchStage);

//                         if (isBatchStage) {
//                             const cCount = pcbsInStage.filter((p) => p.pcbType.includes("CHILD")).length;
//                             const mCount = pcbsInStage.filter((p) => !p.pcbType.includes("CHILD")).length;
//                             pBatches += Math.ceil(cCount / CHILD_BATCH_LIMIT);
//                             if (MAIN_BATCH_LIMIT > 1) {
//                                 pBatches += Math.ceil(mCount / MAIN_BATCH_LIMIT);
//                             }
//                         }
//                     });

//                     op.processStats[procName] = {
//                         processType: pIsBatch ? "batch" : "serial",
//                         batchCount: pBatches
//                     };
//                     opTotal += pTotal;
//                 });
//                 op.totalHours = opTotal;
//             });

//             setWorkloadData({ processLoad, operatorLoad, machineLoad });
//         } catch (error) {
//             console.error("Failed to calculate workload", error);
//             setSnackbar({ open: true, msg: "Failed to calculate workload. Refer to console.", type: "error" });
//             setWorkloadData({ processLoad: {}, operatorLoad: {}, machineLoad: {} });
//         } finally {
//             setLoadingWorkload(false);
//         }
//     };

//     const handleAssign = async () => {
//         if (selectedIds.size === 0) return;

//         const user = JSON.parse(localStorage.getItem("user"));
//         if (!user) {
//             setSnackbar({ open: true, msg: "User details not found. Please log in.", type: "error" });
//             return;
//         }

//         const selectedItems = dbPCBs.filter((pcb, index) => {
//             const id = getPcbId(pcb, index);
//             return selectedIds.has(id);
//         });

//         const payload = {
//             supervisor_staff_no: user?.id,
//             pcb_serial_parts: selectedItems.map((item) => item.PCBserialNoPartNumber)
//         };

//         try {
//             await axios.post(PythonServer, payload);

//             // POs of these PCBs that are in the current schedule plan keep their slots (others are ignored by the server)
//             const pos = Array.from(new Set(selectedItems.map((x) => pcbPoOf(x)).filter(Boolean)));
//             let lockNote = "";
//             if (pos.length) {
//                 try {
//                     const lk = await axios.post(`${ScheduleServer}/schedule/locks`, { production_order: pos, locked_by: user?.id || null },
//                         { headers: { "x-access-token": localStorage.getItem("token") || "" } });
//                     const n = (lk.data?.locked || []).length;
//                     if (n) lockNote = ` ${n} PO${n > 1 ? "s keep their" : " keeps its"} schedule slots.`;
//                 } catch (e) { /* no saved plan - nothing to keep */ }
//             }
//             setSnackbar({ open: true, msg: `Successfully assigned ${selectedItems.length} PCBs.${lockNote}`, type: "success" });
//             setSelectedIds(new Set());
//             fetchInactionPCBs();
//             fetchAssignedPCBs();
//         } catch (err) {
//             const errorMsg = err.response?.data?.detail || "An error occurred during assignment.";
//             setSnackbar({ open: true, msg: err.response?.data?.detail || errorMsg, type: "error" });
//         }
//     };

//     function getPcbId(pcb, index) {
//         return pcb.PCBserialNoPartNumber || pcb._pcb_key_id || `unknown-${index}`;
//     }

//     const filterDataBySearch = (data) => {
//         if (!searchQuery) return data;
//         const lowerQuery = searchQuery.toLowerCase();

//         return data.filter((item) => {
//             const serial = (item.serialNo || item.serialNumber || "").toLowerCase();
//             const prodOrder = (item.productionOrderNumber || "").toLowerCase();
//             const orderNo = (item.orderNumber || "").toLowerCase();
//             const partNo = (item.partNumber || "").toLowerCase();

//             return (
//                 serial.includes(lowerQuery) ||
//                 prodOrder.includes(lowerQuery) ||
//                 orderNo.includes(lowerQuery) ||
//                 partNo.includes(lowerQuery)
//             );
//         });
//     };

//     const tab1Data = useMemo(() => {
//         let data = dbPCBs;
//         if (filterCategory !== "All") {
//             data = data.filter((pcb) => pcb.Type === filterCategory);
//         }
//         return filterDataBySearch(data);
//     }, [dbPCBs, filterCategory, searchQuery]);

//     const tab2Data = useMemo(() => {
//         const data = assignedPCBs.filter((pcb) => pcb.Overall_PCB_status !== "COMPLETED");
//         return filterDataBySearch(data);
//     }, [assignedPCBs, searchQuery]);

//     const tab3Data = useMemo(() => {
//         const data = assignedPCBs.filter((pcb) => pcb.Overall_PCB_status === "COMPLETED");
//         return filterDataBySearch(data);
//     }, [assignedPCBs, searchQuery]);

//     const handleSelectAll = (e) => {
//         const isChecked = e.target.checked;
//         const newSelected = new Set(selectedIds);
//         tab1Data.forEach((pcb, i) => {
//             const id = getPcbId(pcb, i);
//             isChecked ? newSelected.add(id) : newSelected.delete(id);
//         });
//         setSelectedIds(newSelected);
//     };

//     const toggleSelect = (id) => {
//         const newSelected = new Set(selectedIds);
//         newSelected.has(id) ? newSelected.delete(id) : newSelected.add(id);
//         setSelectedIds(newSelected);
//     };

//     const isAllSelected = tab1Data.length > 0 && tab1Data.every((pcb, i) => selectedIds.has(getPcbId(pcb, i)));
//     const isIndeterminate = tab1Data.some((pcb, i) => selectedIds.has(getPcbId(pcb, i))) && !isAllSelected;

//     const getDynamicColumns = () => {
//         if (!dbPCBs.length) return [];
//         const firstItem = dbPCBs[0];

//         const EXPLICIT_HIDDEN = [
//             "password",
//             "__v",
//             "linkedOperations",
//             "isWorkAssigned",
//             "Type",
//             "PCBserialNoPartNumber",
//             "updatedAt",
//             "status",
//             "productionOrder",
//             "createdAt"
//         ];

//         return Object.keys(firstItem).filter((key) => {
//             const lowerKey = key.toLowerCase();
//             if (lowerKey === "id" || lowerKey === "_id" || lowerKey.includes("key_id")) return false;
//             if (lowerKey.startsWith("user")) return false;
//             if (EXPLICIT_HIDDEN.includes(key)) return false;
//             return true;
//         });
//     };

//     const dynamicColumns = getDynamicColumns();

//     // Sorted Workload Entries
//     const machineEntries = Object.entries(workloadData.machineLoad || {}).sort(
//         (a, b) => b[1].totalHours - a[1].totalHours
//     );
//     const processEntries = Object.entries(workloadData.processLoad || {}).sort(
//         (a, b) => b[1].totalHours - a[1].totalHours
//     );
//     const operatorEntries = Object.entries(workloadData.operatorLoad || {}).sort(
//         (a, b) => b[1].totalHours - a[1].totalHours
//     );

//     return (
//         <Box sx={{ width: "100%", mx: "auto", fontFamily: "Inter, sans-serif" }}>
//             {/* --- 1. Main Navigation Tabs --- */}
//             <Box sx={{ mt: 0.5, mb: 2, display: "flex", justifyContent: "center", flexWrap: "wrap" }}>
//                 <Paper elevation={0} sx={{ borderRadius: 3, bgcolor: "#e2e8f0", p: 0.6, display: "inline-flex", gap: 1 }}>
//                     {BUTTON_OPTS.map((item) => {
//                         const isActive = Bid === item.id;
//                         return (
//                             <Button
//                                 key={item.id}
//                                 onClick={() => dataSelection(item.id)}
//                                 startIcon={item.icon}
//                                 disableRipple
//                                 sx={{
//                                     borderRadius: "8px",
//                                     px: 2.2,
//                                     py: 0.8,
//                                     fontSize: "0.85rem",
//                                     fontWeight: isActive ? 700 : 600,
//                                     textTransform: "none",
//                                     transition: "all 0.2s cubic-bezier(0.4, 0, 0.2, 1)",
//                                     backgroundColor: isActive ? "#ffffff" : "transparent",
//                                     color: isActive ? "#0f172a" : "#475569",
//                                     boxShadow: isActive ? "0 2px 4px rgba(0, 0, 0, 0.06)" : "none",
//                                     "&:hover": {
//                                         backgroundColor: isActive ? "#ffffff" : "rgba(255, 255, 255, 0.5)",
//                                         color: "#0f172a"
//                                     }
//                                 }}
//                             >
//                                 <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
//                                     <Typography variant="inherit">{item.name}</Typography>
//                                     <Box
//                                         component="span"
//                                         sx={{
//                                             display: "inline-flex",
//                                             alignItems: "center",
//                                             justifyContent: "center",
//                                             px: 0.8,
//                                             minWidth: "22px",
//                                             height: "20px",
//                                             borderRadius: "6px",
//                                             fontSize: "0.75rem",
//                                             fontWeight: 700,
//                                             backgroundColor: isActive ? "#eff6ff" : "rgba(100, 116, 139, 0.15)",
//                                             color: isActive ? "#0d6efd" : "#475569"
//                                         }}
//                                     >
//                                         {item.id === "1" ? tab1Data.length : item.id === "2" ? tab2Data.length : tab3Data.length}
//                                     </Box>
//                                 </Box>
//                             </Button>
//                         );
//                     })}
//                 </Paper>
//             </Box>

//             {/* --- 2. Sub-Tabs for 'TO BE ASSIGNED' (Bid = 1) --- */}
//             {Bid === "1" && (
//                 <Box sx={{ mb: 2, borderBottom: "1px solid #e2e8f0", bgcolor: "#ffffff", borderRadius: "8px 8px 0 0", px: 2, textAlign: 'center' }}>
//                     <Tabs
//                         value={subTab}
//                         onChange={(e, val) => setSubTab(val)}
//                         textColor="primary"
//                         indicatorColor="primary"
//                         centered
//                         sx={{
//                             minHeight: 44,
//                             "& .MuiTab-root": {
//                                 minHeight: 44,
//                                 fontWeight: 700,
//                                 fontSize: "1rem",
//                                 textTransform: "none",
//                                 px: 3,
//                             }
//                         }}
//                     >
//                         <Tab label="Workload Matrix" value="workload" />
//                         <Tab label="Assign to Operator" value="assign" />
//                         <Tab label="Scheduled POs" value="scheduled" />
//                     </Tabs>
//                 </Box>
//             )}

//             {/* --- 3. Action Bar (Search & Filters) - Hides on Workload Sub-Tab --- */}
//             {((Bid === "1" && subTab === "assign") || Bid === "2" || Bid === "3") && (
//                 <Box sx={{ mb: 2.5 }}>
//                     <Paper
//                         elevation={0}
//                         sx={{
//                             p: 2,
//                             borderRadius: 2.5,
//                             border: "1px solid #e2e8f0",
//                             display: "flex",
//                             flexWrap: "wrap",
//                             gap: 2,
//                             alignItems: "center",
//                             justifyContent: "space-between",
//                             bgcolor: "white"
//                         }}
//                     >
//                         <TextField
//                             placeholder="Search Serial No, Order No..."
//                             size="small"
//                             value={searchQuery}
//                             onChange={(e) => setSearchQuery(e.target.value)}
//                             sx={{ width: { xs: "100%", md: 350 } }}
//                             InputProps={{
//                                 startAdornment: (
//                                     <InputAdornment position="start">
//                                         <SearchIcon color="action" />
//                                     </InputAdornment>
//                                 ),
//                                 endAdornment: searchQuery && (
//                                     <ClearIcon
//                                         fontSize="small"
//                                         onClick={() => setSearchQuery("")}
//                                         style={{ cursor: "pointer" }}
//                                     />
//                                 )
//                             }}
//                         />

//                         {Bid === "1" ? (
//                             <Stack direction="row" spacing={2} alignItems="center">
//                                 <FormControl size="small" sx={{ minWidth: 160 }}>
//                                     <InputLabel>Category</InputLabel>
//                                     <Select
//                                         value={filterCategory}
//                                         label="Category"
//                                         onChange={(e) => setFilterCategory(e.target.value)}
//                                     >
//                                         {filterCategories.map((cat) => (
//                                             <MenuItem key={cat} value={cat}>
//                                                 {cat}
//                                             </MenuItem>
//                                         ))}
//                                     </Select>
//                                 </FormControl>
//                                 <Divider orientation="vertical" flexItem />
//                                 {selectedIds.size > 0 && (
//                                     <Chip label={`${selectedIds.size} Selected`} color="primary" size="small" />
//                                 )}
//                                 <Button
//                                     variant="contained"
//                                     color="primary"
//                                     startIcon={<AssignmentTurnedInIcon />}
//                                     disabled={selectedIds.size === 0}
//                                     onClick={handleAssign}
//                                     sx={{ borderRadius: 2, textTransform: "none", fontWeight: 600 }}
//                                 >
//                                     Assign Selected
//                                 </Button>
//                             </Stack>
//                         ) : (
//                             // <Chip
//                             //     label={Bid === "2" ? "Monitoring Live Tasks" : "Archived Tasks"}
//                             //     variant="outlined"
//                             //     color={Bid === "2" ? "info" : "success"}
//                             //     size="small"
//                             // />

//                             <Stack direction="row" spacing={1.5} alignItems="center">
//                                 <Chip
//                                     label={Bid === "2" ? "Monitoring Live Tasks" : "Archived Tasks"}
//                                     variant="outlined"
//                                     color={Bid === "2" ? "info" : "success"}
//                                     size="small"
//                                 />
//                             </Stack>
//                         )}
//                     </Paper>
//                 </Box>
//             )}

//             {/* --- Status Messages --- */}
//             {error && (
//                 <Alert severity="error" sx={{ mb: 2 }}>
//                     {error}
//                 </Alert>
//             )}
//             {(isLoading || loadingWorkload) && (
//                 <Box sx={{ display: "flex", justifyContent: "center", p: 8 }}>
//                     <CircularProgress size={46} thickness={4} />
//                 </Box>
//             )}

//             {/* =========================================================
//             TAB 1 - SUBTAB: WORKLOAD MATRIX (ALL 3 IN SAME HORIZONTAL LANE)
//             Order: 1. Machine-Process | 2. Process-Wise | 3. Operator-Wise
//             ========================================================= */}
//             {Bid === "1" && subTab === "workload" && !isLoading && !loadingWorkload && (
//                 <Box
//                     sx={{
//                         display: "grid",
//                         gridTemplateColumns: {
//                             xs: "1fr",
//                             lg: "repeat(3, minmax(0, 1fr))"
//                         },
//                         gap: 2,
//                         alignItems: "start",
//                         mb: 4
//                     }}
//                 >
//                     {/* 1. FIRST COLUMN: Machine-Process Load Matrix */}
//                     <Paper
//                         elevation={0}
//                         sx={{
//                             borderRadius: 2.5,
//                             border: "1px solid #e2e8f0",
//                             overflow: "hidden",
//                             bgcolor: "#ffffff",
//                             display: "flex",
//                             flexDirection: "column"
//                         }}
//                     >
//                         <Box
//                             sx={{
//                                 px: 1.75,
//                                 py: 1.4,
//                                 bgcolor: "#f8fafc",
//                                 borderBottom: "1px solid #e2e8f0",
//                                 display: "flex",
//                                 alignItems: "center",
//                                 justifyContent: "space-between",
//                                 gap: 1
//                             }}
//                         >
//                             <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0 }}>
//                                 <PrecisionManufacturingIcon sx={{ color: "#0284c7", fontSize: 20, flexShrink: 0 }} />
//                                 <Typography
//                                     variant="subtitle2"
//                                     noWrap
//                                     sx={{ fontWeight: 700, color: "#1e293b", fontSize: "0.9rem" }}
//                                 >
//                                     Machine-Wise Load Matrix
//                                 </Typography>
//                             </Stack>
//                             <Chip
//                                 label={machineEntries.length}
//                                 size="small"
//                                 sx={{
//                                     height: 22,
//                                     bgcolor: "#e0f2fe",
//                                     color: "#0369a1",
//                                     fontWeight: 700,
//                                     fontSize: "0.72rem",
//                                     flexShrink: 0
//                                 }}
//                             />
//                         </Box>

//                         <TableContainer sx={{ maxHeight: "65vh" }}>
//                             <Table stickyHeader size="small">
//                                 <TableHead>
//                                     <TableRow>
//                                         <TableCell sx={{ width: 32, px: 0.5, bgcolor: "#f8fafc" }} />
//                                         <TableCell sx={{ px: 1, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc" }}>
//                                             Machine
//                                         </TableCell>
//                                         <TableCell
//                                             align="center"
//                                             sx={{ px: 1, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc", whiteSpace: "nowrap" }}
//                                         >
//                                             PCBs
//                                         </TableCell>
//                                         <TableCell
//                                             align="right"
//                                             sx={{ px: 1.5, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc", whiteSpace: "nowrap" }}
//                                         >
//                                             Est. Time
//                                         </TableCell>
//                                     </TableRow>
//                                 </TableHead>
//                                 <TableBody>
//                                     {machineEntries.length === 0 ? (
//                                         <TableRow>
//                                             <TableCell colSpan={4} align="center" sx={{ py: 4, color: "#64748b", fontSize: "0.82rem" }}>
//                                                 Loading...
//                                             </TableCell>
//                                         </TableRow>
//                                     ) : (
//                                         machineEntries.map(([machine, data]) => {
//                                             const isExpanded = expandedMachine === machine;
//                                             return (
//                                                 <React.Fragment key={`mach-${machine}`}>
//                                                     <TableRow
//                                                         hover
//                                                         onClick={() => setExpandedMachine(isExpanded ? null : machine)}
//                                                         sx={{
//                                                             cursor: "pointer",
//                                                             bgcolor: isExpanded ? "#f0f9ff" : "inherit",
//                                                             "& > *": { borderBottom: isExpanded ? "none" : undefined }
//                                                         }}
//                                                     >
//                                                         <TableCell sx={{ px: 0.5, py: 0.75, width: 32 }}>
//                                                             <IconButton size="small" sx={{ p: 0.25 }}>
//                                                                 {isExpanded ? (
//                                                                     <KeyboardArrowUpIcon fontSize="small" />
//                                                                 ) : (
//                                                                     <KeyboardArrowDownIcon fontSize="small" />
//                                                                 )}
//                                                             </IconButton>
//                                                         </TableCell>
//                                                         <TableCell
//                                                             sx={{
//                                                                 px: 1,
//                                                                 py: 0.9,
//                                                                 fontWeight: 600,
//                                                                 fontSize: "0.82rem",
//                                                                 color: "#1e293b",
//                                                                 wordBreak: "break-word"
//                                                             }}
//                                                         >
//                                                             <Stack direction="row" spacing={0.75} alignItems="center" flexWrap="wrap">
//                                                                 <span>{machine}</span>
//                                                                 <Chip
//                                                                     label={
//                                                                         data.processType === "batch"
//                                                                             ? `Batch${data.batchCount > 0 ? ` (${data.batchCount})` : ""}`
//                                                                             : "Serial"
//                                                                     }
//                                                                     size="small"
//                                                                     sx={{
//                                                                         height: 18,
//                                                                         fontSize: "0.65rem",
//                                                                         fontWeight: 700,
//                                                                         bgcolor: data.processType === "batch" ? "#fef3c7" : "#f1f5f9",
//                                                                         color: data.processType === "batch" ? "#b45309" : "#475569"
//                                                                     }}
//                                                                 />
//                                                             </Stack>
//                                                         </TableCell>
//                                                         <TableCell align="center" sx={{ px: 0.75, py: 0.9 }}>
//                                                             <Chip
//                                                                 label={data.count}
//                                                                 size="small"
//                                                                 color={data.count > 0 ? "info" : "default"}
//                                                                 variant={data.count > 0 ? "filled" : "outlined"}
//                                                                 sx={{ height: 20, fontSize: "0.72rem", fontWeight: 700 }}
//                                                             />
//                                                         </TableCell>
//                                                         <TableCell
//                                                             align="right"
//                                                             sx={{
//                                                                 px: 1.5,
//                                                                 py: 0.9,
//                                                                 fontWeight: 700,
//                                                                 fontSize: "0.8rem",
//                                                                 color: "#0f172a",
//                                                                 whiteSpace: "nowrap"
//                                                             }}
//                                                         >
//                                                             {formatHours(data.totalHours)}
//                                                         </TableCell>
//                                                     </TableRow>
//                                                     <TableRow>
//                                                         <TableCell style={{ paddingBottom: 0, paddingTop: 0, paddingLeft: 8, paddingRight: 8 }} colSpan={4}>
//                                                             <Collapse in={isExpanded} timeout="auto" unmountOnExit>
//                                                                 <Box
//                                                                     sx={{
//                                                                         my: 1,
//                                                                         p: 1.25,
//                                                                         bgcolor: "#f8fafc",
//                                                                         borderRadius: 1.5,
//                                                                         borderLeft: "3px solid #0284c7"
//                                                                     }}
//                                                                 >
//                                                                     <Typography
//                                                                         variant="caption"
//                                                                         sx={{ display: "block", mb: 0.75, fontWeight: 700, color: "#0369a1" }}
//                                                                     >
//                                                                         PCBs Assigned to {machine}
//                                                                     </Typography>
//                                                                     {data.pcbs.length === 0 ? (
//                                                                         <Typography variant="caption" color="text.secondary">
//                                                                             Loading...
//                                                                         </Typography>
//                                                                     ) : (
//                                                                         <Table size="small" sx={{ bgcolor: "white", borderRadius: 1 }}>
//                                                                             <TableHead>
//                                                                                 <TableRow>
//                                                                                     <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>
//                                                                                         Serial No
//                                                                                     </TableCell>
//                                                                                     <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>
//                                                                                         Part No
//                                                                                     </TableCell>
//                                                                                     <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>
//                                                                                         Stage
//                                                                                     </TableCell>
//                                                                                     <TableCell
//                                                                                         align="right"
//                                                                                         sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem", whiteSpace: "nowrap" }}
//                                                                                     >
//                                                                                         Time
//                                                                                     </TableCell>
//                                                                                 </TableRow>
//                                                                             </TableHead>
//                                                                             <TableBody>
//                                                                                 {data.pcbs.map((p, idx) => (
//                                                                                     <TableRow key={`m-det-${idx}`}>
//                                                                                         <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem", fontWeight: 600 }}>
//                                                                                             {p.serialNo}
//                                                                                         </TableCell>
//                                                                                         <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem" }}>
//                                                                                             {p.partNumber}
//                                                                                         </TableCell>
//                                                                                         <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem" }}>
//                                                                                             {p.processName}
//                                                                                         </TableCell>
//                                                                                         <TableCell
//                                                                                             align="right"
//                                                                                             sx={{ px: 1, py: 0.5, fontSize: "0.74rem", whiteSpace: "nowrap" }}
//                                                                                         >
//                                                                                             {formatHours(p.timeHours)}
//                                                                                         </TableCell>
//                                                                                     </TableRow>
//                                                                                 ))}
//                                                                             </TableBody>
//                                                                         </Table>
//                                                                     )}
//                                                                 </Box>
//                                                             </Collapse>
//                                                         </TableCell>
//                                                     </TableRow>
//                                                 </React.Fragment>
//                                             );
//                                         })
//                                     )}
//                                 </TableBody>
//                             </Table>
//                         </TableContainer>
//                     </Paper>

//                     {/* 2. SECOND COLUMN: Process-Wise Load Matrix */}
//                     <Paper
//                         elevation={0}
//                         sx={{
//                             borderRadius: 2.5,
//                             border: "1px solid #e2e8f0",
//                             overflow: "hidden",
//                             bgcolor: "#ffffff",
//                             display: "flex",
//                             flexDirection: "column"
//                         }}
//                     >
//                         <Box
//                             sx={{
//                                 px: 1.75,
//                                 py: 1.4,
//                                 bgcolor: "#f8fafc",
//                                 borderBottom: "1px solid #e2e8f0",
//                                 display: "flex",
//                                 alignItems: "center",
//                                 justifyContent: "space-between",
//                                 gap: 1
//                             }}
//                         >
//                             <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0 }}>
//                                 <AccountTreeIcon sx={{ color: "#2563eb", fontSize: 20, flexShrink: 0 }} />
//                                 <Typography
//                                     variant="subtitle2"
//                                     noWrap
//                                     sx={{ fontWeight: 700, color: "#1e293b", fontSize: "0.9rem" }}
//                                 >
//                                     Process-Wise Load Matrix
//                                 </Typography>
//                             </Stack>
//                             <Chip
//                                 label={processEntries.length}
//                                 size="small"
//                                 sx={{
//                                     height: 22,
//                                     bgcolor: "#dbeafe",
//                                     color: "#1d4ed8",
//                                     fontWeight: 700,
//                                     fontSize: "0.72rem",
//                                     flexShrink: 0
//                                 }}
//                             />
//                         </Box>

//                         <TableContainer sx={{ maxHeight: "65vh" }}>
//                             <Table stickyHeader size="small">
//                                 <TableHead>
//                                     <TableRow>
//                                         <TableCell sx={{ width: 32, px: 0.5, bgcolor: "#f8fafc" }} />
//                                         <TableCell sx={{ px: 1, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc" }}>
//                                             Process Name
//                                         </TableCell>
//                                         <TableCell
//                                             align="center"
//                                             sx={{ px: 1, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc", whiteSpace: "nowrap" }}
//                                         >
//                                             PCBs
//                                         </TableCell>
//                                         <TableCell
//                                             align="right"
//                                             sx={{ px: 1.5, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc", whiteSpace: "nowrap" }}
//                                         >
//                                             Est. Time
//                                         </TableCell>
//                                     </TableRow>
//                                 </TableHead>
//                                 <TableBody>
//                                     {processEntries.length === 0 ? (
//                                         <TableRow>
//                                             <TableCell colSpan={4} align="center" sx={{ py: 4, color: "#64748b", fontSize: "0.82rem" }}>
//                                                 Loading...
//                                             </TableCell>
//                                         </TableRow>
//                                     ) : (
//                                         processEntries.map(([process, data]) => {
//                                             const isExpanded = expandedProcess === process;
//                                             return (
//                                                 <React.Fragment key={`process-${process}`}>
//                                                     <TableRow
//                                                         hover
//                                                         onClick={() => setExpandedProcess(isExpanded ? null : process)}
//                                                         sx={{
//                                                             cursor: "pointer",
//                                                             bgcolor: isExpanded ? "#eff6ff" : "inherit",
//                                                             "& > *": { borderBottom: isExpanded ? "none" : undefined }
//                                                         }}
//                                                     >
//                                                         <TableCell sx={{ px: 0.5, py: 0.75, width: 32 }}>
//                                                             <IconButton size="small" sx={{ p: 0.25 }}>
//                                                                 {isExpanded ? (
//                                                                     <KeyboardArrowUpIcon fontSize="small" />
//                                                                 ) : (
//                                                                     <KeyboardArrowDownIcon fontSize="small" />
//                                                                 )}
//                                                             </IconButton>
//                                                         </TableCell>
//                                                         <TableCell
//                                                             sx={{
//                                                                 px: 1,
//                                                                 py: 0.9,
//                                                                 fontWeight: 600,
//                                                                 fontSize: "0.82rem",
//                                                                 color: "#1e293b",
//                                                                 wordBreak: "break-word"
//                                                             }}
//                                                         >
//                                                             <Stack direction="row" spacing={0.75} alignItems="center" flexWrap="wrap">
//                                                                 <span>{process}</span>
//                                                                 <Chip
//                                                                     label={
//                                                                         data.processType === "batch"
//                                                                             ? `Batch${data.batchCount > 0 ? ` (${data.batchCount})` : ""}`
//                                                                             : "Serial"
//                                                                     }
//                                                                     size="small"
//                                                                     sx={{
//                                                                         height: 18,
//                                                                         fontSize: "0.65rem",
//                                                                         fontWeight: 700,
//                                                                         bgcolor: data.processType === "batch" ? "#fef3c7" : "#f1f5f9",
//                                                                         color: data.processType === "batch" ? "#b45309" : "#475569"
//                                                                     }}
//                                                                 />
//                                                             </Stack>
//                                                         </TableCell>
//                                                         <TableCell align="center" sx={{ px: 0.75, py: 0.9 }}>
//                                                             <Chip
//                                                                 label={data.count}
//                                                                 size="small"
//                                                                 color="primary"
//                                                                 variant="outlined"
//                                                                 sx={{ height: 20, fontSize: "0.72rem", fontWeight: 700 }}
//                                                             />
//                                                         </TableCell>
//                                                         <TableCell
//                                                             align="right"
//                                                             sx={{
//                                                                 px: 1.5,
//                                                                 py: 0.9,
//                                                                 fontWeight: 700,
//                                                                 fontSize: "0.8rem",
//                                                                 color: "#0f172a",
//                                                                 whiteSpace: "nowrap"
//                                                             }}
//                                                         >
//                                                             {formatHours(data.totalHours)}
//                                                         </TableCell>
//                                                     </TableRow>
//                                                     <TableRow>
//                                                         <TableCell style={{ paddingBottom: 0, paddingTop: 0, paddingLeft: 8, paddingRight: 8 }} colSpan={4}>
//                                                             <Collapse in={isExpanded} timeout="auto" unmountOnExit>
//                                                                 <Box
//                                                                     sx={{
//                                                                         my: 1,
//                                                                         p: 1.25,
//                                                                         bgcolor: "#f8fafc",
//                                                                         borderRadius: 1.5,
//                                                                         borderLeft: "3px solid #2563eb"
//                                                                     }}
//                                                                 >
//                                                                     <Typography
//                                                                         variant="caption"
//                                                                         sx={{ display: "block", mb: 0.75, fontWeight: 700, color: "#1d4ed8" }}
//                                                                     >
//                                                                         Assigned PCBs in {process}
//                                                                     </Typography>
//                                                                     <Table size="small" sx={{ bgcolor: "white", borderRadius: 1 }}>
//                                                                         <TableHead>
//                                                                             <TableRow>
//                                                                                 <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>
//                                                                                     Serial No
//                                                                                 </TableCell>
//                                                                                 <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>
//                                                                                     Part No
//                                                                                 </TableCell>
//                                                                                 <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>
//                                                                                     Operator
//                                                                                 </TableCell>
//                                                                                 <TableCell
//                                                                                     align="right"
//                                                                                     sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem", whiteSpace: "nowrap" }}
//                                                                                 >
//                                                                                     Time
//                                                                                 </TableCell>
//                                                                             </TableRow>
//                                                                         </TableHead>
//                                                                         <TableBody>
//                                                                             {data.pcbs.map((p, idx) => (
//                                                                                 <TableRow key={`p-det-${idx}`}>
//                                                                                     <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem", fontWeight: 600 }}>
//                                                                                         {p.serialNo}
//                                                                                     </TableCell>
//                                                                                     <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem" }}>
//                                                                                         {p.partNumber}
//                                                                                     </TableCell>
//                                                                                     <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem" }}>
//                                                                                         {p.operatorName}
//                                                                                     </TableCell>
//                                                                                     <TableCell
//                                                                                         align="right"
//                                                                                         sx={{ px: 1, py: 0.5, fontSize: "0.74rem", whiteSpace: "nowrap" }}
//                                                                                     >
//                                                                                         {formatHours(p.timeHours)}
//                                                                                     </TableCell>
//                                                                                 </TableRow>
//                                                                             ))}
//                                                                         </TableBody>
//                                                                     </Table>
//                                                                 </Box>
//                                                             </Collapse>
//                                                         </TableCell>
//                                                     </TableRow>
//                                                 </React.Fragment>
//                                             );
//                                         })
//                                     )}
//                                 </TableBody>
//                             </Table>
//                         </TableContainer>
//                     </Paper>

//                     {/* 3. THIRD COLUMN: Operator-Wise Load Matrix */}
//                     <Paper
//                         elevation={0}
//                         sx={{
//                             borderRadius: 2.5,
//                             border: "1px solid #e2e8f0",
//                             overflow: "hidden",
//                             bgcolor: "#ffffff",
//                             display: "flex",
//                             flexDirection: "column"
//                         }}
//                     >
//                         <Box
//                             sx={{
//                                 px: 1.75,
//                                 py: 1.4,
//                                 bgcolor: "#f8fafc",
//                                 borderBottom: "1px solid #e2e8f0",
//                                 display: "flex",
//                                 alignItems: "center",
//                                 justifyContent: "space-between",
//                                 gap: 1
//                             }}
//                         >
//                             <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0 }}>
//                                 <EngineeringIcon sx={{ color: "#7c3aed", fontSize: 20, flexShrink: 0 }} />
//                                 <Typography
//                                     variant="subtitle2"
//                                     noWrap
//                                     sx={{ fontWeight: 700, color: "#1e293b", fontSize: "0.9rem" }}
//                                 >
//                                     Operator-Wise Load Matrix
//                                 </Typography>
//                             </Stack>
//                             <Chip
//                                 label={operatorEntries.length}
//                                 size="small"
//                                 sx={{
//                                     height: 22,
//                                     bgcolor: "#ede9fe",
//                                     color: "#6d28d9",
//                                     fontWeight: 700,
//                                     fontSize: "0.72rem",
//                                     flexShrink: 0
//                                 }}
//                             />
//                         </Box>

//                         <TableContainer sx={{ maxHeight: "65vh" }}>
//                             <Table stickyHeader size="small">
//                                 <TableHead>
//                                     <TableRow>
//                                         <TableCell sx={{ width: 32, px: 0.5, bgcolor: "#f8fafc" }} />
//                                         <TableCell sx={{ px: 1, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc" }}>
//                                             Operator
//                                         </TableCell>
//                                         <TableCell
//                                             align="center"
//                                             sx={{ px: 1, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc", whiteSpace: "nowrap" }}
//                                         >
//                                             Tasks
//                                         </TableCell>
//                                         <TableCell
//                                             align="right"
//                                             sx={{ px: 1.5, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc", whiteSpace: "nowrap" }}
//                                         >
//                                             Est. Time
//                                         </TableCell>
//                                     </TableRow>
//                                 </TableHead>
//                                 <TableBody>
//                                     {operatorEntries.length === 0 ? (
//                                         <TableRow>
//                                             <TableCell colSpan={4} align="center" sx={{ py: 4, color: "#64748b", fontSize: "0.82rem" }}>
//                                                 Loading...
//                                             </TableCell>
//                                         </TableRow>
//                                     ) : (
//                                         operatorEntries.map(([operator, data]) => {
//                                             const isExpanded = expandedOperator === operator;
//                                             return (
//                                                 <React.Fragment key={`op-${operator}`}>
//                                                     <TableRow
//                                                         hover
//                                                         onClick={() => setExpandedOperator(isExpanded ? null : operator)}
//                                                         sx={{
//                                                             cursor: "pointer",
//                                                             bgcolor: isExpanded ? "#f5f3ff" : "inherit",
//                                                             "& > *": { borderBottom: isExpanded ? "none" : undefined }
//                                                         }}
//                                                     >
//                                                         <TableCell sx={{ px: 0.5, py: 0.75, width: 32 }}>
//                                                             <IconButton size="small" sx={{ p: 0.25 }}>
//                                                                 {isExpanded ? (
//                                                                     <KeyboardArrowUpIcon fontSize="small" />
//                                                                 ) : (
//                                                                     <KeyboardArrowDownIcon fontSize="small" />
//                                                                 )}
//                                                             </IconButton>
//                                                         </TableCell>
//                                                         <TableCell
//                                                             sx={{
//                                                                 px: 1,
//                                                                 py: 0.9,
//                                                                 fontWeight: 600,
//                                                                 fontSize: "0.82rem",
//                                                                 color: "#1e293b",
//                                                                 wordBreak: "break-word"
//                                                             }}
//                                                         >
//                                                             {operator}
//                                                         </TableCell>
//                                                         <TableCell align="center" sx={{ px: 0.75, py: 0.9 }}>
//                                                             <Chip
//                                                                 label={data.count}
//                                                                 size="small"
//                                                                 color="secondary"
//                                                                 variant="outlined"
//                                                                 sx={{ height: 20, fontSize: "0.72rem", fontWeight: 700 }}
//                                                             />
//                                                         </TableCell>
//                                                         <TableCell
//                                                             align="right"
//                                                             sx={{
//                                                                 px: 1.5,
//                                                                 py: 0.9,
//                                                                 fontWeight: 700,
//                                                                 fontSize: "0.8rem",
//                                                                 color: "#0f172a",
//                                                                 whiteSpace: "nowrap"
//                                                             }}
//                                                         >
//                                                             {formatHours(data.totalHours)}
//                                                         </TableCell>
//                                                     </TableRow>
//                                                     <TableRow>
//                                                         <TableCell style={{ paddingBottom: 0, paddingTop: 0, paddingLeft: 8, paddingRight: 8 }} colSpan={4}>
//                                                             <Collapse in={isExpanded} timeout="auto" unmountOnExit>
//                                                                 <Box
//                                                                     sx={{
//                                                                         my: 1,
//                                                                         p: 1.25,
//                                                                         bgcolor: "#f8fafc",
//                                                                         borderRadius: 1.5,
//                                                                         borderLeft: "3px solid #7c3aed"
//                                                                     }}
//                                                                 >
//                                                                     <Typography
//                                                                         variant="caption"
//                                                                         sx={{ display: "block", mb: 0.75, fontWeight: 700, color: "#6d28d9" }}
//                                                                     >
//                                                                         Assigned Stages for {operator}
//                                                                     </Typography>
//                                                                     {Object.entries(data.pcbsByProcess).map(
//                                                                         ([procName, pcbsInProc], procIdx) => (
//                                                                             <Box key={`proc-group-${procIdx}`} sx={{ mb: 1.25, mt: 0.5 }}>
//                                                                                 <Stack direction="row" spacing={1} sx={{ mb: 0.75 }}>
//                                                                                     <Chip
//                                                                                         label={`Stage: ${procName}`}
//                                                                                         size="small"
//                                                                                         sx={{
//                                                                                             height: 20,
//                                                                                             fontSize: "0.7rem",
//                                                                                             fontWeight: 700,
//                                                                                             bgcolor: "#e2e8f0",
//                                                                                             color: "#1e293b"
//                                                                                         }}
//                                                                                     />
//                                                                                     {data.processStats && data.processStats[procName] && (
//                                                                                         <Chip
//                                                                                             label={
//                                                                                                 data.processStats[procName].processType === "batch"
//                                                                                                     ? `Batch${data.processStats[procName].batchCount > 0 ? ` (${data.processStats[procName].batchCount})` : ""}`
//                                                                                                     : "Serial"
//                                                                                             }
//                                                                                             size="small"
//                                                                                             sx={{
//                                                                                                 height: 20,
//                                                                                                 fontSize: "0.65rem",
//                                                                                                 fontWeight: 700,
//                                                                                                 bgcolor: data.processStats[procName].processType === "batch" ? "#fef3c7" : "#f1f5f9",
//                                                                                                 color: data.processStats[procName].processType === "batch" ? "#b45309" : "#475569"
//                                                                                             }}
//                                                                                         />
//                                                                                     )}
//                                                                                 </Stack>

//                                                                                 <Table size="small" sx={{ bgcolor: "white", borderRadius: 1 }}>
//                                                                                     <TableHead>
//                                                                                         <TableRow>
//                                                                                             <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>
//                                                                                                 Serial No
//                                                                                             </TableCell>
//                                                                                             <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>
//                                                                                                 Part No
//                                                                                             </TableCell>
//                                                                                             <TableCell
//                                                                                                 align="right"
//                                                                                                 sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem", whiteSpace: "nowrap" }}
//                                                                                             >
//                                                                                                 Time
//                                                                                             </TableCell>
//                                                                                         </TableRow>
//                                                                                     </TableHead>
//                                                                                     <TableBody>
//                                                                                         {pcbsInProc.map((p, idx) => (
//                                                                                             <TableRow key={`o-det-${procIdx}-${idx}`}>
//                                                                                                 <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem", fontWeight: 600 }}>
//                                                                                                     {p.serialNo}
//                                                                                                 </TableCell>
//                                                                                                 <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem" }}>
//                                                                                                     {p.partNumber}
//                                                                                                 </TableCell>
//                                                                                                 <TableCell
//                                                                                                     align="right"
//                                                                                                     sx={{ px: 1, py: 0.5, fontSize: "0.74rem", whiteSpace: "nowrap" }}
//                                                                                                 >
//                                                                                                     {formatHours(p.timeHours)}
//                                                                                                 </TableCell>
//                                                                                             </TableRow>
//                                                                                         ))}
//                                                                                     </TableBody>
//                                                                                 </Table>
//                                                                             </Box>
//                                                                         )
//                                                                     )}
//                                                                 </Box>
//                                                             </Collapse>
//                                                         </TableCell>
//                                                     </TableRow>
//                                                 </React.Fragment>
//                                             );
//                                         })
//                                     )}
//                                 </TableBody>
//                             </Table>
//                         </TableContainer>
//                     </Paper>
//                 </Box>
//             )}

//             {/* =========================================================
//             TAB 1 - SUBTAB: ASSIGN TO OPERATOR
//             ========================================================= */}
//             {Bid === "1" && subTab === "assign" && !isLoading && (
//                 <Box>
//                     <Paper
//                         sx={{
//                             width: "100%",
//                             overflow: "hidden",
//                             borderRadius: 2.5,
//                             border: "1px solid #e2e8f0",
//                             boxShadow: "none"
//                         }}
//                     >
//                         <TableContainer sx={{ maxHeight: "60vh" }}>
//                             <Table stickyHeader size="medium">
//                                 <TableHead>
//                                     <TableRow>
//                                         <TableCell padding="checkbox" sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
//                                             <Checkbox
//                                                 color="primary"
//                                                 indeterminate={isIndeterminate}
//                                                 checked={isAllSelected}
//                                                 onChange={handleSelectAll}
//                                                 disabled={tab1Data.length === 0}
//                                             />
//                                         </TableCell>

//                                         {dynamicColumns.map((col) => (
//                                             <TableCell
//                                                 key={col}
//                                                 sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem", whiteSpace: "nowrap" }}
//                                             >
//                                                 {formatHeader(col)}
//                                             </TableCell>
//                                         ))}
//                                         <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>Category</TableCell>
//                                         <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>Status</TableCell>
//                                     </TableRow>
//                                 </TableHead>
//                                 <TableBody>
//                                     {tab1Data.length === 0 ? (
//                                         <TableRow>
//                                             <TableCell colSpan={100} align="center" sx={{ py: 6, color: "black" }}>
//                                                 Loading...
//                                             </TableCell>
//                                         </TableRow>
//                                     ) : (
//                                         tab1Data.map((pcb, i) => {
//                                             const uniqueId = getPcbId(pcb, i);
//                                             const isSelected = selectedIds.has(uniqueId);
//                                             return (
//                                                 <TableRow
//                                                     hover
//                                                     key={uniqueId}
//                                                     selected={isSelected}
//                                                     onClick={() => toggleSelect(uniqueId)}
//                                                     sx={{ cursor: "pointer", "&.Mui-selected": { bgcolor: "#eff6ff" } }}
//                                                 >
//                                                     <TableCell padding="checkbox" sx={{ opacity: 0.8, fontWeight: 600 }}>
//                                                         <Checkbox
//                                                             color="primary"
//                                                             checked={isSelected}
//                                                             onClick={(e) => {
//                                                                 e.stopPropagation();
//                                                                 toggleSelect(uniqueId);
//                                                             }}
//                                                         />
//                                                     </TableCell>
//                                                     {dynamicColumns.map((col) => (
//                                                         <TableCell key={col} sx={{ opacity: 0.8, fontWeight: 600 }}>
//                                                             {pcb[col]}
//                                                         </TableCell>
//                                                     ))}
//                                                     <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>
//                                                         <Chip
//                                                             label={pcb.Type || "UNKNOWN"}
//                                                             size="small"
//                                                             sx={{ bgcolor: "#f1f5f9", fontWeight: 600 }}
//                                                         />
//                                                     </TableCell>
//                                                     <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>
//                                                         <Chip
//                                                             label="Ready To Assign"
//                                                             size="small"
//                                                             color="warning"
//                                                             sx={{ fontWeight: 600, bgcolor: "#fff7ed", color: "#c2410c" }}
//                                                         />
//                                                     </TableCell>
//                                                 </TableRow>
//                                             );
//                                         })
//                                     )}
//                                 </TableBody>
//                             </Table>
//                         </TableContainer>
//                     </Paper>
//                 </Box>
//             )}

//             {/* =========================================================
//             TAB 2 & 3: ASSIGNED & COMPLETED (Read-Only Views)
//             ========================================================= */}
//             {(Bid === "2" || Bid === "3") && !isLoading && (
//                 <Box>
//                     <Paper
//                         sx={{
//                             width: "100%",
//                             overflow: "hidden",
//                             borderRadius: 2.5,
//                             border: "1px solid #e2e8f0",
//                             boxShadow: "none"
//                         }}
//                     >
//                         <TableContainer sx={{ maxHeight: "65vh" }}>
//                             <Table stickyHeader>
//                                 {Bid === "3" ? (
//                                     <TableHead>
//                                         <TableRow>
//                                             <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
//                                                 Serial No
//                                             </TableCell>
//                                             <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
//                                                 Part Number
//                                             </TableCell>
//                                             <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
//                                                 PCB Type
//                                             </TableCell>
//                                             <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
//                                                 Overall Status
//                                             </TableCell>
//                                         </TableRow>
//                                     </TableHead>
//                                 ) : (
//                                     <TableHead>
//                                         <TableRow>
//                                             <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
//                                                 Part Number
//                                             </TableCell>
//                                             <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
//                                                 Serial No
//                                             </TableCell>
//                                             <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
//                                                 Current Stage
//                                             </TableCell>
//                                             <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
//                                                 Operator
//                                             </TableCell>
//                                             <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
//                                                 Current Stage ID
//                                             </TableCell>
//                                             <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
//                                                 Step Status
//                                             </TableCell>
//                                             <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
//                                                 Overall Status
//                                             </TableCell>
//                                         </TableRow>
//                                     </TableHead>
//                                 )}
//                                 <TableBody>
//                                     {Bid === "2" ? (
//                                         tab2Data.length === 0 ? (
//                                             <TableRow>
//                                                 <TableCell colSpan={7} align="center" sx={{ opacity: 0.8, fontWeight: 600 }}>
//                                                     Loading...
//                                                 </TableCell>
//                                             </TableRow>
//                                         ) : (
//                                             tab2Data.map((row, index) => (
//                                                 <TableRow key={index} hover>
//                                                     <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>{row.partNumber}</TableCell>
//                                                     <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>{row.serialNo}</TableCell>
//                                                     <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>
//                                                         <Typography sx={{ opacity: 0.8, fontWeight: 600 }}>
//                                                             {row.currentProcessName}
//                                                         </Typography>
//                                                     </TableCell>
//                                                     <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>
//                                                         <Stack direction="row" alignItems="center" spacing={1}>
//                                                             <PersonIcon fontSize="small" sx={{ opacity: 0.8, fontWeight: 600 }} />
//                                                             <Box>
//                                                                 {row.currentProcessOpeName ? (
//                                                                     <Typography sx={{ opacity: 0.8, fontWeight: 600 }}>
//                                                                         {Array.isArray(row.currentProcessOpeName)
//                                                                             ? row.currentProcessOpeName.join(", ")
//                                                                             : String(row.currentProcessOpeName).replace(/ , $/g, "")}
//                                                                     </Typography>
//                                                                 ) : (
//                                                                     <Typography sx={{ opacity: 0.8, fontWeight: 600 }}>
//                                                                         Unassigned
//                                                                     </Typography>
//                                                                 )}
//                                                                 {row.currentProcessOpeStaffno && (
//                                                                     <Typography sx={{ opacity: 0.8, fontWeight: 600 }}>
//                                                                         ID:{" "}
//                                                                         {Array.isArray(row.currentProcessOpeStaffno)
//                                                                             ? row.currentProcessOpeStaffno.join(", ")
//                                                                             : String(row.currentProcessOpeStaffno).replace(/ , $/g, "")}
//                                                                     </Typography>
//                                                                 )}
//                                                             </Box>
//                                                         </Stack>
//                                                     </TableCell>
//                                                     <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>
//                                                         <Typography sx={{ opacity: 0.8, fontWeight: 600 }}>
//                                                             Stage: {row.currentStepOrder}
//                                                         </Typography>
//                                                     </TableCell>
//                                                     <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>
//                                                         <Chip
//                                                             label={row.currentProcessstatus || "Pending"}
//                                                             size="small"
//                                                             sx={{
//                                                                 bgcolor:
//                                                                     row.currentProcessstatus === "Start" ? "#dbeafe" : "#f1f5f9",
//                                                                 color:
//                                                                     row.currentProcessstatus === "Start" ? "#1e40af" : "#475569",
//                                                                 fontWeight: 600
//                                                             }}
//                                                         />
//                                                     </TableCell>
//                                                     <TableCell>
//                                                         <Chip
//                                                             label={row.Overall_PCB_status}
//                                                             size="small"
//                                                             color={row.Overall_PCB_status === "Completed" ? "success" : "default"}
//                                                             variant={row.Overall_PCB_status === "Completed" ? "filled" : "outlined"}
//                                                             sx={{ fontWeight: 600 }}
//                                                         />
//                                                     </TableCell>
//                                                 </TableRow>
//                                             ))
//                                         )
//                                     ) : tab3Data.length === 0 ? (
//                                         <TableRow>
//                                             <TableCell colSpan={7} align="center" sx={{ opacity: 0.8, fontWeight: 600 }}>
//                                                 No Completed PCBs found.
//                                             </TableCell>
//                                         </TableRow>
//                                     ) : (
//                                         tab3Data.map((row, index) => (
//                                             <TableRow key={index} hover>
//                                                 <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>{row.serialNo}</TableCell>
//                                                 <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>{row.partNumber}</TableCell>
//                                                 <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>
//                                                     <Chip
//                                                         label={row.Type || "Pending"}
//                                                         size="small"
//                                                         sx={{
//                                                             bgcolor: row.currentProcessstatus === "Start" ? "#dbeafe" : "#f1f5f9",
//                                                             color: row.currentProcessstatus === "Start" ? "#1e40af" : "#475569",
//                                                             fontWeight: 600
//                                                         }}
//                                                     />
//                                                 </TableCell>
//                                                 <TableCell>
//                                                     <Chip
//                                                         label={row.Overall_PCB_status}
//                                                         size="small"
//                                                         color={row.Overall_PCB_status === "Completed" ? "success" : "default"}
//                                                         variant={row.Overall_PCB_status === "Completed" ? "filled" : "outlined"}
//                                                         sx={{ fontWeight: 600 }}
//                                                     />
//                                                 </TableCell>
//                                             </TableRow>
//                                         ))
//                                     )}
//                                 </TableBody>
//                             </Table>
//                         </TableContainer>
//                     </Paper>
//                 </Box>
//             )}

//             {/* TAB 1 - SUBTAB: SCHEDULED POs (self-contained; stays mounted so its filters survive tab switches) */}
//             <ScheduledPOsTab
//                 active={Bid === "1" && subTab === "scheduled"}
//                 busy={isLoading}
//                 dbPCBs={dbPCBs}
//                 getPcbId={getPcbId}
//                 apiBase={ScheduleServer}
//                 assignUrl={PythonServer}
//                 onAssigned={() => { fetchInactionPCBs(); fetchAssignedPCBs(); }}
//                 notify={(msg, type) => setSnackbar({ open: true, msg, type })}
//                 onViewFull={() => setGanttOpen(true)}
//             />

//             <ScheduleGanttView
//                 open={ganttOpen}
//                 onClose={() => setGanttOpen(false)}
//                 apiBase={ScheduleServer}
//                 authHeaders={() => ({ "x-access-token": localStorage.getItem("token") || "" })}
//             />

//             <Snackbar
//                 open={snackbar.open}
//                 autoHideDuration={4000}
//                 onClose={() => setSnackbar({ ...snackbar, open: false })}
//                 anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
//             >
//                 <Alert
//                     variant="filled"
//                     onClose={() => setSnackbar({ ...snackbar, open: false })}
//                     severity={snackbar.type}
//                     sx={{ width: "100%", borderRadius: 2 }}
//                 >
//                     {snackbar.msg}
//                 </Alert>
//             </Snackbar>
//         </Box>
//     );
// }

// export default AssignPCB;












import React, { useState, useEffect, useMemo } from "react";
import axios from "../../AxiosInstance/axiosInstance";
import {
    Box,
    Button,
    Typography,
    Table,
    TableHead,
    TableRow,
    TableCell,
    TableBody,
    Paper,
    Alert,
    CircularProgress,
    TableContainer,
    Checkbox,
    Stack,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Chip,
    Snackbar,
    TextField,
    InputAdornment,
    Divider,
    IconButton,
    Collapse,
    Tabs,
    Tab,Dialog,
    DialogTitle,
    DialogContent,
    Tooltip,
    DialogActions
} from "@mui/material";
import ClearIcon from "@mui/icons-material/Clear";

// Icons
import AssignmentTurnedInIcon from "@mui/icons-material/AssignmentTurnedIn";
import ListAltIcon from "@mui/icons-material/ListAlt";
import PersonIcon from "@mui/icons-material/Person";
import SearchIcon from "@mui/icons-material/Search";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import PrecisionManufacturingIcon from "@mui/icons-material/PrecisionManufacturing";
import AccountTreeIcon from "@mui/icons-material/AccountTree";
import EngineeringIcon from "@mui/icons-material/Engineering";

import { useSelector } from "react-redux";
import { CheckCircleIcon } from "lucide-react";
import AssignmentInd from "@mui/icons-material/AssignmentInd";
import TimelineIcon from '@mui/icons-material/Timeline';

import CloseIcon from '@mui/icons-material/Close';
import VisibilityIcon from '@mui/icons-material/Visibility';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import RefreshIcon from '@mui/icons-material/Refresh';
// --- Configuration & Constants ---

const BUTTON_OPTS = [
    {
        id: "1",
        name: "TO BE ASSIGNED",
        icon: <ListAltIcon sx={{ color: "#b26a00" }} />,
        color: "warning"
    },
    {
        id: "2",
        name: "ASSIGNED",
        icon: <AssignmentInd sx={{ color: "#455a64" }} />,
        color: "info"
    },
    {
        id: "3",
        name: "COMPLETED",
        icon: <CheckCircleIcon sx={{ color: "#2e7d32" }} />,
        color: "success"
    }
];

const FILTER_CATEGORIES = [
    "All",
    "HEXA-CHILD",
    "HEXA-MAIN",
    "OCTA-CHILD",
    "OCTA-MAIN"
];

const formatHeader = (key) => {
    const map = {
        PCBserialNoPartNumber: "Serial / Part No",
        productionOrderNumber: "Prod. Order No",
        orderNumber: "Order No",
        createdAt: "Created Date",
        updatedAt: "Last Updated",
        serialNumber: "Serial No",
        partNumber: "Part No",
        type: "Type",
        quantity: "Qty"
    };
    if (map[key]) return map[key];

    return key
        .replace(/([A-Z])/g, " $1")
        .replace(/_/g, " ")
        .replace(/^./, (str) => str.toUpperCase())
        .trim();
};

const getAuthHeader = () => {
    const token = localStorage.getItem("token");
    return token ? { headers: { Authorization: `Bearer ${token}` } } : {};
};

// Process times are stored and returned in HOURS (e.g. 0.1, 1, 5.6) - no HH:MM:SS
const formatHours = (hours) => `${(Number(hours) || 0).toFixed(2)} h`;




// =====================================================================================
// Read-only Gantt of the SAVED production schedule for a date range ("View Schedule" button)
// Backend: GET {apiBase}/schedule/plans/view?date_from=YYYY-MM-DD&date_to=YYYY-MM-DD[&plan_id=]
//          (default = baseline plan of each plant)   GET {apiBase}/schedule/plans -> plan picker
// =====================================================================================
const PALETTE = ["#2563eb", "#16a34a", "#d97706", "#9333ea", "#dc2626", "#0891b2", "#db2777", "#65a30d",
    "#7c3aed", "#ea580c", "#0d9488", "#4f46e5", "#b45309", "#be123c", "#15803d", "#1d4ed8"];
const LABEL_W = 250;      // left column (process names)
const LANE_H = 22;        // one bar lane
const ROW_PAD = 6;
const MAX_DAYS = 62;

/* ---------- small date helpers (all on "YYYY-MM-DD" / "YYYY-MM-DDTHH:MM:SS" strings, no time-zone shifts) ---------- */
const pad = (n) => String(n).padStart(2, "0");
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const addDays = (s, n) => { const d = new Date(`${s}T00:00:00`); d.setDate(d.getDate() + n); return ymd(d); };
const daysBetween = (a, b) => Math.round((new Date(`${b}T00:00:00`) - new Date(`${a}T00:00:00`)) / 86400000);
const hourOf = (iso) => Number(iso.slice(11, 13)) + Number(iso.slice(14, 16)) / 60;
const hm = (iso) => (iso ? iso.slice(11, 16) : "");
const dayLabel = (s) => new Date(`${s}T00:00:00`).toLocaleDateString("en-GB", { weekday: "short", day: "2-digit", month: "short" });
const fmt = (iso) => (iso ? `${new Date(iso.slice(0, 10) + "T00:00:00").toLocaleDateString("en-GB", { day: "2-digit", month: "short" })} ${hm(iso)}` : "-");
const hourText = (h) => { const x = ((h % 24) + 24) % 24; return `${pad(Math.floor(x))}:${pad(Math.round((x % 1) * 60) % 60)}`; };   // 32 h -> 08:00 (next day)

/* bars that overlap in one row (parallel machines, shared batch) go on separate lanes */
function assignLanes(segs) {
    const ends = [];
    const out = [...segs].sort((a, b) => (a.start < b.start ? -1 : a.start > b.start ? 1 : 0)).map((s) => {
        let lane = ends.findIndex((e) => e <= s.start);
        if (lane < 0) { lane = ends.length; ends.push(s.end); } else ends[lane] = s.end;
        return { ...s, lane };
    });
    return { segs: out, lanes: Math.max(1, ends.length) };
}

function ScheduleGanttView({ open, onClose, apiBase, authHeaders ,initialPlanId}) {
    const today = ymd(new Date());
    const [from, setFrom] = useState(today);
    const [to, setTo] = useState(addDays(today, 6));
    // the chart shows EVERY plan together (each PO once); the plan picked in the Scheduled POs tab is highlighted
    const [planId, setPlanId] = useState("base");         // highlighted plan: a version id, "base" = current plan(s), "none"
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [search, setSearch] = useState("");
    const [hoverPo, setHoverPo] = useState(null);
    const [pinPo, setPinPo] = useState(null);

    const headers = () => (authHeaders ? authHeaders() : { "x-access-token": localStorage.getItem("token") || "" });
    const nDays = from && to ? daysBetween(from, to) + 1 : 0;
    const rangeError = !from || !to ? "Pick both dates"
        : nDays < 1 ? "'To' must be on or after 'From'"
            : nDays > MAX_DAYS ? `Pick at most ${MAX_DAYS} days` : null;

    useEffect(() => {
        if (open) {
            setPlanId(initialPlanId || "base");
        }
    }, [open, initialPlanId]);

    /* the schedule for the range */
    useEffect(() => {
        if (!open || rangeError) return;
        let alive = true;
        setLoading(true);
        setError(null);
        const params = { date_from: from, date_to: to, all_plans: true };   // every plan together
        axios.get(`${apiBase}/schedule/plans/view`, { headers: headers(), params })
            .then((r) => { if (alive) setData(r.data); })
            .catch((e) => { if (alive) { setData(null); setError(e.response?.data?.detail || "Could not load the schedule."); } })
            .finally(() => { if (alive) setLoading(false); });
        return () => { alive = false; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [open, apiBase, from, to, rangeError]);

    /* which plan(s) are in colour: the picked version, or the current plan of each plant */
    const allPlans = data?.plans || [];
    const shownPlans = allPlans.filter((p) => p.pos_in_range > 0);
    const hiSet = useMemo(() => {
        if (planId === "none") return null;
        if (planId === "base") return new Set(allPlans.filter((p) => p.is_baseline).map((p) => p.id));
        return new Set([Number(planId)]);
    }, [planId, allPlans]);
    const isHi = (planOfSeg) => !hiSet || hiSet.has(planOfSeg);
    const planTag = (id) => { const p = allPlans.find((x) => x.id === id); return p ? (p.reference || p.version_name || p.name) : ""; };
    const OTHER_PLAN = "#cbd5e1";

    const days = useMemo(() => (rangeError ? [] : Array.from({ length: nDays }, (_, i) => addDays(from, i))), [from, nDays, rangeError]);
    const dayIndex = useMemo(() => Object.fromEntries(days.map((d, i) => [d, i])), [days]);
    const dayW = Math.max(110, Math.min(260, Math.floor(1350 / Math.max(1, days.length))));
    const winStart = data?.day_window?.start_hour ?? 8;
    const winEnd = data?.day_window?.end_hour ?? 24;
    const winLen = Math.max(1, winEnd - winStart);

    const colorOf = useMemo(() => {
        const m = {}, plOf = {};
        (data?.pos || []).filter((p) => isHi(p.plan_id)).forEach((p, i) => { m[p.production_order] = PALETTE[i % PALETTE.length]; });
        (data?.pos || []).forEach((p) => { plOf[p.production_order] = p.plan_id; });
        return (po) => (isHi(plOf[po]) ? m[po] || "#64748b" : OTHER_PLAN);         // other plans: grey
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [data, hiSet]);

    const q = search.trim().toLowerCase();
    const matches = (s) => !q || s.po.toLowerCase().includes(q) || (s.part || "").toLowerCase().includes(q);
    const focusPo = hoverPo || pinPo;

    const rows = useMemo(() => (data?.rows || []).map((r) => ({ ...r, ...assignLanes(r.segments) })), [data]);

    const xOf = (iso) => {
        const i = dayIndex[iso.slice(0, 10)];
        if (i === undefined) return null;
        const f = Math.min(1, Math.max(0, (hourOf(iso) - winStart) / winLen));
        return i * dayW + f * dayW;
    };

    const setPreset = (n) => { setFrom(today); setTo(addDays(today, n - 1)); };
    const setMonth = () => {
        const d = new Date();
        setFrom(ymd(new Date(d.getFullYear(), d.getMonth(), 1)));
        setTo(ymd(new Date(d.getFullYear(), d.getMonth() + 1, 0)));
    };

    const gridW = days.length * dayW;
    let lastSection = null;

    return (
        <Dialog open={open} onClose={onClose} fullWidth maxWidth="xl" PaperProps={{ sx: { borderRadius: 3, height: "90vh" } }}>
            <DialogTitle sx={{ display: "flex", alignItems: "center", gap: 1.5, py: 1.5 }}>
                <Typography variant="h6" sx={{ fontWeight: 700 }}>Production Schedule - all plans</Typography>
                <Chip icon={<VisibilityIcon />} label="View only" size="small" variant="outlined" />
                <Box sx={{ flex: 1 }} />
                <IconButton onClick={onClose} size="small"><CloseIcon /></IconButton>
            </DialogTitle>
            <Divider />

            <DialogContent sx={{ display: "flex", flexDirection: "column", gap: 1.5, pt: 2 }}>
                {/* ---------- filters ---------- */}
                <Stack direction="row" spacing={1.5} alignItems="center" flexWrap="wrap" useFlexGap>
                    <TextField label="From" type="date" size="small" value={from} onChange={(e) => setFrom(e.target.value)}
                        InputLabelProps={{ shrink: true }} sx={{ width: 160 }} />
                    <TextField label="To" type="date" size="small" value={to} onChange={(e) => setTo(e.target.value)}
                        InputLabelProps={{ shrink: true }} sx={{ width: 160 }} inputProps={{ min: from }} />
                    <Stack direction="row" spacing={0.5}>
                        <Chip label="7 days" size="small" onClick={() => setPreset(7)} />
                        <Chip label="14 days" size="small" onClick={() => setPreset(14)} />
                        <Chip label="This month" size="small" onClick={setMonth} />
                    </Stack>
                    <FormControl size="small" sx={{ minWidth: 300 }}>
                        <InputLabel>Highlight plan</InputLabel>
                        <Select value={planId} label="Highlight plan" onChange={(e) => setPlanId(e.target.value)}>
                            <MenuItem value="base">Current plan</MenuItem>
                            <MenuItem value="none">No highlight (all in colour)</MenuItem>
                            {allPlans.filter((p) => p.pos_in_range > 0 || String(p.id) === String(planId)).map((p) => (
                                <MenuItem key={p.id} value={p.id}>
                                    {p.version_name || p.name}{p.reference ? ` · ${p.reference}` : ""}{p.is_baseline ? " · current" : ""}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                    <TextField placeholder="Find PO / part" size="small" value={search} onChange={(e) => setSearch(e.target.value)}
                        sx={{ width: 200 }}
                        InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }} />
                </Stack>

                {/* plans on the chart - click one to highlight it */}
                {shownPlans.length > 0 && (
                    <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap alignItems="center">
                        <Typography variant="caption" sx={{ fontWeight: 700, color: "#475569", mr: 0.5 }}>Plans in range:</Typography>
                        {shownPlans.map((p) => {
                            const on = isHi(p.id) && hiSet;
                            return (
                                <Tooltip key={p.id} arrow title={`${p.version_name || p.name}${p.created_at ? ` · saved ${fmt(p.created_at)}` : ""}`}>
                                    <Chip size="small" onClick={() => setPlanId(p.id)}
                                        label={`${p.reference || p.version_name || p.name} · ${p.pos_in_range} PO${p.pos_in_range > 1 ? "s" : ""}`}
                                        sx={{ fontWeight: 700, bgcolor: on ? "#1f6fe5" : "#e2e8f0", color: on ? "#fff" : "#334155", "&:hover": { bgcolor: on ? "#1a5fc7" : "#cbd5e1" } }} />
                                </Tooltip>
                            );
                        })}
                    </Stack>
                )}

                {rangeError && <Alert severity="warning">{rangeError}</Alert>}
                {error && <Alert severity="error">{error}</Alert>}

                {/* ---------- chart ---------- */}
                <Box sx={{ flex: 1, minHeight: 0, border: "1px solid #e2e8f0", borderRadius: 2, overflow: "auto", position: "relative", bgcolor: "#fff" }}>
                    {loading && (
                        <Box sx={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", bgcolor: "rgba(255,255,255,.6)", zIndex: 5 }}>
                            <CircularProgress size={36} />
                        </Box>
                    )}
                    {!loading && !error && !rangeError && data && rows.length === 0 && (
                        <Box sx={{ p: 6, textAlign: "center", color: "text.secondary" }}>
                            {allPlans.length === 0
                                ? "No saved schedule yet. Save a plan on the Production Schedule page first."
                                : "Nothing is scheduled between these dates."}
                        </Box>
                    )}
                    {rows.length > 0 && !rangeError && (
                        <Box sx={{ width: LABEL_W + gridW, position: "relative" }}>
                            {/* header: days + hour ticks */}
                            <Box sx={{ display: "flex", position: "sticky", top: 0, zIndex: 3, bgcolor: "#f8fafc", borderBottom: "1px solid #e2e8f0" }}>
                                <Box sx={{ width: LABEL_W, flexShrink: 0, position: "sticky", left: 0, zIndex: 4, bgcolor: "#f8fafc", borderRight: "1px solid #e2e8f0", px: 1.5, display: "flex", alignItems: "center" }}>
                                    <Typography variant="caption" sx={{ fontWeight: 700, color: "#475569" }}>PROCESS</Typography>
                                </Box>
                                {days.map((d) => (
                                    <Box key={d} sx={{ width: dayW, flexShrink: 0, borderRight: "1px solid #e2e8f0", bgcolor: d === today ? "#eff6ff" : undefined }}>
                                        <Typography variant="caption" sx={{ display: "block", textAlign: "center", fontWeight: 700, color: d === today ? "#1d4ed8" : "#334155", pt: 0.5 }}>
                                            {dayLabel(d)}
                                        </Typography>
                                        <Box sx={{ display: "flex", justifyContent: "space-between", px: 0.5, pb: 0.3 }}>
                                            {[winStart, winStart + winLen / 2, winEnd].map((h) => (
                                                <Typography key={h} sx={{ fontSize: 10, color: "#94a3b8" }}>{hourText(h)}</Typography>
                                            ))}
                                        </Box>
                                    </Box>
                                ))}
                            </Box>

                            {/* rows */}
                            {rows.map((r) => {
                                const h = r.lanes * LANE_H + ROW_PAD * 2;
                                const header = r.section && r.section !== lastSection;
                                lastSection = r.section;
                                return (
                                    <React.Fragment key={r.row_id}>
                                        {header && (
                                            <Box sx={{ display: "flex", bgcolor: "#f1f5f9", borderBottom: "1px solid #e2e8f0" }}>
                                                <Box sx={{ width: LABEL_W, position: "sticky", left: 0, bgcolor: "#f1f5f9", px: 1.5, py: 0.3 }}>
                                                    <Typography variant="caption" sx={{ fontWeight: 800, letterSpacing: 0.5, color: "#475569" }}>{r.section}</Typography>
                                                </Box>
                                            </Box>
                                        )}
                                        <Box sx={{ display: "flex", borderBottom: "1px solid #f1f5f9", height: h }}>
                                            <Box sx={{ width: LABEL_W, flexShrink: 0, position: "sticky", left: 0, zIndex: 2, bgcolor: "#fff", borderRight: "1px solid #e2e8f0", px: 1.5, display: "flex", alignItems: "center" }}>
                                                <Typography variant="body2" noWrap title={r.title} sx={{ fontWeight: 600, fontSize: 12.5, color: "#1e293b" }}>
                                                    {r.title}
                                                    {r.kind === "LINE" && <Chip label="LINE" size="small" sx={{ ml: 0.75, height: 16, fontSize: 9 }} />}
                                                </Typography>
                                            </Box>
                                            <Box sx={{ position: "relative", width: gridW, flexShrink: 0 }}>
                                                {/* day separators + today tint */}
                                                {days.map((d, i) => (
                                                    <Box key={d} sx={{ position: "absolute", top: 0, bottom: 0, left: i * dayW, width: dayW, borderRight: "1px solid #f1f5f9", bgcolor: d === today ? "rgba(59,130,246,.05)" : undefined }} />
                                                ))}
                                                {r.segs.map((s, k) => {
                                                    const x1 = xOf(s.start), x2 = xOf(s.end);
                                                    if (x1 === null || x2 === null) return null;
                                                    const w = Math.max(3, x2 - x1);
                                                    const dim = (focusPo && s.po !== focusPo) || !matches(s);
                                                    const tip = (
                                                        <Box sx={{ fontSize: 12, lineHeight: 1.5 }}>
                                                            <b>PO {s.po}</b> · {s.part} ({s.role}){s.locked ? " · 🔒 assigned" : ""}<br />
                                                            Plan: {planTag(s.plan_id)}<br />
                                                            {r.name}{s.step ? ` → ${s.step}` : ""}<br />
                                                            {fmt(s.start)} – {hm(s.end)} ({Math.round(s.minutes)} min)<br />
                                                            {s.machine ? <>Machine: {s.machine}<br /></> : null}
                                                            {s.batch ? <>Batch {s.batch.no}/{s.batch.count}: {s.batch.qty} of {s.batch.size} PCBs</> : null}
                                                        </Box>
                                                    );
                                                    return (
                                                        <Tooltip key={k} title={tip} arrow placement="top" disableInteractive>
                                                            <Box
                                                                onMouseEnter={() => setHoverPo(s.po)}
                                                                onMouseLeave={() => setHoverPo(null)}
                                                                onClick={() => setPinPo((p) => (p === s.po ? null : s.po))}
                                                                sx={{
                                                                    position: "absolute", left: x1, width: w, top: ROW_PAD + s.lane * LANE_H + 1, height: LANE_H - 3,
                                                                    bgcolor: colorOf(s.po), borderRadius: "4px", opacity: dim ? 0.18 : 1, cursor: "pointer",
                                                                    color: isHi(s.plan_id) ? "#fff" : "#475569", fontSize: 10.5, fontWeight: 600, lineHeight: `${LANE_H - 3}px`, px: 0.5,
                                                                    overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis",
                                                                    boxShadow: focusPo === s.po ? "0 0 0 2px #0f172a" : "none",
                                                                    transition: "opacity .12s",
                                                                }}
                                                            >
                                                                {w > 46 ? `${s.locked ? "🔒 " : ""}${s.step && r.kind === "LINE" ? `${s.po} · ${s.step}` : s.po}` : ""}
                                                            </Box>
                                                        </Tooltip>
                                                    );
                                                })}
                                            </Box>
                                        </Box>
                                    </React.Fragment>
                                );
                            })}
                        </Box>
                    )}
                </Box>

                {/* ---------- PO legend ---------- */}
                {(data?.pos || []).length > 0 && (
                    <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap alignItems="center">
                        <Typography variant="caption" sx={{ fontWeight: 700, color: "#475569", mr: 0.5 }}>POs in range:</Typography>
                        {data.pos.map((p) => (
                            <Tooltip key={p.production_order} arrow
                                title={`${p.part_number} · ${p.role} · qty ${p.quantity} · ${p.plan_reference || ""} · planned ${fmt(p.start)} → ${fmt(p.end)}${p.forced ? " · scheduled without child PCBs" : ""}${p.locked ? " · assigned" : ""}`}>
                                <Chip
                                    size="small"
                                    onMouseEnter={() => setHoverPo(p.production_order)}
                                    onMouseLeave={() => setHoverPo(null)}
                                    onClick={() => setPinPo((x) => (x === p.production_order ? null : p.production_order))}
                                    icon={p.forced ? <WarningAmberIcon sx={{ color: "#b45309 !important" }} /> : undefined}
                                    label={`${p.locked ? "🔒 " : ""}${p.production_order} · ${p.part_number}`}
                                    variant={pinPo === p.production_order ? "filled" : "outlined"}
                                    sx={{ borderColor: colorOf(p.production_order), borderLeft: `6px solid ${colorOf(p.production_order)}`, fontWeight: 600 }}
                                />
                            </Tooltip>
                        ))}
                        {pinPo && <Button size="small" onClick={() => setPinPo(null)}>Clear highlight</Button>}
                    </Stack>
                )}
            </DialogContent>
        </Dialog>
    );
}








/* =====================================================================================
   SCHEDULED POs TAB  (self-contained - owns all of its own state, touches nothing else)
   ===================================================================================== */

/* PO numbers can come with / without leading zeros - compare them normalised */
// const normPo = (v) => String(v ?? "").trim().replace(/^0+/, "");
const normPo = (v) => String(v ?? "").trim().replace(/^0+/, "");
// const PO_KEYS = ["productionOrderNumber", "productionOrder", "ProductionOrder", "production_order", "orderNumber", "order_number", "poNumber", "po_number"];
const PO_KEYS = [
    "productionOrderNumber", "productionOrder", "ProductionOrder", "production_order", 
    "orderNumber", "order_number", "poNumber", "po_number", "bel_po_no", "BEL_PO_No", "po", "PO"
];

// const pcbPoOf = (pcb) => {
//     for (const k of PO_KEYS) {
//         if (pcb[k] !== undefined && pcb[k] !== null && String(pcb[k]).trim() !== "") return normPo(pcb[k]);
//     }
//     const k2 = Object.keys(pcb).find((k) => /(prod.*order|^po[_ ]?(no|num))/i.test(k) && String(pcb[k] ?? "").trim() !== "");
//     return k2 ? normPo(pcb[k2]) : "";
// };

const pcbPoOf = (pcb) => {
    for (const k of PO_KEYS) {
        if (pcb[k] !== undefined && pcb[k] !== null && String(pcb[k]).trim() !== "") return normPo(pcb[k]);
    }
    const k2 = Object.keys(pcb).find((k) => /(prod.*order|^po[_ ]?(no|num))/i.test(k) && String(pcb[k] ?? "").trim() !== "");
    return k2 ? normPo(pcb[k2]) : "";
};


/* Gantt for ONE or SEVERAL chosen POs (read-only). The full-schedule Gantt is the original ScheduleGanttView. */
function PoGanttDialog({ open, onClose, apiBase, plans, initialPlanId, poList, initialFrom, initialTo }) {
    const [from, setFrom] = useState(initialFrom || ymd(new Date()));
    const [to, setTo] = useState(initialTo || ymd(new Date()));
    const [planId, setPlanId] = useState(initialPlanId || "base");
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [showAll, setShowAll] = useState(false);
    const [hoverPo, setHoverPo] = useState(null);
    const [pinPo, setPinPo] = useState(null);

    const headers = () => ({ "x-access-token": localStorage.getItem("token") || "" });
    const listKey = (poList || []).join("|");

    useEffect(() => {
        if (!open) return;
        setShowAll(false);
        setPinPo(poList && poList.length === 1 ? poList[0] : null);
        setPlanId(initialPlanId || "base");
        if (initialFrom && initialTo) { setFrom(initialFrom); setTo(initialTo); }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [open, listKey, initialFrom, initialTo, initialPlanId]);

    const nDays = from && to ? daysBetween(from, to) + 1 : 0;
    const rangeError = !from || !to ? "Pick both dates"
        : nDays < 1 ? "'To' must be on or after 'From'"
            : nDays > MAX_DAYS ? `Pick at most ${MAX_DAYS} days` : null;

    useEffect(() => {
        if (!open || rangeError) return;
        let alive = true;
        setLoading(true);
        setError(null);
        const params = { date_from: from, date_to: to };
        if (planId !== "base") params.plan_id = planId;
        axios.get(`${apiBase}/schedule/plans/view`, { headers: headers(), params })
            .then((r) => { if (alive) setData(r.data); })
            .catch((e) => { if (alive) { setData(null); setError(e.response?.data?.detail || "Could not load the schedule."); } })
            .finally(() => { if (alive) setLoading(false); });
        return () => { alive = false; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [open, apiBase, from, to, planId, rangeError]);

    const today = ymd(new Date());
    const days = useMemo(() => (rangeError ? [] : Array.from({ length: nDays }, (_, i) => addDays(from, i))), [from, nDays, rangeError]);
    const dayIndex = useMemo(() => Object.fromEntries(days.map((d, i) => [d, i])), [days]);
    const dayW = Math.max(110, Math.min(260, Math.floor(1350 / Math.max(1, days.length))));
    const winStart = data?.day_window?.start_hour ?? 8;
    const winEnd = data?.day_window?.end_hour ?? 24;
    const winLen = Math.max(1, winEnd - winStart);

    const colorOf = useMemo(() => {
        const m = {};
        (data?.pos || []).forEach((p, i) => { m[p.production_order] = PALETTE[i % PALETTE.length]; });
        return (po) => m[po] || "#64748b";
    }, [data]);

    const scoped = poList && poList.length > 0 && !showAll;
    const view = useMemo(() => {
        if (!data || !scoped) return data;
        const keep = new Set(poList);
        return {
            ...data,
            rows: (data.rows || [])
                .map((r) => ({ ...r, segments: (r.segments || []).filter((sg) => keep.has(sg.po)) }))
                .filter((r) => r.segments.length > 0),
            pos: (data.pos || []).filter((p) => keep.has(p.production_order)),
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [data, scoped, listKey]);

    const rows = useMemo(() => (view?.rows || []).map((r) => ({ ...r, ...assignLanes(r.segments) })), [view]);
    const focusPo = hoverPo || pinPo;
    const gridW = days.length * dayW;
    const label = poList && poList.length === 1 ? `PO ${poList[0]}` : `${(poList || []).length} selected POs`;
    let lastSection = null;

    const xOf = (iso) => {
        const i = dayIndex[iso.slice(0, 10)];
        if (i === undefined) return null;
        const f = Math.min(1, Math.max(0, (hourOf(iso) - winStart) / winLen));
        return i * dayW + f * dayW;
    };

    return (
        <Dialog open={open} onClose={onClose} fullWidth maxWidth="xl" PaperProps={{ sx: { borderRadius: 3, height: "90vh" } }}>
            <DialogTitle sx={{ display: "flex", alignItems: "center", gap: 1.5, py: 1.5 }}>
                <Typography variant="h6" sx={{ fontWeight: 700 }}>
                    {scoped ? `Production Schedule - ${label}` : "Production Schedule"}
                </Typography>
                <Chip icon={<VisibilityIcon />} label="View only" size="small" variant="outlined" />
                {poList && poList.length > 0 && (
                    <Button size="small" onClick={() => setShowAll((v) => !v)} sx={{ textTransform: "none", fontWeight: 600 }}>
                        {showAll ? `Only ${label}` : "Show all POs"}
                    </Button>
                )}
                <Box sx={{ flex: 1 }} />
                <IconButton onClick={onClose} size="small"><CloseIcon /></IconButton>
            </DialogTitle>
            <Divider />
            <DialogContent sx={{ display: "flex", flexDirection: "column", gap: 1.5, pt: 2 }}>
                <Stack direction="row" spacing={1.5} alignItems="center" flexWrap="wrap" useFlexGap>
                    <TextField label="From" type="date" size="small" value={from} onChange={(e) => setFrom(e.target.value)}
                        InputLabelProps={{ shrink: true }} sx={{ width: 160 }} />
                    <TextField label="To" type="date" size="small" value={to} onChange={(e) => setTo(e.target.value)}
                        InputLabelProps={{ shrink: true }} sx={{ width: 160 }} inputProps={{ min: from }} />
                    <FormControl size="small" sx={{ minWidth: 260 }}>
                        <InputLabel>Plan</InputLabel>
                        <Select value={planId} label="Plan" onChange={(e) => setPlanId(e.target.value)}>
                            <MenuItem value="base">Current plan (baseline)</MenuItem>
                            {(plans || []).map((p) => (
                                <MenuItem key={p.id} value={p.id}>
                                    {p.name}{p.plant ? ` · ${p.plant}` : ""}{p.is_baseline ? " · baseline" : ""}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Stack>

                {rangeError && <Alert severity="warning">{rangeError}</Alert>}
                {error && <Alert severity="error">{error}</Alert>}

                <Box sx={{ flex: 1, minHeight: 0, border: "1px solid #e2e8f0", borderRadius: 2, overflow: "auto", position: "relative", bgcolor: "#fff" }}>
                    {loading && (
                        <Box sx={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", bgcolor: "rgba(255,255,255,.6)", zIndex: 5 }}>
                            <CircularProgress size={36} />
                        </Box>
                    )}
                    {!loading && !error && !rangeError && data && rows.length === 0 && (
                        <Box sx={{ p: 6, textAlign: "center", color: "text.secondary" }}>
                            {data.plans.length === 0
                                ? "No saved schedule yet. Save a plan on the Production Schedule page first."
                                : scoped
                                    ? `${label} not scheduled between these dates on this plan.`
                                    : "Nothing is scheduled between these dates."}
                        </Box>
                    )}
                    {rows.length > 0 && !rangeError && (
                        <Box sx={{ width: LABEL_W + gridW, position: "relative" }}>
                            <Box sx={{ display: "flex", position: "sticky", top: 0, zIndex: 3, bgcolor: "#f8fafc", borderBottom: "1px solid #e2e8f0" }}>
                                <Box sx={{ width: LABEL_W, flexShrink: 0, position: "sticky", left: 0, zIndex: 4, bgcolor: "#f8fafc", borderRight: "1px solid #e2e8f0", px: 1.5, display: "flex", alignItems: "center" }}>
                                    <Typography variant="caption" sx={{ fontWeight: 700, color: "#475569" }}>PROCESS</Typography>
                                </Box>
                                {days.map((d) => (
                                    <Box key={d} sx={{ width: dayW, flexShrink: 0, borderRight: "1px solid #e2e8f0", bgcolor: d === today ? "#eff6ff" : undefined }}>
                                        <Typography variant="caption" sx={{ display: "block", textAlign: "center", fontWeight: 700, color: d === today ? "#1d4ed8" : "#334155", pt: 0.5 }}>
                                            {dayLabel(d)}
                                        </Typography>
                                        <Box sx={{ display: "flex", justifyContent: "space-between", px: 0.5, pb: 0.3 }}>
                                            {[winStart, winStart + winLen / 2, winEnd].map((h) => (
                                                <Typography key={h} sx={{ fontSize: 10, color: "#94a3b8" }}>{hourText(h)}</Typography>
                                            ))}
                                        </Box>
                                    </Box>
                                ))}
                            </Box>
                            {rows.map((r) => {
                                const h = r.lanes * LANE_H + ROW_PAD * 2;
                                const header = r.section && r.section !== lastSection;
                                lastSection = r.section;
                                return (
                                    <React.Fragment key={r.row_id}>
                                        {header && (
                                            <Box sx={{ display: "flex", bgcolor: "#f1f5f9", borderBottom: "1px solid #e2e8f0" }}>
                                                <Box sx={{ width: LABEL_W, position: "sticky", left: 0, bgcolor: "#f1f5f9", px: 1.5, py: 0.3 }}>
                                                    <Typography variant="caption" sx={{ fontWeight: 800, letterSpacing: 0.5, color: "#475569" }}>{r.section}</Typography>
                                                </Box>
                                            </Box>
                                        )}
                                        <Box sx={{ display: "flex", borderBottom: "1px solid #f1f5f9", height: h }}>
                                            <Box sx={{ width: LABEL_W, flexShrink: 0, position: "sticky", left: 0, zIndex: 2, bgcolor: "#fff", borderRight: "1px solid #e2e8f0", px: 1.5, display: "flex", alignItems: "center" }}>
                                                <Typography variant="body2" noWrap title={r.title} sx={{ fontWeight: 600, fontSize: 12.5, color: "#1e293b" }}>
                                                    {r.title}
                                                    {r.kind === "LINE" && <Chip label="LINE" size="small" sx={{ ml: 0.75, height: 16, fontSize: 9 }} />}
                                                </Typography>
                                            </Box>
                                            <Box sx={{ position: "relative", width: gridW, flexShrink: 0 }}>
                                                {days.map((d, i) => (
                                                    <Box key={d} sx={{ position: "absolute", top: 0, bottom: 0, left: i * dayW, width: dayW, borderRight: "1px solid #f1f5f9", bgcolor: d === today ? "rgba(59,130,246,.05)" : undefined }} />
                                                ))}
                                                {r.segs.map((s, k) => {
                                                    const x1 = xOf(s.start), x2 = xOf(s.end);
                                                    if (x1 === null || x2 === null) return null;
                                                    const w = Math.max(3, x2 - x1);
                                                    const dim = focusPo && s.po !== focusPo;
                                                    const tip = (
                                                        <Box sx={{ fontSize: 12, lineHeight: 1.5 }}>
                                                            <b>PO {s.po}</b> · {s.part} ({s.role})<br />
                                                            {r.name}{s.step ? ` → ${s.step}` : ""}<br />
                                                            {fmt(s.start)} – {hm(s.end)} ({Math.round(s.minutes)} min)<br />
                                                            {s.machine ? <>Machine: {s.machine}<br /></> : null}
                                                            {s.batch ? <>Batch {s.batch.no}/{s.batch.count}: {s.batch.qty} of {s.batch.size} PCBs</> : null}
                                                        </Box>
                                                    );
                                                    return (
                                                        <Tooltip key={k} title={tip} arrow placement="top" disableInteractive>
                                                            <Box
                                                                onMouseEnter={() => setHoverPo(s.po)}
                                                                onMouseLeave={() => setHoverPo(null)}
                                                                onClick={() => setPinPo((p) => (p === s.po ? null : s.po))}
                                                                sx={{
                                                                    position: "absolute", left: x1, width: w, top: ROW_PAD + s.lane * LANE_H + 1, height: LANE_H - 3,
                                                                    bgcolor: colorOf(s.po), borderRadius: "4px", opacity: dim ? 0.18 : 1, cursor: "pointer",
                                                                    color: "#fff", fontSize: 10.5, fontWeight: 600, lineHeight: `${LANE_H - 3}px`, px: 0.5,
                                                                    overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis",
                                                                    boxShadow: focusPo === s.po ? "0 0 0 2px #0f172a" : "none",
                                                                    transition: "opacity .12s",
                                                                }}
                                                            >
                                                                {w > 46 ? (s.step && r.kind === "LINE" ? `${s.po} · ${s.step}` : s.po) : ""}
                                                            </Box>
                                                        </Tooltip>
                                                    );
                                                })}
                                            </Box>
                                        </Box>
                                    </React.Fragment>
                                );
                            })}
                        </Box>
                    )}
                </Box>

                {(view?.pos || []).length > 0 && (
                    <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap alignItems="center">
                        <Typography variant="caption" sx={{ fontWeight: 700, color: "#475569", mr: 0.5 }}>POs shown:</Typography>
                        {view.pos.map((p) => (
                            <Chip
                                key={p.production_order}
                                size="small"
                                onMouseEnter={() => setHoverPo(p.production_order)}
                                onMouseLeave={() => setHoverPo(null)}
                                onClick={() => setPinPo((x) => (x === p.production_order ? null : p.production_order))}
                                label={`${p.production_order} · ${p.part_number}`}
                                variant={pinPo === p.production_order ? "filled" : "outlined"}
                                sx={{ borderColor: colorOf(p.production_order), borderLeft: `6px solid ${colorOf(p.production_order)}`, fontWeight: 600 }}
                            />
                        ))}
                        {pinPo && <Button size="small" onClick={() => setPinPo(null)}>Clear highlight</Button>}
                    </Stack>
                )}
            </DialogContent>
        </Dialog>
    );
}

function ScheduledPOsTab({ active, busy, dbPCBs, getPcbId, apiBase, assignedPCBs, assignUrl, onAssigned, notify, onViewFull }) {
    // A saved plan is assigned AS A WHOLE: no selection. "Assign plan" works only when every PCB of every PO of the plan
    // (that is not assigned yet) is ready; it then assigns all of them in one request and keeps the plan's slots.
    const [planId, setPlanId] = useState("base");            // "base" = the current plan
    const [plans, setPlans] = useState([]);
    const [pos, setPos] = useState([]);                      // EVERY PO of the plan (no date range)
    const [planInfo, setPlanInfo] = useState([]);            // the plan(s) the list comes from
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [search, setSearch] = useState("");
    const [expanded, setExpanded] = useState(null);
    const [assigning, setAssigning] = useState(false);
    const [confirmOpen, setConfirmOpen] = useState(false);
    const [gantt, setGantt] = useState(null);                // { pos:[...], from, to }
    const [reloadKey, setReloadKey] = useState(0);

    const headers = () => ({ "x-access-token": localStorage.getItem("token") || "" });

    /* saved plans for the picker */
    useEffect(() => {
        if (!active) return;
        let alive = true;
        axios.get(`${apiBase}/schedule/plans`, { headers: headers() })
            .then((r) => { if (alive) setPlans(r.data?.plans || []); })
            .catch(() => { if (alive) setPlans([]); });
        return () => { alive = false; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [active, apiBase, reloadKey]);

    /* every PO of the chosen plan, in plan order */
    useEffect(() => {
        if (!active) return;
        let alive = true;
        setLoading(true);
        setError(null);
        const params = planId !== "base" ? { plan_id: planId } : {};
        axios.get(`${apiBase}/schedule/plans/pos`, { headers: headers(), params })
            .then((r) => {
                if (!alive) return;
                setPos(r.data?.pos || []);
                setPlanInfo(r.data?.plans || []);
            })
            .catch((e) => {
                if (!alive) return;
                setPos([]);
                setPlanInfo([]);
                setError(e.response?.data?.detail || "Could not load the production orders of the plan.");
            })
            .finally(() => { if (alive) setLoading(false); });
        return () => { alive = false; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [active, apiBase, planId, reloadKey]);

    const pcbSerialOf = (pcb) => String(pcb.PCBserialNoPartNumber || pcb.serialNo || pcb.serialNumber || pcb.serial_no || "").trim();

    /* PCBs not assigned yet (the "Assign to Operator" list), by PO */
    const pcbsByPo = useMemo(() => {
        const assignedSerials = new Set((assignedPCBs || []).map((a) => String(a.serialNo || a.serialNumber || a.PCBserialNoPartNumber || "").trim()).filter(Boolean));
        const m = {};
        (dbPCBs || []).forEach((pcb, i) => {
            const serial = pcbSerialOf(pcb);
            if (serial && assignedSerials.has(serial)) return;
            const k = pcbPoOf(pcb);
            if (!k) return;
            (m[k] = m[k] || []).push({ pcb, id: getPcbId(pcb, i) });
        });
        return m;
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [dbPCBs, assignedPCBs]);

    /* PCBs already assigned, by PO */
    const assignedByPo = useMemo(() => {
        const m = {};
        (assignedPCBs || []).forEach((pcb) => {
            const po = pcbPoOf(pcb);
            if (po) m[po] = (m[po] || 0) + 1;
        });
        return m;
    }, [assignedPCBs]);

    /* every PO of the plan with its PCB state */
    const planRows = useMemo(() => pos.map((p, i) => {
        const k = normPo(p.production_order);
        const qty = Number(p.quantity) || 0;
        const ready = pcbsByPo[k] || [];
        const assigned = Math.min(assignedByPo[k] || 0, qty || Infinity);
        const need = Math.max(qty - assigned, 0);
        const done = !!p.assigned || (qty > 0 && need === 0);       // already assigned (from this plan)
        return { ...p, no: i + 1, ready, assigned, need, done, ok: done || ready.length >= need };
    }), [pos, pcbsByPo, assignedByPo]);

    const todo = planRows.filter((r) => !r.done);
    const notReady = todo.filter((r) => !r.ok);
    const pcbsToAssign = todo.reduce((n, r) => n + Math.min(r.ready.length, r.need || r.ready.length), 0);
    const onePlan = planInfo.length === 1 ? planInfo[0] : null;
    const canAssign = !!onePlan && todo.length > 0 && notReady.length === 0 && !assigning;
    const whyNot = !onePlan ? (planInfo.length > 1 ? "Pick one plan - the current plan list has one plan per plant" : "No saved plan")
        : todo.length === 0 ? "Every PO of this plan is already assigned"
            : notReady.length ? `All PCBs of every PO must be ready. Not ready: ${notReady.map((r) => `${r.production_order} (${Math.min(r.ready.length, r.need)} / ${r.need})`).join(", ")}`
                : "";

    const rows = useMemo(() => {
        const q = search.trim().toLowerCase();
        return planRows.filter((p) => !q || String(p.production_order).toLowerCase().includes(q) || String(p.part_number || "").toLowerCase().includes(q));
    }, [planRows, search]);

    /* assign the WHOLE plan: every ready PCB of every PO not assigned yet, in one request, then keep the plan's slots */
    const assignPlan = async () => {
        const user = JSON.parse(localStorage.getItem("user"));
        if (!user) { notify("User details not found. Please log in.", "error"); return; }
        const serials = [];
        todo.forEach((r) => r.ready.slice(0, r.need || r.ready.length).forEach((x) => serials.push(x.pcb.PCBserialNoPartNumber)));
        if (!serials.length) { notify("No PCBs to assign.", "warning"); return; }
        setAssigning(true);
        try {
            await axios.post(assignUrl, { supervisor_staff_no: user?.id, pcb_serial_parts: serials });
            let lockNote = "";
            try {
                await axios.post(`${apiBase}/schedule/locks`, {
                    production_order: todo.map((r) => r.production_order), version_id: onePlan.id, locked_by: user?.id || null,
                }, { headers: headers() });
                lockNote = " Their schedule slots are kept.";
            } catch (e) {
                lockNote = " (Could not keep their schedule slots.)";
            }
            notify(`Plan ${onePlan.reference || onePlan.version_name || ""}: assigned ${serials.length} PCBs of ${todo.length} PO${todo.length > 1 ? "s" : ""}.${lockNote}`, "success");
            setConfirmOpen(false);
            onAssigned();
            setReloadKey((k) => k + 1);
        } catch (err) {
            notify(err.response?.data?.detail || "An error occurred during assignment.", "error");
        } finally {
            setAssigning(false);
        }
    };

    const openGantt = (list) => {
        if (!list.length) return;
        const starts = list.map((x) => (x.start || "").slice(0, 10)).filter(Boolean).sort();
        const ends = list.map((x) => (x.end || "").slice(0, 10)).filter(Boolean).sort();
        const f = starts[0] || ymd(new Date());
        let t = ends[ends.length - 1] || f;
        if (t < f) t = f;
        if (daysBetween(f, t) + 1 > MAX_DAYS) t = addDays(f, MAX_DAYS - 1);
        setGantt({ pos: list.map((x) => x.production_order), from: f, to: t });
    };

    const cellSx = { py: 0.75, px: 1, fontSize: "0.85rem" };
    const headSx = { ...cellSx, bgcolor: "#f8f9fa", fontWeight: 700, whiteSpace: "nowrap" };
    const readyTotal = todo.reduce((n, r) => n + Math.min(r.ready.length, r.need), 0);
    const needTotal = todo.reduce((n, r) => n + r.need, 0);

    const pcbChip = (r) => {
        const qty = Number(r.quantity) || 0;
        if (r.done) return <Chip label={`${qty} / ${qty} assigned`} size="small" sx={{ fontWeight: 700, height: 22, bgcolor: "#e0f2fe", color: "#0369a1" }} />;
        const n = Math.min(r.ready.length, r.need);
        const full = n >= r.need;
        return (
            <Stack direction="row" spacing={0.75} alignItems="center">
                <Chip label={`${n} / ${r.need} ready`} size="small"
                    sx={{ fontWeight: 700, height: 22, bgcolor: full ? "#f0fdf4" : n > 0 ? "#fff7ed" : "#f1f5f9", color: full ? "#166534" : n > 0 ? "#c2410c" : "#64748b" }} />
                {r.assigned > 0 && <Typography sx={{ fontSize: 12, color: "#0369a1", fontWeight: 600 }}>+ {r.assigned} assigned</Typography>}
            </Stack>
        );
    };

    return (
        <Box sx={{ display: active && !busy ? "block" : "none" }}>
            {/* ---------- plan + actions ---------- */}
            <Paper elevation={0} sx={{ p: 1.5, mb: 1.5, borderRadius: 2.5, border: "1px solid #e2e8f0", bgcolor: "white" }}>
                <Stack direction="row" spacing={1.5} alignItems="center" flexWrap="wrap" useFlexGap>
                    <FormControl size="small" sx={{ minWidth: 300, flex: "1 1 300px", maxWidth: 460 }}>
                        <InputLabel>Schedule plan</InputLabel>
                        <Select value={planId} label="Schedule plan" onChange={(e) => { setPlanId(e.target.value); setExpanded(null); }}>
                            <MenuItem value="base">Current plan</MenuItem>
                            {plans.map((pl) => (
                                <MenuItem key={pl.id} value={pl.id}>
                                    {pl.version_name || pl.name}{pl.reference ? ` · ${pl.reference}` : ""}{pl.plant ? ` · ${pl.plant}` : ""}{pl.is_baseline ? " · current" : ""}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                    <TextField
                        placeholder="Search PO / part no"
                        size="small"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        sx={{ flex: "1 1 180px", maxWidth: 260 }}
                        InputProps={{
                            startAdornment: (<InputAdornment position="start"><SearchIcon color="action" /></InputAdornment>),
                            endAdornment: search && (<ClearIcon fontSize="small" onClick={() => setSearch("")} style={{ cursor: "pointer" }} />)
                        }}
                    />
                </Stack>

                <Divider sx={{ my: 1.25 }} />

                <Stack direction="row" spacing={1.5} alignItems="center" justifyContent="space-between" flexWrap="wrap" useFlexGap>
                    <Typography variant="body2" sx={{ color: "text.secondary" }}>
                        <b>{planRows.length}</b> PO{planRows.length === 1 ? "" : "s"} in this plan
                        {todo.length > 0 ? <> · <b>{readyTotal}</b> of {needTotal} PCBs ready</> : null}
                        {planRows.length - todo.length > 0 ? ` · ${planRows.length - todo.length} already assigned` : ""}
                        {onePlan ? ` · ${onePlan.version_name || onePlan.name}${onePlan.reference ? ` (${onePlan.reference})` : ""}` : ""}
                    </Typography>

                    <Stack direction="row" spacing={1} alignItems="center" useFlexGap>
                        <Tooltip title="Reload the plan and the PCB lists">
                            <span>
                                <IconButton size="small" disabled={loading} onClick={() => { setReloadKey((k) => k + 1); onAssigned(); }}>
                                    <RefreshIcon fontSize="small" />
                                </IconButton>
                            </span>
                        </Tooltip>
                        <Button size="small" variant="outlined" startIcon={<TimelineIcon />} onClick={() => onViewFull(onePlan ? onePlan.id : planId)}
                            sx={{ borderRadius: 2, textTransform: "none", fontWeight: 600 }}>
                            Full Schedule
                        </Button>
                        <Tooltip title={whyNot}>
                            <span>
                                <Button size="small" variant="contained" disabled={!canAssign}
                                    startIcon={assigning ? <CircularProgress size={14} color="inherit" /> : <AssignmentTurnedInIcon />}
                                    onClick={() => setConfirmOpen(true)}
                                    sx={{ borderRadius: 2, textTransform: "none", fontWeight: 700 }}>
                                    {todo.length ? `Assign plan (${todo.length} PO${todo.length > 1 ? "s" : ""} · ${pcbsToAssign} PCBs)` : "Assign plan"}
                                </Button>
                            </span>
                        </Tooltip>
                    </Stack>
                </Stack>
                {onePlan && todo.length > 0 && notReady.length > 0 && (
                    <Alert severity="info" sx={{ mt: 1.25, py: 0 }}>
                        The plan can be assigned once every PCB of every PO is ready. Waiting for: {notReady.map((r) => `${r.production_order} (${Math.min(r.ready.length, r.need)} / ${r.need})`).join(", ")}.
                    </Alert>
                )}
            </Paper>

            {error && <Alert severity="error" sx={{ mb: 1.5 }}>{error}</Alert>}

            {/* ---------- every PO of the plan ---------- */}
            <Paper sx={{ width: "100%", overflow: "hidden", borderRadius: 2.5, border: "1px solid #e2e8f0", boxShadow: "none", position: "relative" }}>
                {loading && (
                    <Box sx={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", bgcolor: "rgba(255,255,255,.6)", zIndex: 5 }}>
                        <CircularProgress size={36} />
                    </Box>
                )}
                <TableContainer sx={{ maxHeight: "58vh", overflowX: "auto" }}>
                    <Table stickyHeader size="small" sx={{ minWidth: 760 }}>
                        <TableHead>
                            <TableRow>
                                <TableCell sx={{ ...headSx, width: 36, px: 0.5 }} />
                                <TableCell sx={{ ...headSx, width: 40 }}>#</TableCell>
                                <TableCell sx={headSx}>Production Order</TableCell>
                                <TableCell sx={headSx}>Part No</TableCell>
                                <TableCell sx={headSx} align="right">Qty</TableCell>
                                <TableCell sx={headSx}>Planned (start → end)</TableCell>
                                <TableCell sx={headSx}>PCBs</TableCell>
                                <TableCell sx={headSx} align="right">Actions</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {rows.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={8} align="center" sx={{ py: 6, color: "#64748b" }}>
                                        {loading ? "Loading..." : error ? "" : planInfo.length === 0
                                            ? "No saved schedule yet. Save a plan on the Production Schedule page first."
                                            : search ? "No PO of this plan matches the search." : "This plan has no production orders."}
                                    </TableCell>
                                </TableRow>
                            ) : rows.map((p) => {
                                const po = p.production_order;
                                const isOpen = expanded === po;
                                return (
                                    <React.Fragment key={po}>
                                        <TableRow hover sx={{ bgcolor: p.done ? "#f8fafc" : undefined }}>
                                            <TableCell sx={{ ...cellSx, px: 0.5 }}>
                                                <IconButton size="small" disabled={p.ready.length === 0}
                                                    onClick={() => setExpanded(isOpen ? null : po)}>
                                                    {isOpen ? <KeyboardArrowUpIcon fontSize="small" /> : <KeyboardArrowDownIcon fontSize="small" />}
                                                </IconButton>
                                            </TableCell>
                                            <TableCell sx={{ ...cellSx, color: "#64748b" }}>{p.no}</TableCell>
                                            <TableCell sx={{ ...cellSx, fontWeight: 700, whiteSpace: "nowrap" }}>
                                                {po}
                                                {p.forced && (
                                                    <Tooltip title="Scheduled without child PCBs">
                                                        <WarningAmberIcon sx={{ ml: 0.5, fontSize: 16, color: "#b45309", verticalAlign: "text-bottom" }} />
                                                    </Tooltip>
                                                )}
                                            </TableCell>
                                            <TableCell sx={{ ...cellSx, fontWeight: 600 }}>{p.part_number}</TableCell>
                                            <TableCell sx={cellSx} align="right">{p.quantity}</TableCell>
                                            <TableCell sx={{ ...cellSx, whiteSpace: "nowrap" }}>{fmt(p.start)} → {fmt(p.end)}</TableCell>
                                            <TableCell sx={cellSx}>{pcbChip(p)}</TableCell>
                                            <TableCell sx={{ ...cellSx, whiteSpace: "nowrap" }} align="right">
                                                <Button size="small" variant="outlined" startIcon={<TimelineIcon />} onClick={() => openGantt([p])}
                                                    sx={{ borderRadius: 2, textTransform: "none", fontWeight: 600 }}>
                                                    View
                                                </Button>
                                            </TableCell>
                                        </TableRow>
                                        <TableRow>
                                            <TableCell colSpan={8} sx={{ py: 0, px: 1, borderBottom: isOpen ? undefined : "none" }}>
                                                <Collapse in={isOpen} timeout="auto" unmountOnExit>
                                                    <Box sx={{ m: 1, p: 1.5, bgcolor: "#f8fafc", borderRadius: 2, border: "1px solid #e2e8f0" }}>
                                                        <Typography variant="caption" sx={{ display: "block", mb: 0.75, fontWeight: 700, color: "#475569" }}>
                                                            PCBs of PO {po} that will be assigned with the plan
                                                        </Typography>
                                                        <Table size="small" sx={{ bgcolor: "white", borderRadius: 1 }}>
                                                            <TableHead>
                                                                <TableRow>
                                                                    <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>Serial No</TableCell>
                                                                    <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>Part No</TableCell>
                                                                    <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>Category</TableCell>
                                                                </TableRow>
                                                            </TableHead>
                                                            <TableBody>
                                                                {p.ready.map(({ pcb, id }) => (
                                                                    <TableRow key={id}>
                                                                        <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem", fontWeight: 600 }}>{pcb.serialNo || pcb.serialNumber || id}</TableCell>
                                                                        <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem" }}>{pcb.partNumber}</TableCell>
                                                                        <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem" }}>{pcb.Type || "UNKNOWN"}</TableCell>
                                                                    </TableRow>
                                                                ))}
                                                            </TableBody>
                                                        </Table>
                                                    </Box>
                                                </Collapse>
                                            </TableCell>
                                        </TableRow>
                                    </React.Fragment>
                                );
                            })}
                        </TableBody>
                    </Table>
                </TableContainer>
            </Paper>

            {/* ---------- confirm: the whole plan ---------- */}
            <Dialog open={confirmOpen} onClose={assigning ? undefined : () => setConfirmOpen(false)} maxWidth="sm" fullWidth PaperProps={{ sx: { borderRadius: 3 } }}>
                <DialogTitle sx={{ pb: 0.5 }}>
                    <Typography component="span" sx={{ display: "block", fontSize: 19, fontWeight: 700 }}>Assign the whole plan?</Typography>
                    <Typography component="span" sx={{ display: "block", fontSize: 13.5, color: "#64748b" }}>
                        {onePlan ? `${onePlan.version_name || onePlan.name}${onePlan.reference ? ` · ${onePlan.reference}` : ""}` : ""}
                    </Typography>
                </DialogTitle>
                <DialogContent>
                    <Table size="small">
                        <TableHead>
                            <TableRow>
                                <TableCell sx={headSx}>#</TableCell><TableCell sx={headSx}>PO</TableCell>
                                <TableCell sx={headSx}>Part</TableCell><TableCell sx={headSx} align="right">PCBs to assign</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {planRows.map((r) => (
                                <TableRow key={r.production_order}>
                                    <TableCell sx={cellSx}>{r.no}</TableCell>
                                    <TableCell sx={{ ...cellSx, fontWeight: 700, color: r.done ? "#94a3b8" : undefined }}>{r.production_order}</TableCell>
                                    <TableCell sx={{ ...cellSx, color: r.done ? "#94a3b8" : undefined }}>{r.part_number}</TableCell>
                                    <TableCell sx={{ ...cellSx, color: r.done ? "#94a3b8" : undefined }} align="right">
                                        {r.done ? "already assigned" : Math.min(r.ready.length, r.need || r.ready.length)}
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                    <Alert severity="info" sx={{ mt: 1.5 }}>
                        {pcbsToAssign} PCBs of {todo.length} PO{todo.length > 1 ? "s" : ""} are assigned to you in one go. Their schedule slots are then kept: later plans are built around them.
                    </Alert>
                </DialogContent>
                <DialogActions sx={{ px: 3, pb: 2 }}>
                    <Button onClick={() => setConfirmOpen(false)} disabled={assigning} sx={{ textTransform: "none", fontWeight: 600 }}>Cancel</Button>
                    <Button variant="contained" onClick={assignPlan} disabled={!canAssign}
                        startIcon={assigning ? <CircularProgress size={14} color="inherit" /> : <AssignmentTurnedInIcon />}
                        sx={{ textTransform: "none", fontWeight: 700, borderRadius: 2 }}>
                        Assign {pcbsToAssign} PCBs
                    </Button>
                </DialogActions>
            </Dialog>

            <PoGanttDialog
                open={!!gantt}
                onClose={() => setGantt(null)}
                apiBase={apiBase}
                plans={plans}
                initialPlanId={onePlan ? onePlan.id : planId}
                poList={gantt?.pos || null}
                initialFrom={gantt?.from || null}
                initialTo={gantt?.to || null}
            />
        </Box>
    );
}

function AssignPCB() {
    // --- State Management ---
    const [dbPCBs, setDbPCBs] = useState([]);
    const [assignedPCBs, setAssignedPCBs] = useState([]);

    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);
    const [Bid, SetBid] = React.useState("1");

    // Sub-tab for "TO BE ASSIGNED" section
    const [subTab, setSubTab] = useState("workload");

    const [snackbar, setSnackbar] = useState({ open: false, msg: "", type: "info" });

    const [selectedIds, setSelectedIds] = useState(new Set());
    const [filterCategory, setFilterCategory] = useState("All");
    const [searchQuery, setSearchQuery] = useState("");
    const [ganttOpen, setGanttOpen] = useState(false);  // "View Schedule" dialog (read-only)
    const [selectedPlanForGantt, setSelectedPlanForGantt] = useState("base");

    // Workload State
    const [workloadData, setWorkloadData] = useState({ processLoad: {}, operatorLoad: {}, machineLoad: {} });
    const [loadingWorkload, setLoadingWorkload] = useState(false);

    // Expanded Row State for Workload Drill-down
    const [expandedProcess, setExpandedProcess] = useState(null);
    const [expandedOperator, setExpandedOperator] = useState(null);
    const [expandedMachine, setExpandedMachine] = useState(null);
    const [expandedAssignedPo, setExpandedAssignedPo] = useState(null);

    // --- Redux & API Configuration ---
    const configDetails = useSelector((state) => state.MROTDataSavingReducer?.configDetails);

    var API1 = "/supervisor/assign";
    var API2 = "/api/pcb/filter?status=Inaction";
    var API3 = "/supervisor/view";

    var PythonServer = "http://127.0.0.1:2000" + API1;
    var PythonServerViewandAssigned = "http://192.168.0.20:2000" + API3;
    var NodeServerIP = "http://192.168.0.20:8082" + API2;
    var ScheduleServer = "http://192.168.0.20:2000";

    if (configDetails !== undefined) {
        if (configDetails.project && configDetails.project[0].ServerIP) {
            const serverIPs = configDetails.project[0].ServerIP[0];
            if (serverIPs.PythonServerIP) {
                PythonServer = serverIPs.PythonServerIP + API1;
                PythonServerViewandAssigned = serverIPs.PythonServerIP + API3;
                NodeServerIP = serverIPs.NodeServerIP + API2;
                ScheduleServer = serverIPs.PythonServerIP;

            }
        }
    }

    function dataSelection(id) {
        SetBid(id);
        setError(null);
        setSearchQuery("");
        setSelectedIds(new Set());
        setExpandedProcess(null);
        setExpandedOperator(null);
        setExpandedMachine(null);
        if (id === "1") {
            setSubTab("workload");
        }
    }

    useEffect(() => {
        if (Bid === "1") {
            fetchInactionPCBs();
            fetchAssignedPCBs(); // Required for Workload Calculation
        } else if (Bid === "2" || Bid === "3") {
            fetchAssignedPCBs();
        }
    }, [Bid]);

    useEffect(() => {
        if (Bid === "1" && assignedPCBs.length > 0) {
            calculateWorkload();
        } else if (Bid === "1" && assignedPCBs.length === 0) {
            setWorkloadData({ processLoad: {}, operatorLoad: {}, machineLoad: {} });
        }
    }, [Bid, assignedPCBs, configDetails]);

    const fetchInactionPCBs = async () => {
        setIsLoading(true);
        try {
            const resp = await axios.get(NodeServerIP);
            const data = resp.data;

            const processedData = data.map((each_pcb) => {
                let compositeType = each_pcb.Type;
                if (!compositeType && each_pcb.type && each_pcb.source) {
                    compositeType = `${each_pcb.type}`.toUpperCase();
                }
                return { ...each_pcb, Type: compositeType || "UNKNOWN" };
            });
            setDbPCBs(processedData);
        } catch (error) {
            setError(error.message || "failed to fetch data");
            setDbPCBs([]);
        } finally {
            setIsLoading(false);
        }
    };

    const fetchAssignedPCBs = async () => {
        setIsLoading(true);
        setError(null);
        const user = JSON.parse(localStorage.getItem("user"));
        const requestParams = { staff_no: user?.id };

        try {
            const response = await axios.get(PythonServerViewandAssigned, { params: requestParams });
            if (response.data && response.data.pcbs) {
                setAssignedPCBs(response.data.pcbs);
            } else {
                setAssignedPCBs([]);
            }
        } catch (err) {
            setError("Failed to load assigned tasks.");
            setAssignedPCBs([]);
        } finally {
            setIsLoading(false);
        }
    };


    // --- Batch Configuration ---
    const CHILD_BATCH_LIMIT = 30; // Up to 30 child PCBs complete in the same batch time
    const MAIN_BATCH_LIMIT = 30;   // Placeholder for MAIN processes (1 = one by one until configured)

    // Optional fallback: Add lowercase stage names here if an API doesn't return process_type="batch"
    const KNOWN_BATCH_STAGES = new Set([
        // e.g., "cleaning of pcba", "conformal coating", "hass"
    ]);

    // Helper to convert either "HH:MM:SS" or numeric hours into decimal hours
    const parseProcessTimeToHours = (timeVal) => {
        if (timeVal === null || timeVal === undefined) return 0;
        if (typeof timeVal === "number") return timeVal;

        const str = String(timeVal).trim();
        if (str.includes(":")) {
            const parts = str.split(":").map(Number);
            const [hours = 0, minutes = 0, seconds = 0] = parts;
            return (hours || 0) + (minutes || 0) / 60 + (seconds || 0) / 3600;
        }
        return Number(str) || 0;
    };

    // Detects whether a machine/stage is "batch" or "serial"
    const resolveProcessType = (eqOrStep = {}, normalizedStage = "") => {
        // 1. Check boolean flags (from process_type table: process_type_batch)
        if (
            eqOrStep.process_type_batch === true ||
            eqOrStep.is_batch === true ||
            String(eqOrStep.process_type_batch).toLowerCase() === "true"
        ) {
            return "batch";
        }

        // 2. Check string field (from equipment_details: process_type)
        const rawType = String(eqOrStep.process_type || eqOrStep.processType || "").trim().toLowerCase();
        if (rawType.includes("batch")) return "batch";
        if (rawType.includes("serial") || rawType.includes("series")) return "serial";

        // 3. Check fallback set
        if (normalizedStage && KNOWN_BATCH_STAGES.has(normalizedStage)) {
            return "batch";
        }

        return "serial";
    };

    // --- Workload Calculation with Individual Operator Grouping ---
    // const calculateWorkload = async () => {
    //     setLoadingWorkload(true);
    //     try {
    //         const activePCBs = assignedPCBs.filter((pcb) => pcb.Overall_PCB_status !== "COMPLETED");
    //         const uniquePartNums = [...new Set(activePCBs.map((p) => p.partNumber).filter(Boolean))];

    //         let pythonServerIp = "http://127.0.0.1:2000";
    //         if (configDetails?.project?.[0]?.ServerIP?.[0]?.PythonServerIP) {
    //             pythonServerIp = configDetails.project[0].ServerIP[0].PythonServerIP;
    //         }

    //         const timeSource = configDetails?.project?.[0]?.time_source === "sap" ? "sap" : "actual";

    //         const eqPromise = axios
    //             .get(`${pythonServerIp}/get_equipment_det_stagenames`, {
    //                 ...getAuthHeader()
    //             })
    //             .catch(() => ({ data: [] }));

    //         const timePromises = uniquePartNums.map((partNum) =>
    //             axios
    //                 .get(`${pythonServerIp}/api/flow/${partNum}`, {
    //                     ...getAuthHeader(),
    //                     params: { time_source: timeSource }
    //                 })
    //                 .catch(() => ({ data: [] }))
    //         );

    //         const [eqResponse, ...responses] = await Promise.all([eqPromise, ...timePromises]);

    //         const timeMap = {};

    //         uniquePartNums.forEach((partNum, index) => {
    //             timeMap[partNum] = {};
    //             const flowData = Array.isArray(responses[index]?.data) ? responses[index].data : [];

    //             flowData.forEach((step) => {
    //                 const hours = parseProcessTimeToHours(step.process_time);
    //                 const processName = step.step_name || (step.process_detail && step.process_detail.step_name);
    //                 if (processName) {
    //                     timeMap[partNum][processName.trim().toLowerCase()] = hours;
    //                 }
    //             });
    //         });

    //         const processLoad = {};
    //         const operatorLoad = {};
    //         const machineLoad = {};
    //         const processToMachines = {};

    //         const equipments = Array.isArray(eqResponse.data) ? eqResponse.data : [];
    //         equipments.forEach((eq) => {
    //             const machineName = eq.eqpt_name || `Machine ${eq.eqpt_no}`;
    //             if (!machineLoad[machineName]) {
    //                 machineLoad[machineName] = { count: 0, totalHours: 0, pcbs: [] };
    //             }

    //             if (eq.stage_name) {
    //                 const normalizedProcess = eq.stage_name.trim().toLowerCase();
    //                 if (!processToMachines[normalizedProcess]) {
    //                     processToMachines[normalizedProcess] = [];
    //                 }
    //                 if (!processToMachines[normalizedProcess].includes(machineName)) {
    //                     processToMachines[normalizedProcess].push(machineName);
    //                 }
    //             }
    //         });

    //         activePCBs.forEach((pcb) => {
    //             const partNum = pcb.partNumber;
    //             const rawProcessName = pcb.currentProcessName || pcb.current_step || "Unknown Process";
    //             const normalizedProcess = rawProcessName.trim().toLowerCase();

    //             let opNamesArray = [];
    //             if (Array.isArray(pcb.currentProcessOpeName)) {
    //                 opNamesArray = pcb.currentProcessOpeName;
    //             } else if (typeof pcb.currentProcessOpeName === "string" && pcb.currentProcessOpeName.trim()) {
    //                 opNamesArray = pcb.currentProcessOpeName
    //                     .split(",")
    //                     .map((name) => name.trim())
    //                     .filter(Boolean);
    //             } else if (pcb.operator && pcb.operator.name && pcb.operator.name !== "YET TO START") {
    //                 opNamesArray = [pcb.operator.name];
    //             }

    //             if (opNamesArray.length === 0) {
    //                 opNamesArray = ["Unassigned"];
    //             }

    //             const timeRequired =
    //                 timeMap[partNum] && timeMap[partNum][normalizedProcess]
    //                     ? timeMap[partNum][normalizedProcess]
    //                     : 0;

    //             const pcbDetail = {
    //                 serialNo: pcb.serialNo || "N/A",
    //                 partNumber: pcb.partNumber || "N/A",
    //                 poNumber: pcb.Production_order || pcb.productionOrder || pcb.productionOrderNumber || "N/A",
    //                 processName: rawProcessName,
    //                 operatorName: opNamesArray.join(", "),
    //                 timeHours: timeRequired
    //             };

    //             // Process Wise Grouping
    //             if (!processLoad[rawProcessName]) processLoad[rawProcessName] = { count: 0, totalHours: 0, pcbs: [] };
    //             processLoad[rawProcessName].count += 1;
    //             processLoad[rawProcessName].totalHours += timeRequired;
    //             processLoad[rawProcessName].pcbs.push(pcbDetail);

    //             // Machine Wise Grouping
    //             const mappedMachines = processToMachines[normalizedProcess];
    //             if (mappedMachines && mappedMachines.length > 0) {
    //                 mappedMachines.forEach((machineName) => {
    //                     if (machineLoad[machineName]) {
    //                         machineLoad[machineName].count += 1;
    //                         machineLoad[machineName].totalHours += timeRequired;
    //                         machineLoad[machineName].pcbs.push(pcbDetail);
    //                     }
    //                 });
    //             }

    //             // Operator Wise Grouping
    //             opNamesArray.forEach((singleOpName) => {
    //                 if (!operatorLoad[singleOpName])
    //                     operatorLoad[singleOpName] = { count: 0, totalHours: 0, pcbsByProcess: {} };
    //                 operatorLoad[singleOpName].count += 1;
    //                 operatorLoad[singleOpName].totalHours += timeRequired;

    //                 if (!operatorLoad[singleOpName].pcbsByProcess[rawProcessName]) {
    //                     operatorLoad[singleOpName].pcbsByProcess[rawProcessName] = [];
    //                 }
    //                 operatorLoad[singleOpName].pcbsByProcess[rawProcessName].push(pcbDetail);
    //             });
    //         });

    //         setWorkloadData({ processLoad, operatorLoad, machineLoad });
    //     } catch (error) {
    //         console.error("Failed to calculate workload", error);
    //         setSnackbar({ open: true, msg: "Failed to calculate workload. Refer to console.", type: "error" });
    //         setWorkloadData({ processLoad: {}, operatorLoad: {}, machineLoad: {} });
    //     } finally {
    //         setLoadingWorkload(false);
    //     }
    // };
    // --- Workload Calculation with Complete Machine Inventory ---
    // const calculateWorkload = async () => {
    //         setLoadingWorkload(true);
    //         try {
    //             const activePCBs = assignedPCBs.filter((pcb) => pcb.Overall_PCB_status !== "COMPLETED");
    //             const uniquePartNums = [...new Set(activePCBs.map((p) => p.partNumber).filter(Boolean))];

    //             let pythonServerIp = "http://192.168.0.20:2000";
    //             if (configDetails?.project?.[0]?.ServerIP?.[0]?.PythonServerIP) {
    //                 pythonServerIp = configDetails.project[0].ServerIP[0].PythonServerIP;
    //             }

    //             const timeSource = configDetails?.project?.[0]?.time_source === "sap" ? "sap" : "actual";

    //             const invEquipPromise = axios
    //                 .get(`${pythonServerIp}/inventory/equipments`, {
    //                     ...getAuthHeader()
    //                 })
    //                 .catch(() => ({ data: [] }));

    //             const stageEquipPromise = axios
    //                 .get(`${pythonServerIp}/get_equipment_det_stagenames`, {
    //                     ...getAuthHeader()
    //                 })
    //                 .catch(() => ({ data: [] }));

    //             const timePromises = uniquePartNums.map((partNum) =>
    //                 axios
    //                     .get(`${pythonServerIp}/api/flow/${partNum}`, {
    //                         ...getAuthHeader(),
    //                         params: { time_source: timeSource }
    //                     })
    //                     .catch(() => ({ data: [] }))
    //             );

    //             const [invResponse, eqResponse, ...responses] = await Promise.all([
    //                 invEquipPromise,
    //                 stageEquipPromise,
    //                 ...timePromises
    //             ]);

    //             const timeMap = {};
    //             const stageProcessTypeMap = {}; // normalizedStage -> "batch" | "serial"

    //             uniquePartNums.forEach((partNum, index) => {
    //                 timeMap[partNum] = {};
    //                 const flowData = Array.isArray(responses[index]?.data) ? responses[index].data : [];

    //                 flowData.forEach((step) => {
    //                     const hours = parseProcessTimeToHours(step.process_time);
    //                     const processName = step.step_name || (step.process_detail && step.process_detail.step_name);
    //                     if (processName) {
    //                         const normName = processName.trim().toLowerCase();
    //                         timeMap[partNum][normName] = hours;

    //                         // Capture batch/serial info if returned by flow API
    //                         const stepType = resolveProcessType(step, normName);
    //                         if (stepType === "batch") {
    //                             stageProcessTypeMap[normName] = "batch";
    //                         }
    //                     }
    //                 });
    //             });

    //             const processLoad = {};
    //             const operatorLoad = {};
    //             const machineLoad = {};
    //             const processToMachines = {};

    //             const rawInvData = invResponse?.data;
    //             const masterEquipments =
    //                 rawInvData && rawInvData[0] && Array.isArray(rawInvData[0].items)
    //                     ? rawInvData[0].items
    //                     : Array.isArray(rawInvData)
    //                     ? rawInvData
    //                     : [];

    //             const stageEquipments = Array.isArray(eqResponse?.data) ? eqResponse.data : [];

    //             const registerMachine = (eq) => {
    //                 const eqptNo = String(eq.eqpt_no || eq.equip_no || eq.machine_id || "").trim();
    //                 const eqptName = (eq.eqpt_name || eq.name || "").trim();
    //                 if (!eqptNo && !eqptName) return;

    //                 const machineKey = eqptNo && eqptName
    //                     ? `${eqptName} (${eqptNo})`
    //                     : eqptName || `Machine ${eqptNo}`;

    //                 // Determine stage name (avoid treating "Batch"/"Serial" in process_type as a stage name)
    //                 const rawProcessTypeField = String(eq.process_type || "").trim().toLowerCase();
    //                 const isProcessTypeMode = ["batch", "serial", "series"].includes(rawProcessTypeField);
    //                 const stageOrProcess = eq.stage_name || eq.stage || (!isProcessTypeMode ? eq.process_type : "");
    //                 const normalizedStage = stageOrProcess ? String(stageOrProcess).trim().toLowerCase() : "";

    //                 const detectedType = resolveProcessType(eq, normalizedStage);
    //                 if (normalizedStage && detectedType === "batch") {
    //                     stageProcessTypeMap[normalizedStage] = "batch";
    //                 }

    //                 if (!machineLoad[machineKey]) {
    //                     machineLoad[machineKey] = {
    //                         eqptNo,
    //                         eqptName: eqptName || `Machine ${eqptNo}`,
    //                         processType: detectedType, // "batch" or "serial"
    //                         count: 0,
    //                         totalHours: 0,
    //                         batchCount: 0,
    //                         pcbs: []
    //                     };
    //                 } else if (detectedType === "batch") {
    //                     machineLoad[machineKey].processType = "batch";
    //                 }

    //                 if (normalizedStage) {
    //                     if (!processToMachines[normalizedStage]) {
    //                         processToMachines[normalizedStage] = [];
    //                     }
    //                     if (!processToMachines[normalizedStage].includes(machineKey)) {
    //                         processToMachines[normalizedStage].push(machineKey);
    //                     }
    //                 }
    //             };

    //             masterEquipments.forEach(registerMachine);
    //             stageEquipments.forEach(registerMachine);

    //             activePCBs.forEach((pcb) => {
    //                 const partNum = pcb.partNumber;
    //                 const rawProcessName = pcb.currentProcessName || pcb.current_step || "Unknown Process";
    //                 const normalizedProcess = rawProcessName.trim().toLowerCase();
    //                 const pcbCategory = String(pcb.Type || pcb.type || "").trim().toUpperCase(); // e.g., HEXA-CHILD, OCTA-MAIN

    //                 let opNamesArray = [];
    //                 if (Array.isArray(pcb.currentProcessOpeName)) {
    //                     opNamesArray = pcb.currentProcessOpeName;
    //                 } else if (typeof pcb.currentProcessOpeName === "string" && pcb.currentProcessOpeName.trim()) {
    //                     opNamesArray = pcb.currentProcessOpeName
    //                         .split(",")
    //                         .map((name) => name.trim())
    //                         .filter(Boolean);
    //                 } else if (pcb.operator && pcb.operator.name && pcb.operator.name !== "YET TO START") {
    //                     opNamesArray = [pcb.operator.name];
    //                 }

    //                 if (opNamesArray.length === 0) {
    //                     opNamesArray = ["Unassigned"];
    //                 }

    //                 const timeRequired =
    //                     timeMap[partNum] && timeMap[partNum][normalizedProcess] !== undefined
    //                         ? timeMap[partNum][normalizedProcess]
    //                         : 0;

    //                 const pcbDetail = {
    //                     serialNo: pcb.serialNo || "N/A",
    //                     partNumber: pcb.partNumber || "N/A",
    //                     pcbType: pcbCategory || "UNKNOWN",
    //                     poNumber: pcb.Production_order || pcb.productionOrder || pcb.productionOrderNumber || "N/A",
    //                     processName: rawProcessName,
    //                     normalizedProcess,
    //                     operatorName: opNamesArray.join(", "),
    //                     timeHours: timeRequired
    //                 };

    //                 // 1. Process-Wise Grouping
    //                 if (!processLoad[rawProcessName]) {
    //                     processLoad[rawProcessName] = { count: 0, totalHours: 0, pcbs: [] };
    //                 }
    //                 processLoad[rawProcessName].count += 1;
    //                 processLoad[rawProcessName].totalHours += timeRequired;
    //                 processLoad[rawProcessName].pcbs.push(pcbDetail);

    //                 // 2. Queue PCBs into Mapped Machines (Time is calculated below based on Batch vs Serial)
    //                 const mappedMachines = processToMachines[normalizedProcess];
    //                 if (mappedMachines && mappedMachines.length > 0) {
    //                     mappedMachines.forEach((machineKey) => {
    //                         if (machineLoad[machineKey]) {
    //                             machineLoad[machineKey].count += 1;
    //                             machineLoad[machineKey].pcbs.push(pcbDetail);
    //                         }
    //                     });
    //                 }

    //                 // 3. Operator-Wise Grouping
    //                 opNamesArray.forEach((singleOpName) => {
    //                     if (!operatorLoad[singleOpName]) {
    //                         operatorLoad[singleOpName] = { count: 0, totalHours: 0, pcbsByProcess: {} };
    //                     }
    //                     operatorLoad[singleOpName].count += 1;
    //                     operatorLoad[singleOpName].totalHours += timeRequired;

    //                     if (!operatorLoad[singleOpName].pcbsByProcess[rawProcessName]) {
    //                         operatorLoad[singleOpName].pcbsByProcess[rawProcessName] = [];
    //                     }
    //                     operatorLoad[singleOpName].pcbsByProcess[rawProcessName].push(pcbDetail);
    //                 });
    //             });

    //             // --- Calculate Machine Total Hours Based on Process Type (Batch vs Serial) ---
    //             Object.values(machineLoad).forEach((machine) => {
    //                 if (machine.pcbs.length === 0) {
    //                     machine.totalHours = 0;
    //                     machine.batchCount = 0;
    //                     return;
    //                 }

    //                 // Group queued PCBs on this machine by their stage
    //                 const pcbsByStage = {};
    //                 machine.pcbs.forEach((pcbItem) => {
    //                     const stg = pcbItem.normalizedProcess;
    //                     if (!pcbsByStage[stg]) pcbsByStage[stg] = [];
    //                     pcbsByStage[stg].push(pcbItem);
    //                 });

    //                 let machineTotalHours = 0;
    //                 let totalBatchesOnMachine = 0;

    //                 Object.entries(pcbsByStage).forEach(([stg, pcbsInStage]) => {
    //                     const isBatchStage =
    //                         machine.processType === "batch" || stageProcessTypeMap[stg] === "batch";

    //                     if (isBatchStage) {
    //                         machine.processType = "batch";

    //                         // Separate CHILD and MAIN PCBs
    //                         const childPcbs = pcbsInStage.filter((p) => p.pcbType.includes("CHILD"));
    //                         const mainPcbs = pcbsInStage.filter((p) => !p.pcbType.includes("CHILD"));

    //                         // Child PCBs: up to 30 complete in the same cycle time
    //                         if (childPcbs.length > 0) {
    //                             const childBatches = Math.ceil(childPcbs.length / CHILD_BATCH_LIMIT);
    //                             // Use the unit process time for the batch run
    //                             const unitChildTime = Math.max(...childPcbs.map((p) => Number(p.timeHours) || 0));
    //                             machineTotalHours += childBatches * unitChildTime;
    //                             totalBatchesOnMachine += childBatches;
    //                         }

    //                         // Main PCBs: uses MAIN_BATCH_LIMIT (currently 1 = serial until specified)
    //                         if (mainPcbs.length > 0) {
    //                             if (MAIN_BATCH_LIMIT > 1) {
    //                                 const mainBatches = Math.ceil(mainPcbs.length / MAIN_BATCH_LIMIT);
    //                                 const unitMainTime = Math.max(...mainPcbs.map((p) => Number(p.timeHours) || 0));
    //                                 machineTotalHours += mainBatches * unitMainTime;
    //                                 totalBatchesOnMachine += mainBatches;
    //                             } else {
    //                                 machineTotalHours += mainPcbs.reduce((sum, p) => sum + (Number(p.timeHours) || 0), 0);
    //                             }
    //                         }
    //                     } else {
    //                         // SERIAL Process: happens one by one
    //                         machineTotalHours += pcbsInStage.reduce((sum, p) => sum + (Number(p.timeHours) || 0), 0);
    //                     }
    //                 });

    //                 machine.totalHours = machineTotalHours;
    //                 machine.batchCount = totalBatchesOnMachine;
    //             });

    //             setWorkloadData({ processLoad, operatorLoad, machineLoad });
    //         } catch (error) {
    //             console.error("Failed to calculate workload", error);
    //             setSnackbar({ open: true, msg: "Failed to calculate workload. Refer to console.", type: "error" });
    //             setWorkloadData({ processLoad: {}, operatorLoad: {}, machineLoad: {} });
    //         } finally {
    //             setLoadingWorkload(false);
    //         }
    //     };
    // --- Workload Calculation with Complete Machine, Process & Operator Batching ---
// --- Workload Calculation with Complete Machine, Process & Operator Batching ---
    const calculateWorkload = async () => {
        setLoadingWorkload(true);
        try {
            const activePCBs = assignedPCBs.filter((pcb) => pcb.Overall_PCB_status !== "COMPLETED");
            const uniquePartNums = [...new Set(activePCBs.map((p) => p.partNumber).filter(Boolean))];

            let pythonServerIp = "http://192.168.0.20:2000";
            if (configDetails?.project?.[0]?.ServerIP?.[0]?.PythonServerIP) {
                pythonServerIp = configDetails.project[0].ServerIP[0].PythonServerIP;
            }

            const timeSource = configDetails?.project?.[0]?.time_source === "sap" ? "sap" : "actual";

            const invEquipPromise = axios
                .get(`${pythonServerIp}/inventory/equipments`, { ...getAuthHeader() })
                .catch(() => ({ data: [] }));

            const stageEquipPromise = axios
                .get(`${pythonServerIp}/get_equipment_det_stagenames`, { ...getAuthHeader() })
                .catch(() => ({ data: [] }));

            // NEW: Fetch process types (Batch vs Serial) dynamically from the database
            const processTypePromise = axios
                .get(`${pythonServerIp}/processtype/all`, { ...getAuthHeader() })
                .catch(() => ({ data: [] }));

            const timePromises = uniquePartNums.map((partNum) =>
                axios
                    .get(`${pythonServerIp}/api/flow/${partNum}`, {
                        ...getAuthHeader(),
                        params: { time_source: timeSource }
                    })
                    .catch(() => ({ data: [] }))
            );

            const [invResponse, eqResponse, procTypeResponse, ...responses] = await Promise.all([
                invEquipPromise,
                stageEquipPromise,
                processTypePromise,
                ...timePromises
            ]);

            // Build Batch Stage IDs Set from dynamic DB fetch (no hardcoding needed)
            const processTypes = Array.isArray(procTypeResponse?.data) ? procTypeResponse.data : [];
            const batchStageIds = new Set();
            processTypes.forEach(pt => {
                if (pt.process_type_batch) {
                    batchStageIds.add(pt.stage_id);
                }
            });

            const timeMap = {};
            const stageProcessTypeMap = {}; // normalizedStage -> "batch" | "serial"

            uniquePartNums.forEach((partNum, index) => {
                timeMap[partNum] = {};
                const flowData = Array.isArray(responses[index]?.data) ? responses[index].data : [];

                flowData.forEach((step) => {
                    const hours = parseProcessTimeToHours(step.process_time);
                    const processName = step.step_name || (step.process_detail && step.process_detail.step_name);
                    const stageId = step.flow_step_id || step.process_id || step.stage_id || (step.process_detail && step.process_detail.flow_step_id);

                    if (processName) {
                        const normName = processName.trim().toLowerCase();
                        timeMap[partNum][normName] = hours;

                        let stepType = resolveProcessType(step, normName);
                        // Override with actual DB value if matched
                        if (stageId && batchStageIds.has(stageId)) {
                            stepType = "batch";
                        }

                        if (stepType === "batch") {
                            stageProcessTypeMap[normName] = "batch";
                        }
                    }
                });
            });

            const processLoad = {};
            const operatorLoad = {};
            const machineLoad = {};
            const processToMachines = {};

            const rawInvData = invResponse?.data;
            const masterEquipments =
                rawInvData && rawInvData[0] && Array.isArray(rawInvData[0].items)
                    ? rawInvData[0].items
                    : Array.isArray(rawInvData)
                        ? rawInvData
                        : [];
            const stageEquipments = Array.isArray(eqResponse?.data) ? eqResponse.data : [];

            const registerMachine = (eq) => {
                const eqptNo = String(eq.eqpt_no || eq.equip_no || eq.machine_id || "").trim();
                const eqptName = (eq.eqpt_name || eq.name || "").trim();
                if (!eqptNo && !eqptName) return;

                const machineKey = eqptNo && eqptName
                    ? `${eqptName} (${eqptNo})`
                    : eqptName || `Machine ${eqptNo}`;

                const rawProcessTypeField = String(eq.process_type || "").trim().toLowerCase();
                const isProcessTypeMode = ["batch", "serial", "series"].includes(rawProcessTypeField);
                const stageOrProcess = eq.stage_name || eq.stage || (!isProcessTypeMode ? eq.process_type : "");
                const normalizedStage = stageOrProcess ? String(stageOrProcess).trim().toLowerCase() : "";
                const stageId = eq.stage_id || eq.flow_step_id;

                let detectedType = resolveProcessType(eq, normalizedStage);
                // Override with actual DB value if matched
                if (stageId && batchStageIds.has(stageId)) {
                    detectedType = "batch";
                }

                if (normalizedStage && detectedType === "batch") {
                    stageProcessTypeMap[normalizedStage] = "batch";
                }

                if (!machineLoad[machineKey]) {
                    machineLoad[machineKey] = {
                        eqptNo,
                        eqptName: eqptName || `Machine ${eqptNo}`,
                        processType: detectedType,
                        count: 0,
                        totalHours: 0,
                        batchCount: 0,
                        pcbs: []
                    };
                } else if (detectedType === "batch") {
                    machineLoad[machineKey].processType = "batch";
                }

                if (normalizedStage) {
                    if (!processToMachines[normalizedStage]) {
                        processToMachines[normalizedStage] = [];
                    }
                    if (!processToMachines[normalizedStage].includes(machineKey)) {
                        processToMachines[normalizedStage].push(machineKey);
                    }
                }
            };

            masterEquipments.forEach(registerMachine);
            stageEquipments.forEach(registerMachine);

            // 1. Group PCBs into arrays without summing time yet
            activePCBs.forEach((pcb) => {
                const partNum = pcb.partNumber;
                const rawProcessName = pcb.currentProcessName || pcb.current_step || "Unknown Process";
                const normalizedProcess = rawProcessName.trim().toLowerCase();
                const pcbCategory = String(pcb.Type || pcb.type || "").trim().toUpperCase();
                const stageId = pcb.currentStepOrder || pcb.current_step_order || pcb.currentStepId;

                // Final safety check to perfectly link the active PCB's stage to the batch map
                if (stageId && batchStageIds.has(stageId)) {
                    stageProcessTypeMap[normalizedProcess] = "batch";
                }

                let opNamesArray = [];
                if (Array.isArray(pcb.currentProcessOpeName)) {
                    opNamesArray = pcb.currentProcessOpeName;
                } else if (typeof pcb.currentProcessOpeName === "string" && pcb.currentProcessOpeName.trim()) {
                    opNamesArray = pcb.currentProcessOpeName
                        .split(",")
                        .map((name) => name.trim())
                        .filter(Boolean);
                } else if (pcb.operator && pcb.operator.name && pcb.operator.name !== "YET TO START") {
                    opNamesArray = [pcb.operator.name];
                }

                if (opNamesArray.length === 0) {
                    opNamesArray = ["Unassigned"];
                }

                const timeRequired =
                    timeMap[partNum] && timeMap[partNum][normalizedProcess] !== undefined
                        ? timeMap[partNum][normalizedProcess]
                        : 0;

                const pcbDetail = {
                    serialNo: pcb.serialNo || "N/A",
                    partNumber: pcb.partNumber || "N/A",
                    pcbType: pcbCategory || "UNKNOWN",
                    poNumber: pcb.Production_order || pcb.productionOrder || pcb.productionOrderNumber || "N/A",
                    processName: rawProcessName,
                    normalizedProcess,
                    operatorName: opNamesArray.join(", "),
                    timeHours: timeRequired
                };

                // Process Wise Grouping
                if (!processLoad[rawProcessName]) {
                    processLoad[rawProcessName] = { count: 0, totalHours: 0, pcbs: [] };
                }
                processLoad[rawProcessName].count += 1;
                processLoad[rawProcessName].pcbs.push(pcbDetail);

                // Machine Wise Grouping
                const mappedMachines = processToMachines[normalizedProcess];
                if (mappedMachines && mappedMachines.length > 0) {
                    mappedMachines.forEach((machineKey) => {
                        if (machineLoad[machineKey]) {
                            machineLoad[machineKey].count += 1;
                            machineLoad[machineKey].pcbs.push(pcbDetail);
                        }
                    });
                }

                // Operator Wise Grouping
                opNamesArray.forEach((singleOpName) => {
                    if (!operatorLoad[singleOpName]) {
                        operatorLoad[singleOpName] = { count: 0, totalHours: 0, pcbsByProcess: {} };
                    }
                    operatorLoad[singleOpName].count += 1;

                    if (!operatorLoad[singleOpName].pcbsByProcess[rawProcessName]) {
                        operatorLoad[singleOpName].pcbsByProcess[rawProcessName] = [];
                    }
                    operatorLoad[singleOpName].pcbsByProcess[rawProcessName].push(pcbDetail);
                });
            });

            // --- Helper Function for Batch Mathematics ---
            const calculateGroupHours = (pcbList, isBatchMode) => {
                if (!isBatchMode) {
                    return pcbList.reduce((sum, p) => sum + (Number(p.timeHours) || 0), 0);
                }

                let hours = 0;
                const childPcbs = pcbList.filter((p) => p.pcbType.includes("CHILD"));
                const mainPcbs = pcbList.filter((p) => !p.pcbType.includes("CHILD"));

                if (childPcbs.length > 0) {
                    const childBatches = Math.ceil(childPcbs.length / CHILD_BATCH_LIMIT);
                    const unitChildTime = Math.max(...childPcbs.map((p) => Number(p.timeHours) || 0));
                    hours += childBatches * unitChildTime;
                }

                if (mainPcbs.length > 0) {
                    if (MAIN_BATCH_LIMIT > 1) {
                        const mainBatches = Math.ceil(mainPcbs.length / MAIN_BATCH_LIMIT);
                        const unitMainTime = Math.max(...mainPcbs.map((p) => Number(p.timeHours) || 0));
                        hours += mainBatches * unitMainTime;
                    } else {
                        hours += mainPcbs.reduce((sum, p) => sum + (Number(p.timeHours) || 0), 0);
                    }
                }
                return hours;
            };

            // --- 2. Calculate Machine Totals ---
            Object.values(machineLoad).forEach((machine) => {
                if (machine.pcbs.length === 0) return;

                const pcbsByStage = {};
                machine.pcbs.forEach((pcbItem) => {
                    const stg = pcbItem.normalizedProcess;
                    if (!pcbsByStage[stg]) pcbsByStage[stg] = [];
                    pcbsByStage[stg].push(pcbItem);
                });

                let machineTotalHours = 0;
                let totalBatchesOnMachine = 0;

                Object.entries(pcbsByStage).forEach(([stg, pcbsInStage]) => {
                    const isBatchStage = machine.processType === "batch" || stageProcessTypeMap[stg] === "batch";
                    if (isBatchStage) machine.processType = "batch";

                    machineTotalHours += calculateGroupHours(pcbsInStage, isBatchStage);

                    if (isBatchStage) {
                        const cCount = pcbsInStage.filter((p) => p.pcbType.includes("CHILD")).length;
                        const mCount = pcbsInStage.filter((p) => !p.pcbType.includes("CHILD")).length;
                        totalBatchesOnMachine += Math.ceil(cCount / CHILD_BATCH_LIMIT);
                        if (MAIN_BATCH_LIMIT > 1) {
                            totalBatchesOnMachine += Math.ceil(mCount / MAIN_BATCH_LIMIT);
                        }
                    }
                });
                machine.totalHours = machineTotalHours;
                machine.batchCount = totalBatchesOnMachine;
            });

            // --- 3. Calculate Process Totals ---
            Object.values(processLoad).forEach((proc) => {
                const pcbsByStage = {};
                proc.pcbs.forEach((p) => {
                    const stg = p.normalizedProcess;
                    if (!pcbsByStage[stg]) pcbsByStage[stg] = [];
                    pcbsByStage[stg].push(p);
                });

                let procTotal = 0;
                let totalBatches = 0;
                let isBatchProc = false;

                Object.entries(pcbsByStage).forEach(([stg, pcbsInStage]) => {
                    const isBatchStage = stageProcessTypeMap[stg] === "batch";
                    if (isBatchStage) isBatchProc = true;

                    procTotal += calculateGroupHours(pcbsInStage, isBatchStage);

                    if (isBatchStage) {
                        const cCount = pcbsInStage.filter((p) => p.pcbType.includes("CHILD")).length;
                        const mCount = pcbsInStage.filter((p) => !p.pcbType.includes("CHILD")).length;
                        totalBatches += Math.ceil(cCount / CHILD_BATCH_LIMIT);
                        if (MAIN_BATCH_LIMIT > 1) {
                            totalBatches += Math.ceil(mCount / MAIN_BATCH_LIMIT);
                        }
                    }
                });
                proc.totalHours = procTotal;
                proc.processType = isBatchProc ? "batch" : "serial";
                proc.batchCount = totalBatches;
            });

            // --- 4. Calculate Operator Totals ---
            Object.values(operatorLoad).forEach((op) => {
                let opTotal = 0;
                op.processStats = {}; // Store batch/serial flag for each expanded stage

                Object.entries(op.pcbsByProcess).forEach(([procName, pcbList]) => {
                    const pcbsByStage = {};
                    pcbList.forEach((p) => {
                        const stg = p.normalizedProcess;
                        if (!pcbsByStage[stg]) pcbsByStage[stg] = [];
                        pcbsByStage[stg].push(p);
                    });

                    let pTotal = 0;
                    let pBatches = 0;
                    let pIsBatch = false;

                    Object.entries(pcbsByStage).forEach(([stg, pcbsInStage]) => {
                        const isBatchStage = stageProcessTypeMap[stg] === "batch";
                        if (isBatchStage) pIsBatch = true;

                        pTotal += calculateGroupHours(pcbsInStage, isBatchStage);

                        if (isBatchStage) {
                            const cCount = pcbsInStage.filter((p) => p.pcbType.includes("CHILD")).length;
                            const mCount = pcbsInStage.filter((p) => !p.pcbType.includes("CHILD")).length;
                            pBatches += Math.ceil(cCount / CHILD_BATCH_LIMIT);
                            if (MAIN_BATCH_LIMIT > 1) {
                                pBatches += Math.ceil(mCount / MAIN_BATCH_LIMIT);
                            }
                        }
                    });

                    op.processStats[procName] = {
                        processType: pIsBatch ? "batch" : "serial",
                        batchCount: pBatches
                    };
                    opTotal += pTotal;
                });
                op.totalHours = opTotal;
            });

            setWorkloadData({ processLoad, operatorLoad, machineLoad });
        } catch (error) {
            console.error("Failed to calculate workload", error);
            setSnackbar({ open: true, msg: "Failed to calculate workload. Refer to console.", type: "error" });
            setWorkloadData({ processLoad: {}, operatorLoad: {}, machineLoad: {} });
        } finally {
            setLoadingWorkload(false);
        }
    };

    const handleAssign = async () => {
        if (selectedIds.size === 0) return;

        const user = JSON.parse(localStorage.getItem("user"));
        if (!user) {
            setSnackbar({ open: true, msg: "User details not found. Please log in.", type: "error" });
            return;
        }

        const selectedItems = dbPCBs.filter((pcb, index) => {
            const id = getPcbId(pcb, index);
            return selectedIds.has(id);
        });

        const payload = {
            supervisor_staff_no: user?.id,
            pcb_serial_parts: selectedItems.map((item) => item.PCBserialNoPartNumber)
        };

        try {
            await axios.post(PythonServer, payload);

            setSnackbar({ open: true, msg: `Successfully assigned ${selectedItems.length} PCBs.`, type: "success" });
            setSelectedIds(new Set());
            fetchInactionPCBs();
            fetchAssignedPCBs();
        } catch (err) {
            const errorMsg = err.response?.data?.detail || "An error occurred during assignment.";
            setSnackbar({ open: true, msg: err.response?.data?.detail || errorMsg, type: "error" });
        }
    };

    function getPcbId(pcb, index) {
        return pcb.PCBserialNoPartNumber || pcb._pcb_key_id || `unknown-${index}`;
    }

    const filterDataBySearch = (data) => {
        if (!searchQuery) return data;
        const lowerQuery = searchQuery.toLowerCase();

        return data.filter((item) => {
            const serial = (item.serialNo || item.serialNumber || "").toLowerCase();
            const prodOrder = (item.productionOrderNumber || "").toLowerCase();
            const orderNo = (item.orderNumber || "").toLowerCase();
            const partNo = (item.partNumber || "").toLowerCase();

            return (
                serial.includes(lowerQuery) ||
                prodOrder.includes(lowerQuery) ||
                orderNo.includes(lowerQuery) ||
                partNo.includes(lowerQuery)
            );
        });
    };

    const tab1Data = useMemo(() => {
        let data = dbPCBs;
        if (filterCategory !== "All") {
            data = data.filter((pcb) => pcb.Type === filterCategory);
        }
        return filterDataBySearch(data);
    }, [dbPCBs, filterCategory, searchQuery]);

    // const tab2Data = useMemo(() => {
    //     const data = assignedPCBs.filter((pcb) => pcb.Overall_PCB_status !== "COMPLETED");
    //     return filterDataBySearch(data);
    // }, [assignedPCBs, searchQuery]);

    // const tab3Data = useMemo(() => {
    //     const data = assignedPCBs.filter((pcb) => pcb.Overall_PCB_status === "COMPLETED");
    //     return filterDataBySearch(data);
    // }, [assignedPCBs, searchQuery]);


    const tab2Data = useMemo(() => {
        const data = assignedPCBs.filter((pcb) => pcb.Overall_PCB_status !== "COMPLETED");
        return filterDataBySearch(data);
    }, [assignedPCBs, searchQuery]);

    const assignedPosGrouped = useMemo(() => {
        const groups = {};
        tab2Data.forEach((pcb) => {
            const po = pcbPoOf(pcb) || "UNKNOWN_PO";
            if (!groups[po]) {
                groups[po] = {
                    po,
                    partNumber: pcb.partNumber,
                    pcbs: []
                };
            }
            groups[po].pcbs.push(pcb);
        });
        return Object.values(groups);
    }, [tab2Data]);

    const tab3Data = useMemo(() => {
        const data = assignedPCBs.filter((pcb) => pcb.Overall_PCB_status === "COMPLETED");
        return filterDataBySearch(data);
    }, [assignedPCBs, searchQuery]);



    const handleSelectAll = (e) => {
        const isChecked = e.target.checked;
        const newSelected = new Set(selectedIds);
        tab1Data.forEach((pcb, i) => {
            const id = getPcbId(pcb, i);
            isChecked ? newSelected.add(id) : newSelected.delete(id);
        });
        setSelectedIds(newSelected);
    };

    const toggleSelect = (id) => {
        const newSelected = new Set(selectedIds);
        newSelected.has(id) ? newSelected.delete(id) : newSelected.add(id);
        setSelectedIds(newSelected);
    };

    const isAllSelected = tab1Data.length > 0 && tab1Data.every((pcb, i) => selectedIds.has(getPcbId(pcb, i)));
    const isIndeterminate = tab1Data.some((pcb, i) => selectedIds.has(getPcbId(pcb, i))) && !isAllSelected;

    const getDynamicColumns = () => {
        if (!dbPCBs.length) return [];
        const firstItem = dbPCBs[0];

        const EXPLICIT_HIDDEN = [
            "password",
            "__v",
            "linkedOperations",
            "isWorkAssigned",
            "Type",
            "PCBserialNoPartNumber",
            "updatedAt",
            "status",
            "productionOrder",
            "createdAt"
        ];

        return Object.keys(firstItem).filter((key) => {
            const lowerKey = key.toLowerCase();
            if (lowerKey === "id" || lowerKey === "_id" || lowerKey.includes("key_id")) return false;
            if (lowerKey.startsWith("user")) return false;
            if (EXPLICIT_HIDDEN.includes(key)) return false;
            return true;
        });
    };

    const dynamicColumns = getDynamicColumns();

    // Sorted Workload Entries
    const machineEntries = Object.entries(workloadData.machineLoad || {}).sort(
        (a, b) => b[1].totalHours - a[1].totalHours
    );
    const processEntries = Object.entries(workloadData.processLoad || {}).sort(
        (a, b) => b[1].totalHours - a[1].totalHours
    );
    const operatorEntries = Object.entries(workloadData.operatorLoad || {}).sort(
        (a, b) => b[1].totalHours - a[1].totalHours
    );

    return (
        <Box sx={{ width: "100%", mx: "auto", fontFamily: "Inter, sans-serif" }}>
            {/* --- 1. Main Navigation Tabs --- */}
            <Box sx={{ mt: 0.5, mb: 2, display: "flex", justifyContent: "center", flexWrap: "wrap" }}>
                <Paper elevation={0} sx={{ borderRadius: 3, bgcolor: "#e2e8f0", p: 0.6, display: "inline-flex", gap: 1 }}>
                    {BUTTON_OPTS.map((item) => {
                        const isActive = Bid === item.id;
                        return (
                            <Button
                                key={item.id}
                                onClick={() => dataSelection(item.id)}
                                startIcon={item.icon}
                                disableRipple
                                sx={{
                                    borderRadius: "8px",
                                    px: 2.2,
                                    py: 0.8,
                                    fontSize: "0.85rem",
                                    fontWeight: isActive ? 700 : 600,
                                    textTransform: "none",
                                    transition: "all 0.2s cubic-bezier(0.4, 0, 0.2, 1)",
                                    backgroundColor: isActive ? "#ffffff" : "transparent",
                                    color: isActive ? "#0f172a" : "#475569",
                                    boxShadow: isActive ? "0 2px 4px rgba(0, 0, 0, 0.06)" : "none",
                                    "&:hover": {
                                        backgroundColor: isActive ? "#ffffff" : "rgba(255, 255, 255, 0.5)",
                                        color: "#0f172a"
                                    }
                                }}
                            >
                                <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                                    <Typography variant="inherit">{item.name}</Typography>
                                    <Box
                                        component="span"
                                        sx={{
                                            display: "inline-flex",
                                            alignItems: "center",
                                            justifyContent: "center",
                                            px: 0.8,
                                            minWidth: "22px",
                                            height: "20px",
                                            borderRadius: "6px",
                                            fontSize: "0.75rem",
                                            fontWeight: 700,
                                            backgroundColor: isActive ? "#eff6ff" : "rgba(100, 116, 139, 0.15)",
                                            color: isActive ? "#0d6efd" : "#475569"
                                        }}
                                    >
                                        {item.id === "1" ? tab1Data.length : item.id === "2" ? tab2Data.length : tab3Data.length}
                                    </Box>
                                </Box>
                            </Button>
                        );
                    })}
                </Paper>
            </Box>

            {/* --- 2. Sub-Tabs for 'TO BE ASSIGNED' (Bid = 1) --- */}
            {Bid === "1" && (
                <Box sx={{ mb: 2, borderBottom: "1px solid #e2e8f0", bgcolor: "#ffffff", borderRadius: "8px 8px 0 0", px: 2, textAlign: 'center' }}>
                    <Tabs
                        value={subTab}
                        onChange={(e, val) => setSubTab(val)}
                        textColor="primary"
                        indicatorColor="primary"
                        centered
                        sx={{
                            minHeight: 44,
                            "& .MuiTab-root": {
                                minHeight: 44,
                                fontWeight: 700,
                                fontSize: "1rem",
                                textTransform: "none",
                                px: 3,
                            }
                        }}
                    >
                        <Tab label="Workload Matrix" value="workload" />
                        {/* <Tab label="Assign to Operator" value="assign" /> */}
                        <Tab label="Scheduled POs" value="scheduled" />
                    </Tabs>
                </Box>
            )}

            {/* --- 3. Action Bar (Search & Filters) - Hides on Workload Sub-Tab --- */}
            {((Bid === "1" && subTab === "assign") || Bid === "2" || Bid === "3") && (
                <Box sx={{ mb: 2.5 }}>
                    <Paper
                        elevation={0}
                        sx={{
                            p: 2,
                            borderRadius: 2.5,
                            border: "1px solid #e2e8f0",
                            display: "flex",
                            flexWrap: "wrap",
                            gap: 2,
                            alignItems: "center",
                            justifyContent: "space-between",
                            bgcolor: "white"
                        }}
                    >
                        <TextField
                            placeholder="Search Serial No, Order No..."
                            size="small"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            sx={{ width: { xs: "100%", md: 350 } }}
                            InputProps={{
                                startAdornment: (
                                    <InputAdornment position="start">
                                        <SearchIcon color="action" />
                                    </InputAdornment>
                                ),
                                endAdornment: searchQuery && (
                                    <ClearIcon
                                        fontSize="small"
                                        onClick={() => setSearchQuery("")}
                                        style={{ cursor: "pointer" }}
                                    />
                                )
                            }}
                        />

                        {Bid === "1" ? (
                            <Stack direction="row" spacing={2} alignItems="center">
                                <FormControl size="small" sx={{ minWidth: 160 }}>
                                    <InputLabel>Category</InputLabel>
                                    <Select
                                        value={filterCategory}
                                        label="Category"
                                        onChange={(e) => setFilterCategory(e.target.value)}
                                    >
                                        {FILTER_CATEGORIES.map((cat) => (
                                            <MenuItem key={cat} value={cat}>
                                                {cat}
                                            </MenuItem>
                                        ))}
                                    </Select>
                                </FormControl>
                                <Divider orientation="vertical" flexItem />
                                {selectedIds.size > 0 && (
                                    <Chip label={`${selectedIds.size} Selected`} color="primary" size="small" />
                                )}
                                <Button
                                    variant="contained"
                                    color="primary"
                                    startIcon={<AssignmentTurnedInIcon />}
                                    disabled={selectedIds.size === 0}
                                    onClick={handleAssign}
                                    sx={{ borderRadius: 2, textTransform: "none", fontWeight: 600 }}
                                >
                                    Assign Selected
                                </Button>
                            </Stack>
                        ) : (
                            // <Chip
                            //     label={Bid === "2" ? "Monitoring Live Tasks" : "Archived Tasks"}
                            //     variant="outlined"
                            //     color={Bid === "2" ? "info" : "success"}
                            //     size="small"
                            // />

                            <Stack direction="row" spacing={1.5} alignItems="center">
                                <Chip
                                    label={Bid === "2" ? "Monitoring Live Tasks" : "Archived Tasks"}
                                    variant="outlined"
                                    color={Bid === "2" ? "info" : "success"}
                                    size="small"
                                />
                            </Stack>
                        )}
                    </Paper>
                </Box>
            )}

            {/* --- Status Messages --- */}
            {error && (
                <Alert severity="error" sx={{ mb: 2 }}>
                    {error}
                </Alert>
            )}
            {(isLoading || loadingWorkload) && (
                <Box sx={{ display: "flex", justifyContent: "center", p: 8 }}>
                    <CircularProgress size={46} thickness={4} />
                </Box>
            )}

            {/* =========================================================
            TAB 1 - SUBTAB: WORKLOAD MATRIX (ALL 3 IN SAME HORIZONTAL LANE)
            Order: 1. Machine-Process | 2. Process-Wise | 3. Operator-Wise
            ========================================================= */}
            {Bid === "1" && subTab === "workload" && !isLoading && !loadingWorkload && (
                <Box
                    sx={{
                        display: "grid",
                        gridTemplateColumns: {
                            xs: "1fr",
                            lg: "repeat(3, minmax(0, 1fr))"
                        },
                        gap: 2,
                        alignItems: "start",
                        mb: 4
                    }}
                >
                    {/* 1. FIRST COLUMN: Machine-Process Load Matrix */}
                    <Paper
                        elevation={0}
                        sx={{
                            borderRadius: 2.5,
                            border: "1px solid #e2e8f0",
                            overflow: "hidden",
                            bgcolor: "#ffffff",
                            display: "flex",
                            flexDirection: "column"
                        }}
                    >
                        <Box
                            sx={{
                                px: 1.75,
                                py: 1.4,
                                bgcolor: "#f8fafc",
                                borderBottom: "1px solid #e2e8f0",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "space-between",
                                gap: 1
                            }}
                        >
                            <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0 }}>
                                <PrecisionManufacturingIcon sx={{ color: "#0284c7", fontSize: 20, flexShrink: 0 }} />
                                <Typography
                                    variant="subtitle2"
                                    noWrap
                                    sx={{ fontWeight: 700, color: "#1e293b", fontSize: "0.9rem" }}
                                >
                                    Machine-Wise Load Matrix
                                </Typography>
                            </Stack>
                            <Chip
                                label={machineEntries.length}
                                size="small"
                                sx={{
                                    height: 22,
                                    bgcolor: "#e0f2fe",
                                    color: "#0369a1",
                                    fontWeight: 700,
                                    fontSize: "0.72rem",
                                    flexShrink: 0
                                }}
                            />
                        </Box>

                        <TableContainer sx={{ maxHeight: "65vh" }}>
                            <Table stickyHeader size="small">
                                <TableHead>
                                    <TableRow>
                                        <TableCell sx={{ width: 32, px: 0.5, bgcolor: "#f8fafc" }} />
                                        <TableCell sx={{ px: 1, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc" }}>
                                            Machine
                                        </TableCell>
                                        <TableCell
                                            align="center"
                                            sx={{ px: 1, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc", whiteSpace: "nowrap" }}
                                        >
                                            PCBs
                                        </TableCell>
                                        <TableCell
                                            align="right"
                                            sx={{ px: 1.5, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc", whiteSpace: "nowrap" }}
                                        >
                                            Est. Time
                                        </TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {machineEntries.length === 0 ? (
                                        <TableRow>
                                            <TableCell colSpan={4} align="center" sx={{ py: 4, color: "#64748b", fontSize: "0.82rem" }}>
                                                Loading...
                                            </TableCell>
                                        </TableRow>
                                    ) : (
                                        machineEntries.map(([machine, data]) => {
                                            const isExpanded = expandedMachine === machine;
                                            return (
                                                <React.Fragment key={`mach-${machine}`}>
                                                    <TableRow
                                                        hover
                                                        onClick={() => setExpandedMachine(isExpanded ? null : machine)}
                                                        sx={{
                                                            cursor: "pointer",
                                                            bgcolor: isExpanded ? "#f0f9ff" : "inherit",
                                                            "& > *": { borderBottom: isExpanded ? "none" : undefined }
                                                        }}
                                                    >
                                                        <TableCell sx={{ px: 0.5, py: 0.75, width: 32 }}>
                                                            <IconButton size="small" sx={{ p: 0.25 }}>
                                                                {isExpanded ? (
                                                                    <KeyboardArrowUpIcon fontSize="small" />
                                                                ) : (
                                                                    <KeyboardArrowDownIcon fontSize="small" />
                                                                )}
                                                            </IconButton>
                                                        </TableCell>
                                                        <TableCell
                                                            sx={{
                                                                px: 1,
                                                                py: 0.9,
                                                                fontWeight: 600,
                                                                fontSize: "0.82rem",
                                                                color: "#1e293b",
                                                                wordBreak: "break-word"
                                                            }}
                                                        >
                                                            <Stack direction="row" spacing={0.75} alignItems="center" flexWrap="wrap">
                                                                <span>{machine}</span>
                                                                <Chip
                                                                    label={
                                                                        data.processType === "batch"
                                                                            ? `Batch${data.batchCount > 0 ? ` (${data.batchCount})` : ""}`
                                                                            : "Serial"
                                                                    }
                                                                    size="small"
                                                                    sx={{
                                                                        height: 18,
                                                                        fontSize: "0.65rem",
                                                                        fontWeight: 700,
                                                                        bgcolor: data.processType === "batch" ? "#fef3c7" : "#f1f5f9",
                                                                        color: data.processType === "batch" ? "#b45309" : "#475569"
                                                                    }}
                                                                />
                                                            </Stack>
                                                        </TableCell>
                                                        <TableCell align="center" sx={{ px: 0.75, py: 0.9 }}>
                                                            <Chip
                                                                label={data.count}
                                                                size="small"
                                                                color={data.count > 0 ? "info" : "default"}
                                                                variant={data.count > 0 ? "filled" : "outlined"}
                                                                sx={{ height: 20, fontSize: "0.72rem", fontWeight: 700 }}
                                                            />
                                                        </TableCell>
                                                        <TableCell
                                                            align="right"
                                                            sx={{
                                                                px: 1.5,
                                                                py: 0.9,
                                                                fontWeight: 700,
                                                                fontSize: "0.8rem",
                                                                color: "#0f172a",
                                                                whiteSpace: "nowrap"
                                                            }}
                                                        >
                                                            {formatHours(data.totalHours)}
                                                        </TableCell>
                                                    </TableRow>
                                                    <TableRow>
                                                        <TableCell style={{ paddingBottom: 0, paddingTop: 0, paddingLeft: 8, paddingRight: 8 }} colSpan={4}>
                                                            <Collapse in={isExpanded} timeout="auto" unmountOnExit>
                                                                <Box
                                                                    sx={{
                                                                        my: 1,
                                                                        p: 1.25,
                                                                        bgcolor: "#f8fafc",
                                                                        borderRadius: 1.5,
                                                                        borderLeft: "3px solid #0284c7"
                                                                    }}
                                                                >
                                                                    <Typography
                                                                        variant="caption"
                                                                        sx={{ display: "block", mb: 0.75, fontWeight: 700, color: "#0369a1" }}
                                                                    >
                                                                        PCBs Assigned to {machine}
                                                                    </Typography>
                                                                    {data.pcbs.length === 0 ? (
                                                                        <Typography variant="caption" color="text.secondary">
                                                                            Loading...
                                                                        </Typography>
                                                                    ) : (
                                                                        <Table size="small" sx={{ bgcolor: "white", borderRadius: 1 }}>
                                                                            <TableHead>
                                                                                <TableRow>
                                                                                    <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>
                                                                                        Serial No
                                                                                    </TableCell>
                                                                                    <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>
                                                                                        Part No
                                                                                    </TableCell>
                                                                                    <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>
                                                                                        Stage
                                                                                    </TableCell>
                                                                                    <TableCell
                                                                                        align="right"
                                                                                        sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem", whiteSpace: "nowrap" }}
                                                                                    >
                                                                                        Time
                                                                                    </TableCell>
                                                                                </TableRow>
                                                                            </TableHead>
                                                                            <TableBody>
                                                                                {data.pcbs.map((p, idx) => (
                                                                                    <TableRow key={`m-det-${idx}`}>
                                                                                        <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem", fontWeight: 600 }}>
                                                                                            {p.serialNo}
                                                                                        </TableCell>
                                                                                        <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem" }}>
                                                                                            {p.partNumber}
                                                                                        </TableCell>
                                                                                        <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem" }}>
                                                                                            {p.processName}
                                                                                        </TableCell>
                                                                                        <TableCell
                                                                                            align="right"
                                                                                            sx={{ px: 1, py: 0.5, fontSize: "0.74rem", whiteSpace: "nowrap" }}
                                                                                        >
                                                                                            {formatHours(p.timeHours)}
                                                                                        </TableCell>
                                                                                    </TableRow>
                                                                                ))}
                                                                            </TableBody>
                                                                        </Table>
                                                                    )}
                                                                </Box>
                                                            </Collapse>
                                                        </TableCell>
                                                    </TableRow>
                                                </React.Fragment>
                                            );
                                        })
                                    )}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </Paper>

                    {/* 2. SECOND COLUMN: Process-Wise Load Matrix */}
                    <Paper
                        elevation={0}
                        sx={{
                            borderRadius: 2.5,
                            border: "1px solid #e2e8f0",
                            overflow: "hidden",
                            bgcolor: "#ffffff",
                            display: "flex",
                            flexDirection: "column"
                        }}
                    >
                        <Box
                            sx={{
                                px: 1.75,
                                py: 1.4,
                                bgcolor: "#f8fafc",
                                borderBottom: "1px solid #e2e8f0",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "space-between",
                                gap: 1
                            }}
                        >
                            <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0 }}>
                                <AccountTreeIcon sx={{ color: "#2563eb", fontSize: 20, flexShrink: 0 }} />
                                <Typography
                                    variant="subtitle2"
                                    noWrap
                                    sx={{ fontWeight: 700, color: "#1e293b", fontSize: "0.9rem" }}
                                >
                                    Process-Wise Load Matrix
                                </Typography>
                            </Stack>
                            <Chip
                                label={processEntries.length}
                                size="small"
                                sx={{
                                    height: 22,
                                    bgcolor: "#dbeafe",
                                    color: "#1d4ed8",
                                    fontWeight: 700,
                                    fontSize: "0.72rem",
                                    flexShrink: 0
                                }}
                            />
                        </Box>

                        <TableContainer sx={{ maxHeight: "65vh" }}>
                            <Table stickyHeader size="small">
                                <TableHead>
                                    <TableRow>
                                        <TableCell sx={{ width: 32, px: 0.5, bgcolor: "#f8fafc" }} />
                                        <TableCell sx={{ px: 1, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc" }}>
                                            Process Name
                                        </TableCell>
                                        <TableCell
                                            align="center"
                                            sx={{ px: 1, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc", whiteSpace: "nowrap" }}
                                        >
                                            PCBs
                                        </TableCell>
                                        <TableCell
                                            align="right"
                                            sx={{ px: 1.5, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc", whiteSpace: "nowrap" }}
                                        >
                                            Est. Time
                                        </TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {processEntries.length === 0 ? (
                                        <TableRow>
                                            <TableCell colSpan={4} align="center" sx={{ py: 4, color: "#64748b", fontSize: "0.82rem" }}>
                                                Loading...
                                            </TableCell>
                                        </TableRow>
                                    ) : (
                                        processEntries.map(([process, data]) => {
                                            const isExpanded = expandedProcess === process;
                                            return (
                                                <React.Fragment key={`process-${process}`}>
                                                    <TableRow
                                                        hover
                                                        onClick={() => setExpandedProcess(isExpanded ? null : process)}
                                                        sx={{
                                                            cursor: "pointer",
                                                            bgcolor: isExpanded ? "#eff6ff" : "inherit",
                                                            "& > *": { borderBottom: isExpanded ? "none" : undefined }
                                                        }}
                                                    >
                                                        <TableCell sx={{ px: 0.5, py: 0.75, width: 32 }}>
                                                            <IconButton size="small" sx={{ p: 0.25 }}>
                                                                {isExpanded ? (
                                                                    <KeyboardArrowUpIcon fontSize="small" />
                                                                ) : (
                                                                    <KeyboardArrowDownIcon fontSize="small" />
                                                                )}
                                                            </IconButton>
                                                        </TableCell>
                                                        <TableCell
                                                            sx={{
                                                                px: 1,
                                                                py: 0.9,
                                                                fontWeight: 600,
                                                                fontSize: "0.82rem",
                                                                color: "#1e293b",
                                                                wordBreak: "break-word"
                                                            }}
                                                        >
                                                            <Stack direction="row" spacing={0.75} alignItems="center" flexWrap="wrap">
                                                                <span>{process}</span>
                                                                <Chip
                                                                    label={
                                                                        data.processType === "batch"
                                                                            ? `Batch${data.batchCount > 0 ? ` (${data.batchCount})` : ""}`
                                                                            : "Serial"
                                                                    }
                                                                    size="small"
                                                                    sx={{
                                                                        height: 18,
                                                                        fontSize: "0.65rem",
                                                                        fontWeight: 700,
                                                                        bgcolor: data.processType === "batch" ? "#fef3c7" : "#f1f5f9",
                                                                        color: data.processType === "batch" ? "#b45309" : "#475569"
                                                                    }}
                                                                />
                                                            </Stack>
                                                        </TableCell>
                                                        <TableCell align="center" sx={{ px: 0.75, py: 0.9 }}>
                                                            <Chip
                                                                label={data.count}
                                                                size="small"
                                                                color="primary"
                                                                variant="outlined"
                                                                sx={{ height: 20, fontSize: "0.72rem", fontWeight: 700 }}
                                                            />
                                                        </TableCell>
                                                        <TableCell
                                                            align="right"
                                                            sx={{
                                                                px: 1.5,
                                                                py: 0.9,
                                                                fontWeight: 700,
                                                                fontSize: "0.8rem",
                                                                color: "#0f172a",
                                                                whiteSpace: "nowrap"
                                                            }}
                                                        >
                                                            {formatHours(data.totalHours)}
                                                        </TableCell>
                                                    </TableRow>
                                                    <TableRow>
                                                        <TableCell style={{ paddingBottom: 0, paddingTop: 0, paddingLeft: 8, paddingRight: 8 }} colSpan={4}>
                                                            <Collapse in={isExpanded} timeout="auto" unmountOnExit>
                                                                <Box
                                                                    sx={{
                                                                        my: 1,
                                                                        p: 1.25,
                                                                        bgcolor: "#f8fafc",
                                                                        borderRadius: 1.5,
                                                                        borderLeft: "3px solid #2563eb"
                                                                    }}
                                                                >
                                                                    <Typography
                                                                        variant="caption"
                                                                        sx={{ display: "block", mb: 0.75, fontWeight: 700, color: "#1d4ed8" }}
                                                                    >
                                                                        Assigned PCBs in {process}
                                                                    </Typography>
                                                                    <Table size="small" sx={{ bgcolor: "white", borderRadius: 1 }}>
                                                                        <TableHead>
                                                                            <TableRow>
                                                                                <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>
                                                                                    Serial No
                                                                                </TableCell>
                                                                                <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>
                                                                                    Part No
                                                                                </TableCell>
                                                                                <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>
                                                                                    Operator
                                                                                </TableCell>
                                                                                <TableCell
                                                                                    align="right"
                                                                                    sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem", whiteSpace: "nowrap" }}
                                                                                >
                                                                                    Time
                                                                                </TableCell>
                                                                            </TableRow>
                                                                        </TableHead>
                                                                        <TableBody>
                                                                            {data.pcbs.map((p, idx) => (
                                                                                <TableRow key={`p-det-${idx}`}>
                                                                                    <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem", fontWeight: 600 }}>
                                                                                        {p.serialNo}
                                                                                    </TableCell>
                                                                                    <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem" }}>
                                                                                        {p.partNumber}
                                                                                    </TableCell>
                                                                                    <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem" }}>
                                                                                        {p.operatorName}
                                                                                    </TableCell>
                                                                                    <TableCell
                                                                                        align="right"
                                                                                        sx={{ px: 1, py: 0.5, fontSize: "0.74rem", whiteSpace: "nowrap" }}
                                                                                    >
                                                                                        {formatHours(p.timeHours)}
                                                                                    </TableCell>
                                                                                </TableRow>
                                                                            ))}
                                                                        </TableBody>
                                                                    </Table>
                                                                </Box>
                                                            </Collapse>
                                                        </TableCell>
                                                    </TableRow>
                                                </React.Fragment>
                                            );
                                        })
                                    )}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </Paper>

                    {/* 3. THIRD COLUMN: Operator-Wise Load Matrix */}
                    <Paper
                        elevation={0}
                        sx={{
                            borderRadius: 2.5,
                            border: "1px solid #e2e8f0",
                            overflow: "hidden",
                            bgcolor: "#ffffff",
                            display: "flex",
                            flexDirection: "column"
                        }}
                    >
                        <Box
                            sx={{
                                px: 1.75,
                                py: 1.4,
                                bgcolor: "#f8fafc",
                                borderBottom: "1px solid #e2e8f0",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "space-between",
                                gap: 1
                            }}
                        >
                            <Stack direction="row" spacing={1} alignItems="center" sx={{ minWidth: 0 }}>
                                <EngineeringIcon sx={{ color: "#7c3aed", fontSize: 20, flexShrink: 0 }} />
                                <Typography
                                    variant="subtitle2"
                                    noWrap
                                    sx={{ fontWeight: 700, color: "#1e293b", fontSize: "0.9rem" }}
                                >
                                    Operator-Wise Load Matrix
                                </Typography>
                            </Stack>
                            <Chip
                                label={operatorEntries.length}
                                size="small"
                                sx={{
                                    height: 22,
                                    bgcolor: "#ede9fe",
                                    color: "#6d28d9",
                                    fontWeight: 700,
                                    fontSize: "0.72rem",
                                    flexShrink: 0
                                }}
                            />
                        </Box>

                        <TableContainer sx={{ maxHeight: "65vh" }}>
                            <Table stickyHeader size="small">
                                <TableHead>
                                    <TableRow>
                                        <TableCell sx={{ width: 32, px: 0.5, bgcolor: "#f8fafc" }} />
                                        <TableCell sx={{ px: 1, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc" }}>
                                            Operator
                                        </TableCell>
                                        <TableCell
                                            align="center"
                                            sx={{ px: 1, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc", whiteSpace: "nowrap" }}
                                        >
                                            Tasks
                                        </TableCell>
                                        <TableCell
                                            align="right"
                                            sx={{ px: 1.5, py: 1, fontWeight: 700, fontSize: "0.78rem", color: "#475569", bgcolor: "#f8fafc", whiteSpace: "nowrap" }}
                                        >
                                            Est. Time
                                        </TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {operatorEntries.length === 0 ? (
                                        <TableRow>
                                            <TableCell colSpan={4} align="center" sx={{ py: 4, color: "#64748b", fontSize: "0.82rem" }}>
                                                Loading...
                                            </TableCell>
                                        </TableRow>
                                    ) : (
                                        operatorEntries.map(([operator, data]) => {
                                            const isExpanded = expandedOperator === operator;
                                            return (
                                                <React.Fragment key={`op-${operator}`}>
                                                    <TableRow
                                                        hover
                                                        onClick={() => setExpandedOperator(isExpanded ? null : operator)}
                                                        sx={{
                                                            cursor: "pointer",
                                                            bgcolor: isExpanded ? "#f5f3ff" : "inherit",
                                                            "& > *": { borderBottom: isExpanded ? "none" : undefined }
                                                        }}
                                                    >
                                                        <TableCell sx={{ px: 0.5, py: 0.75, width: 32 }}>
                                                            <IconButton size="small" sx={{ p: 0.25 }}>
                                                                {isExpanded ? (
                                                                    <KeyboardArrowUpIcon fontSize="small" />
                                                                ) : (
                                                                    <KeyboardArrowDownIcon fontSize="small" />
                                                                )}
                                                            </IconButton>
                                                        </TableCell>
                                                        <TableCell
                                                            sx={{
                                                                px: 1,
                                                                py: 0.9,
                                                                fontWeight: 600,
                                                                fontSize: "0.82rem",
                                                                color: "#1e293b",
                                                                wordBreak: "break-word"
                                                            }}
                                                        >
                                                            {operator}
                                                        </TableCell>
                                                        <TableCell align="center" sx={{ px: 0.75, py: 0.9 }}>
                                                            <Chip
                                                                label={data.count}
                                                                size="small"
                                                                color="secondary"
                                                                variant="outlined"
                                                                sx={{ height: 20, fontSize: "0.72rem", fontWeight: 700 }}
                                                            />
                                                        </TableCell>
                                                        <TableCell
                                                            align="right"
                                                            sx={{
                                                                px: 1.5,
                                                                py: 0.9,
                                                                fontWeight: 700,
                                                                fontSize: "0.8rem",
                                                                color: "#0f172a",
                                                                whiteSpace: "nowrap"
                                                            }}
                                                        >
                                                            {formatHours(data.totalHours)}
                                                        </TableCell>
                                                    </TableRow>
                                                    <TableRow>
                                                        <TableCell style={{ paddingBottom: 0, paddingTop: 0, paddingLeft: 8, paddingRight: 8 }} colSpan={4}>
                                                            <Collapse in={isExpanded} timeout="auto" unmountOnExit>
                                                                <Box
                                                                    sx={{
                                                                        my: 1,
                                                                        p: 1.25,
                                                                        bgcolor: "#f8fafc",
                                                                        borderRadius: 1.5,
                                                                        borderLeft: "3px solid #7c3aed"
                                                                    }}
                                                                >
                                                                    <Typography
                                                                        variant="caption"
                                                                        sx={{ display: "block", mb: 0.75, fontWeight: 700, color: "#6d28d9" }}
                                                                    >
                                                                        Assigned Stages for {operator}
                                                                    </Typography>
                                                                    {Object.entries(data.pcbsByProcess).map(
                                                                        ([procName, pcbsInProc], procIdx) => (
                                                                            <Box key={`proc-group-${procIdx}`} sx={{ mb: 1.25, mt: 0.5 }}>
                                                                                <Stack direction="row" spacing={1} sx={{ mb: 0.75 }}>
                                                                                    <Chip
                                                                                        label={`Stage: ${procName}`}
                                                                                        size="small"
                                                                                        sx={{
                                                                                            height: 20,
                                                                                            fontSize: "0.7rem",
                                                                                            fontWeight: 700,
                                                                                            bgcolor: "#e2e8f0",
                                                                                            color: "#1e293b"
                                                                                        }}
                                                                                    />
                                                                                    {data.processStats && data.processStats[procName] && (
                                                                                        <Chip
                                                                                            label={
                                                                                                data.processStats[procName].processType === "batch"
                                                                                                    ? `Batch${data.processStats[procName].batchCount > 0 ? ` (${data.processStats[procName].batchCount})` : ""}`
                                                                                                    : "Serial"
                                                                                            }
                                                                                            size="small"
                                                                                            sx={{
                                                                                                height: 20,
                                                                                                fontSize: "0.65rem",
                                                                                                fontWeight: 700,
                                                                                                bgcolor: data.processStats[procName].processType === "batch" ? "#fef3c7" : "#f1f5f9",
                                                                                                color: data.processStats[procName].processType === "batch" ? "#b45309" : "#475569"
                                                                                            }}
                                                                                        />
                                                                                    )}
                                                                                </Stack>

                                                                                <Table size="small" sx={{ bgcolor: "white", borderRadius: 1 }}>
                                                                                    <TableHead>
                                                                                        <TableRow>
                                                                                            <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>
                                                                                                Serial No
                                                                                            </TableCell>
                                                                                            <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>
                                                                                                Part No
                                                                                            </TableCell>
                                                                                            <TableCell
                                                                                                align="right"
                                                                                                sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem", whiteSpace: "nowrap" }}
                                                                                            >
                                                                                                Time
                                                                                            </TableCell>
                                                                                        </TableRow>
                                                                                    </TableHead>
                                                                                    <TableBody>
                                                                                        {pcbsInProc.map((p, idx) => (
                                                                                            <TableRow key={`o-det-${procIdx}-${idx}`}>
                                                                                                <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem", fontWeight: 600 }}>
                                                                                                    {p.serialNo}
                                                                                                </TableCell>
                                                                                                <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem" }}>
                                                                                                    {p.partNumber}
                                                                                                </TableCell>
                                                                                                <TableCell
                                                                                                    align="right"
                                                                                                    sx={{ px: 1, py: 0.5, fontSize: "0.74rem", whiteSpace: "nowrap" }}
                                                                                                >
                                                                                                    {formatHours(p.timeHours)}
                                                                                                </TableCell>
                                                                                            </TableRow>
                                                                                        ))}
                                                                                    </TableBody>
                                                                                </Table>
                                                                            </Box>
                                                                        )
                                                                    )}
                                                                </Box>
                                                            </Collapse>
                                                        </TableCell>
                                                    </TableRow>
                                                </React.Fragment>
                                            );
                                        })
                                    )}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </Paper>
                </Box>
            )}

            {/* =========================================================
            TAB 1 - SUBTAB: ASSIGN TO OPERATOR
            ========================================================= */}
            {/* {Bid === "1" && subTab === "assign" && !isLoading && (
                <Box>
                    <Paper
                        sx={{
                            width: "100%",
                            overflow: "hidden",
                            borderRadius: 2.5,
                            border: "1px solid #e2e8f0",
                            boxShadow: "none"
                        }}
                    >
                        <TableContainer sx={{ maxHeight: "60vh" }}>
                            <Table stickyHeader size="medium">
                                <TableHead>
                                    <TableRow>
                                        <TableCell padding="checkbox" sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
                                            <Checkbox
                                                color="primary"
                                                indeterminate={isIndeterminate}
                                                checked={isAllSelected}
                                                onChange={handleSelectAll}
                                                disabled={tab1Data.length === 0}
                                            />
                                        </TableCell>

                                        {dynamicColumns.map((col) => (
                                            <TableCell
                                                key={col}
                                                sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem", whiteSpace: "nowrap" }}
                                            >
                                                {formatHeader(col)}
                                            </TableCell>
                                        ))}
                                        <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>Category</TableCell>
                                        <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>Status</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {console.log("tab1: ",tab1Data)}
                                    {tab1Data.length === 0 ? (
                                        <TableRow>
                                            <TableCell colSpan={100} align="center" sx={{ py: 6, color: "black" }}>
                                                Loading...
                                            </TableCell>
                                        </TableRow>
                                    ) : (
                                        tab1Data.map((pcb, i) => {
                                            const uniqueId = getPcbId(pcb, i);
                                            const isSelected = selectedIds.has(uniqueId);
                                            return (
                                                <TableRow
                                                    hover
                                                    key={uniqueId}
                                                    selected={isSelected}
                                                    onClick={() => toggleSelect(uniqueId)}
                                                    sx={{ cursor: "pointer", "&.Mui-selected": { bgcolor: "#eff6ff" } }}
                                                >
                                                    <TableCell padding="checkbox" sx={{ opacity: 0.8, fontWeight: 600 }}>
                                                        <Checkbox
                                                            color="primary"
                                                            checked={isSelected}
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                toggleSelect(uniqueId);
                                                            }}
                                                        />
                                                    </TableCell>
                                                    {dynamicColumns.map((col) => (
                                                        <TableCell key={col} sx={{ opacity: 0.8, fontWeight: 600 }}>
                                                            {pcb[col]}
                                                        </TableCell>
                                                    ))}
                                                    <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>
                                                        <Chip
                                                            label={pcb.Type || "UNKNOWN"}
                                                            size="small"
                                                            sx={{ bgcolor: "#f1f5f9", fontWeight: 600 }}
                                                        />
                                                    </TableCell>
                                                    <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>
                                                        <Chip
                                                            label="Ready To Assign"
                                                            size="small"
                                                            color="warning"
                                                            sx={{ fontWeight: 600, bgcolor: "#fff7ed", color: "#c2410c" }}
                                                        />
                                                    </TableCell>
                                                </TableRow>
                                            );
                                        })
                                    )}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </Paper>
                </Box>
            )} */}

            {/* =========================================================
            TAB 2 & 3: ASSIGNED & COMPLETED (Read-Only Views)
            ========================================================= */}
            {(Bid === "2" || Bid === "3") && !isLoading && (
                <Box>
                    <Paper
                        sx={{
                            width: "100%",
                            overflow: "hidden",
                            borderRadius: 2.5,
                            border: "1px solid #e2e8f0",
                            boxShadow: "none"
                        }}
                    >
                        <TableContainer sx={{ maxHeight: "65vh" }}>
                            {/* <Table stickyHeader>
                                {Bid === "3" ? (
                                    <TableHead>
                                        <TableRow>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
                                                Serial No
                                            </TableCell>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
                                                Part Number
                                            </TableCell>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
                                                PCB Type
                                            </TableCell>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
                                                Overall Status
                                            </TableCell>
                                        </TableRow>
                                    </TableHead>
                                ) : (
                                    <TableHead>
                                        <TableRow>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
                                                Part Number
                                            </TableCell>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
                                                Serial No
                                            </TableCell>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
                                                Current Stage
                                            </TableCell>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
                                                Operator
                                            </TableCell>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
                                                Current Stage ID
                                            </TableCell>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
                                                Step Status
                                            </TableCell>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>
                                                Overall Status
                                            </TableCell>
                                        </TableRow>
                                    </TableHead>
                                )}
                                <TableBody>
                                    {Bid === "2" ? (
                                        tab2Data.length === 0 ? (
                                            <TableRow>
                                                <TableCell colSpan={7} align="center" sx={{ opacity: 0.8, fontWeight: 600 }}>
                                                    Loading...
                                                </TableCell>
                                            </TableRow>
                                        ) : (
                                            tab2Data.map((row, index) => (
                                                <TableRow key={index} hover>
                                                    <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>{row.partNumber}</TableCell>
                                                    <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>{row.serialNo}</TableCell>
                                                    <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>
                                                        <Typography sx={{ opacity: 0.8, fontWeight: 600 }}>
                                                            {row.currentProcessName}
                                                        </Typography>
                                                    </TableCell>
                                                    <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>
                                                        <Stack direction="row" alignItems="center" spacing={1}>
                                                            <PersonIcon fontSize="small" sx={{ opacity: 0.8, fontWeight: 600 }} />
                                                            <Box>
                                                                {row.currentProcessOpeName ? (
                                                                    <Typography sx={{ opacity: 0.8, fontWeight: 600 }}>
                                                                        {Array.isArray(row.currentProcessOpeName)
                                                                            ? row.currentProcessOpeName.join(", ")
                                                                            : String(row.currentProcessOpeName).replace(/ , $/g, "")}
                                                                    </Typography>
                                                                ) : (
                                                                    <Typography sx={{ opacity: 0.8, fontWeight: 600 }}>
                                                                        Unassigned
                                                                    </Typography>
                                                                )}
                                                                {row.currentProcessOpeStaffno && (
                                                                    <Typography sx={{ opacity: 0.8, fontWeight: 600 }}>
                                                                        ID:{" "}
                                                                        {Array.isArray(row.currentProcessOpeStaffno)
                                                                            ? row.currentProcessOpeStaffno.join(", ")
                                                                            : String(row.currentProcessOpeStaffno).replace(/ , $/g, "")}
                                                                    </Typography>
                                                                )}
                                                            </Box>
                                                        </Stack>
                                                    </TableCell>
                                                    <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>
                                                        <Typography sx={{ opacity: 0.8, fontWeight: 600 }}>
                                                            Stage: {row.currentStepOrder}
                                                        </Typography>
                                                    </TableCell>
                                                    <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>
                                                        <Chip
                                                            label={row.currentProcessstatus || "Pending"}
                                                            size="small"
                                                            sx={{
                                                                bgcolor:
                                                                    row.currentProcessstatus === "Start" ? "#dbeafe" : "#f1f5f9",
                                                                color:
                                                                    row.currentProcessstatus === "Start" ? "#1e40af" : "#475569",
                                                                fontWeight: 600
                                                            }}
                                                        />
                                                    </TableCell>
                                                    <TableCell>
                                                        <Chip
                                                            label={row.Overall_PCB_status}
                                                            size="small"
                                                            color={row.Overall_PCB_status === "Completed" ? "success" : "default"}
                                                            variant={row.Overall_PCB_status === "Completed" ? "filled" : "outlined"}
                                                            sx={{ fontWeight: 600 }}
                                                        />
                                                    </TableCell>
                                                </TableRow>
                                            ))
                                        )
                                    ) : tab3Data.length === 0 ? (
                                        <TableRow>
                                            <TableCell colSpan={7} align="center" sx={{ opacity: 0.8, fontWeight: 600 }}>
                                                No Completed PCBs found.
                                            </TableCell>
                                        </TableRow>
                                    ) : (
                                        tab3Data.map((row, index) => (
                                            <TableRow key={index} hover>
                                                <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>{row.serialNo}</TableCell>
                                                <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>{row.partNumber}</TableCell>
                                                <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>
                                                    <Chip
                                                        label={row.Type || "Pending"}
                                                        size="small"
                                                        sx={{
                                                            bgcolor: row.currentProcessstatus === "Start" ? "#dbeafe" : "#f1f5f9",
                                                            color: row.currentProcessstatus === "Start" ? "#1e40af" : "#475569",
                                                            fontWeight: 600
                                                        }}
                                                    />
                                                </TableCell>
                                                <TableCell>
                                                    <Chip
                                                        label={row.Overall_PCB_status}
                                                        size="small"
                                                        color={row.Overall_PCB_status === "Completed" ? "success" : "default"}
                                                        variant={row.Overall_PCB_status === "Completed" ? "filled" : "outlined"}
                                                        sx={{ fontWeight: 600 }}
                                                    />
                                                </TableCell>
                                            </TableRow>
                                        ))
                                    )}
                                </TableBody>
                            </Table> */}


                            <Table stickyHeader>
                                {Bid === "3" ? (
                                    <TableHead>
                                        <TableRow>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>Serial No</TableCell>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>Part Number</TableCell>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>PCB Type</TableCell>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>Overall Status</TableCell>
                                        </TableRow>
                                    </TableHead>
                                ) : (
                                    <TableHead>
                                        <TableRow>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", width: 36, px: 0.5 }} />
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>Production Order</TableCell>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem" }}>Part Number</TableCell>
                                            <TableCell sx={{ bgcolor: "#f8f9fa", fontWeight: "bold", fontSize: "1rem", textAlign: "right" }}>Assigned Qty</TableCell>
                                        </TableRow>
                                    </TableHead>
                                )}
                                <TableBody>
                                    {Bid === "2" ? (
                                        assignedPosGrouped.length === 0 ? (
                                            <TableRow>
                                                <TableCell colSpan={4} align="center" sx={{ opacity: 0.8, fontWeight: 600, py: 4 }}>
                                                    No Live Assigned PCBs found.
                                                </TableCell>
                                            </TableRow>
                                        ) : (
                                            assignedPosGrouped.map((group, index) => {
                                                const isOpen = expandedAssignedPo === group.po;
                                                return (
                                                    <React.Fragment key={group.po || index}>
                                                        <TableRow hover onClick={() => setExpandedAssignedPo(isOpen ? null : group.po)} sx={{ cursor: "pointer", "&.Mui-selected": { bgcolor: "#eff6ff" } }}>
                                                            <TableCell sx={{ px: 0.5 }}>
                                                                <IconButton size="small" onClick={(e) => { e.stopPropagation(); setExpandedAssignedPo(isOpen ? null : group.po); }}>
                                                                    {isOpen ? <KeyboardArrowUpIcon fontSize="small" /> : <KeyboardArrowDownIcon fontSize="small" />}
                                                                </IconButton>
                                                            </TableCell>
                                                            <TableCell sx={{ fontWeight: 700 }}>{group.po === "UNKNOWN_PO" ? "No PO assigned" : group.po}</TableCell>
                                                            <TableCell sx={{ fontWeight: 600, color: "#475569" }}>{group.partNumber}</TableCell>
                                                            <TableCell align="right" sx={{ fontWeight: 700 }}>{group.pcbs.length}</TableCell>
                                                        </TableRow>
                                                        <TableRow>
                                                            <TableCell colSpan={4} sx={{ py: 0, px: 1, borderBottom: isOpen ? undefined : "none" }}>
                                                                <Collapse in={isOpen} timeout="auto" unmountOnExit>
                                                                    <Box sx={{ m: 1, p: 1.5, bgcolor: "#f8fafc", borderRadius: 2, border: "1px solid #e2e8f0" }}>
                                                                        <Typography variant="caption" sx={{ display: "block", mb: 0.75, fontWeight: 700, color: "#475569" }}>
                                                                            PCBs in Progress for {group.po === "UNKNOWN_PO" ? "this group" : `PO ${group.po}`}
                                                                        </Typography>
                                                                        <Table size="small" sx={{ bgcolor: "white", borderRadius: 1 }}>
                                                                            <TableHead>
                                                                                <TableRow>
                                                                                    <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>Serial No</TableCell>
                                                                                    <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>Current Stage</TableCell>
                                                                                    <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>Operator</TableCell>
                                                                                    <TableCell sx={{ px: 1, py: 0.5, fontWeight: 700, fontSize: "0.72rem" }}>Status</TableCell>
                                                                                </TableRow>
                                                                            </TableHead>
                                                                            <TableBody>
                                                                                {group.pcbs.map((row, idx) => (
                                                                                    <TableRow key={idx} hover>
                                                                                        <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem", fontWeight: 600 }}>{row.serialNo}</TableCell>
                                                                                        <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem" }}>
                                                                                            {row.currentProcessName} <span style={{color: "#64748b"}}>(Stage: {row.currentStepOrder})</span>
                                                                                        </TableCell>
                                                                                        <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem" }}>
                                                                                            <Stack direction="row" alignItems="center" spacing={0.75}>
                                                                                                <PersonIcon fontSize="small" sx={{ opacity: 0.7 }} />
                                                                                                <Box>
                                                                                                    {row.currentProcessOpeName ? (
                                                                                                        Array.isArray(row.currentProcessOpeName)
                                                                                                            ? row.currentProcessOpeName.join(", ")
                                                                                                            : String(row.currentProcessOpeName).replace(/ , $/g, "")
                                                                                                    ) : "Unassigned"}
                                                                                                </Box>
                                                                                            </Stack>
                                                                                        </TableCell>
                                                                                        <TableCell sx={{ px: 1, py: 0.5, fontSize: "0.74rem" }}>
                                                                                            <Chip
                                                                                                label={row.currentProcessstatus || "Pending"}
                                                                                                size="small"
                                                                                                sx={{
                                                                                                    height: 20,
                                                                                                    fontSize: "0.65rem",
                                                                                                    bgcolor: row.currentProcessstatus === "Start" ? "#dbeafe" : "#f1f5f9",
                                                                                                    color: row.currentProcessstatus === "Start" ? "#1e40af" : "#475569",
                                                                                                    fontWeight: 600
                                                                                                }}
                                                                                            />
                                                                                        </TableCell>
                                                                                    </TableRow>
                                                                                ))}
                                                                            </TableBody>
                                                                        </Table>
                                                                    </Box>
                                                                </Collapse>
                                                            </TableCell>
                                                        </TableRow>
                                                    </React.Fragment>
                                                );
                                            })
                                        )
                                    ) : tab3Data.length === 0 ? (
                                        <TableRow>
                                            <TableCell colSpan={4} align="center" sx={{ opacity: 0.8, fontWeight: 600, py: 4 }}>
                                                No Completed PCBs found.
                                            </TableCell>
                                        </TableRow>
                                    ) : (
                                        tab3Data.map((row, index) => (
                                            <TableRow key={index} hover>
                                                <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>{row.serialNo}</TableCell>
                                                <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>{row.partNumber}</TableCell>
                                                <TableCell sx={{ opacity: 0.8, fontWeight: 600 }}>
                                                    <Chip
                                                        label={row.Type || "Pending"}
                                                        size="small"
                                                        sx={{
                                                            bgcolor: row.currentProcessstatus === "Start" ? "#dbeafe" : "#f1f5f9",
                                                            color: row.currentProcessstatus === "Start" ? "#1e40af" : "#475569",
                                                            fontWeight: 600
                                                        }}
                                                    />
                                                </TableCell>
                                                <TableCell>
                                                    <Chip
                                                        label={row.Overall_PCB_status}
                                                        size="small"
                                                        color={row.Overall_PCB_status === "Completed" ? "success" : "default"}
                                                        variant={row.Overall_PCB_status === "Completed" ? "filled" : "outlined"}
                                                        sx={{ fontWeight: 600 }}
                                                    />
                                                </TableCell>
                                            </TableRow>
                                        ))
                                    )}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </Paper>
                </Box>
            )}

            {/* TAB 1 - SUBTAB: SCHEDULED POs (self-contained; stays mounted so its filters survive tab switches) */}
            {/* <ScheduledPOsTab
                active={Bid === "1" && subTab === "scheduled"}
                busy={isLoading}
                dbPCBs={dbPCBs}
                getPcbId={getPcbId}
                apiBase={ScheduleServer}
                assignUrl={PythonServer}
                onAssigned={() => { fetchInactionPCBs(); fetchAssignedPCBs(); }}
                notify={(msg, type) => setSnackbar({ open: true, msg, type })}
                // onViewFull={() => setGanttOpen(true)}
                onViewFull={(currentPlanId) => {
                    setSelectedPlanForGantt(currentPlanId);
                    setGanttOpen(true);
                }}
            /> */}

            <ScheduledPOsTab
                active={Bid === "1" && subTab === "scheduled"}
                busy={isLoading}
                dbPCBs={dbPCBs}
                assignedPCBs={assignedPCBs}
                getPcbId={getPcbId}
                apiBase={ScheduleServer}
                assignUrl={PythonServer}
                onAssigned={() => { fetchInactionPCBs(); fetchAssignedPCBs(); }}
                notify={(msg, type) => setSnackbar({ open: true, msg, type })}
                onViewFull={(currentPlanId) => {
                    setSelectedPlanForGantt(currentPlanId);
                    setGanttOpen(true);
                }}
            />

            <ScheduleGanttView
                open={ganttOpen}
                onClose={() => setGanttOpen(false)}
                apiBase={ScheduleServer}
                initialPlanId={selectedPlanForGantt}
                authHeaders={() => ({ "x-access-token": localStorage.getItem("token") || "" })}
            />

            <Snackbar
                open={snackbar.open}
                autoHideDuration={4000}
                onClose={() => setSnackbar({ ...snackbar, open: false })}
                anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
            >
                <Alert
                    variant="filled"
                    onClose={() => setSnackbar({ ...snackbar, open: false })}
                    severity={snackbar.type}
                    sx={{ width: "100%", borderRadius: 2 }}
                >
                    {snackbar.msg}
                </Alert>
            </Snackbar>
        </Box>
    );
}

export default AssignPCB;
