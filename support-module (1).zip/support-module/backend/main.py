"""Support ticket module - FastAPI backend.
Run:  uvicorn main:app --reload
Docs: http://localhost:8000/docs
"""
import hashlib
import hmac
import os
import secrets
import uuid
from datetime import datetime, timedelta
from typing import List, Optional

import jwt
from fastapi import (Depends, FastAPI, File, Form, HTTPException, Query,
                     UploadFile)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from sqlalchemy import (Boolean, Column, DateTime, ForeignKey, Integer, String,
                        Text, create_engine, or_)
from sqlalchemy.orm import (Session, declarative_base, relationship,
                            sessionmaker)

# ---------------------------------------------------------------- config
SECRET_KEY = os.getenv("SECRET_KEY", "change-me-in-production")
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./support.db")
UPLOAD_DIR = os.getenv("UPLOAD_DIR", "uploads")
CORS_ORIGINS = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")
MAX_FILE_MB = 5
ALLOWED_EXT = {".png", ".jpg", ".jpeg", ".gif", ".pdf", ".txt", ".log", ".docx", ".xlsx", ".csv"}

STATUSES = ["open", "in_progress", "resolved", "closed"]
PRIORITIES = ["low", "medium", "high", "urgent"]
CATEGORIES = ["bug", "access", "data", "performance", "question", "other"]

os.makedirs(UPLOAD_DIR, exist_ok=True)

# -------------------------------------------------------------- database
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {},
)
SessionLocal = sessionmaker(bind=engine, autoflush=False)
Base = declarative_base()


def now():
    return datetime.utcnow()


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    email = Column(String(200), unique=True, index=True, nullable=False)
    password_hash = Column(String(200), nullable=False)
    role = Column(String(20), default="user")  # user | agent


class Ticket(Base):
    __tablename__ = "tickets"
    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    description = Column(Text, nullable=False)
    category = Column(String(30), default="other")
    priority = Column(String(20), default="medium")
    status = Column(String(20), default="open", index=True)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    assigned_to = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=now)
    updated_at = Column(DateTime, default=now, onupdate=now)
    resolved_at = Column(DateTime, nullable=True)

    owner = relationship("User", foreign_keys=[owner_id])
    assignee = relationship("User", foreign_keys=[assigned_to])
    comments = relationship("Comment", order_by="Comment.created_at",
                            cascade="all, delete-orphan")
    attachments = relationship("Attachment", cascade="all, delete-orphan")


class Comment(Base):
    __tablename__ = "ticket_comments"
    id = Column(Integer, primary_key=True)
    ticket_id = Column(Integer, ForeignKey("tickets.id"), nullable=False)
    author_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    message = Column(Text, nullable=False)
    is_internal = Column(Boolean, default=False)  # visible to agents only
    created_at = Column(DateTime, default=now)
    author = relationship("User")


class Attachment(Base):
    __tablename__ = "ticket_attachments"
    id = Column(Integer, primary_key=True)
    ticket_id = Column(Integer, ForeignKey("tickets.id"), nullable=False)
    filename = Column(String(255))
    stored_name = Column(String(255))


class Notification(Base):
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True)
    ticket_id = Column(Integer, ForeignKey("tickets.id"))
    message = Column(String(300))
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=now)


Base.metadata.create_all(engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ------------------------------------------------------------------ auth
def hash_password(pw: str) -> str:
    salt = secrets.token_hex(8)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 100_000).hex()
    return f"{salt}${h}"


def verify_password(pw: str, stored: str) -> bool:
    salt, h = stored.split("$")
    check = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 100_000).hex()
    return hmac.compare_digest(h, check)


def make_token(user: User) -> str:
    payload = {"sub": str(user.id), "exp": now() + timedelta(days=7)}
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")


bearer = HTTPBearer(auto_error=False)


def current_user(creds: HTTPAuthorizationCredentials = Depends(bearer),
                 db: Session = Depends(get_db)) -> User:
    if not creds:
        raise HTTPException(401, "Not logged in")
    try:
        uid = int(jwt.decode(creds.credentials, SECRET_KEY, algorithms=["HS256"])["sub"])
    except Exception:
        raise HTTPException(401, "Session expired. Please log in again.")
    user = db.get(User, uid)
    if not user:
        raise HTTPException(401, "User not found")
    return user


def agent_only(user: User = Depends(current_user)) -> User:
    if user.role != "agent":
        raise HTTPException(403, "Support team only")
    return user


# --------------------------------------------------------------- schemas
class RegisterIn(BaseModel):
    name: str
    email: str
    password: str


class LoginIn(BaseModel):
    email: str
    password: str


class TicketUpdate(BaseModel):
    status: Optional[str] = None
    priority: Optional[str] = None
    assigned_to: Optional[int] = None


class CommentIn(BaseModel):
    message: str
    is_internal: bool = False


def user_out(u: User):
    return {"id": u.id, "name": u.name, "email": u.email, "role": u.role}


def short(u: Optional[User]):
    return {"id": u.id, "name": u.name} if u else None


def iso(d):
    return d.isoformat() + "Z" if d else None


def ticket_out(t: Ticket, viewer: User, detail: bool = False):
    d = {
        "id": t.id, "title": t.title, "description": t.description,
        "category": t.category, "priority": t.priority, "status": t.status,
        "owner": short(t.owner), "assignee": short(t.assignee),
        "created_at": iso(t.created_at), "updated_at": iso(t.updated_at),
        "resolved_at": iso(t.resolved_at),
    }
    if detail:
        is_agent = viewer.role == "agent"
        d["attachments"] = [{"id": a.id, "filename": a.filename, "stored_name": a.stored_name}
                            for a in t.attachments]
        d["comments"] = [
            {"id": c.id, "message": c.message, "is_internal": c.is_internal,
             "created_at": iso(c.created_at),
             "author": {"id": c.author.id, "name": c.author.name, "role": c.author.role}}
            for c in t.comments if is_agent or not c.is_internal
        ]
    return d


def notify(db: Session, user_id: int, ticket: Ticket, message: str):
    db.add(Notification(user_id=user_id, ticket_id=ticket.id, message=message))


def get_ticket_or_404(db: Session, tid: int, user: User) -> Ticket:
    t = db.get(Ticket, tid)
    if not t or (user.role != "agent" and t.owner_id != user.id):
        raise HTTPException(404, "Ticket not found")
    return t


# ------------------------------------------------------------------- app
app = FastAPI(title="Support Module")
app.add_middleware(CORSMiddleware, allow_origins=CORS_ORIGINS,
                   allow_methods=["*"], allow_headers=["*"])
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")


@app.on_event("startup")
def seed_agent():
    """Creates a default support agent on first run. CHANGE THE PASSWORD."""
    db = SessionLocal()
    if not db.query(User).filter_by(role="agent").first():
        db.add(User(name="Support Agent", email="agent@example.com",
                    password_hash=hash_password("agent123"), role="agent"))
        db.commit()
    db.close()


@app.get("/meta")
def meta():
    return {"statuses": STATUSES, "priorities": PRIORITIES, "categories": CATEGORIES}


# ------------------------------------------------------------------ auth
@app.post("/auth/register")
def register(data: RegisterIn, db: Session = Depends(get_db)):
    email = data.email.strip().lower()
    if len(data.password) < 6:
        raise HTTPException(400, "Password must be at least 6 characters")
    if db.query(User).filter_by(email=email).first():
        raise HTTPException(400, "This email is already registered")
    u = User(name=data.name.strip(), email=email, password_hash=hash_password(data.password))
    db.add(u)
    db.commit()
    return {"token": make_token(u), "user": user_out(u)}


@app.post("/auth/login")
def login(data: LoginIn, db: Session = Depends(get_db)):
    u = db.query(User).filter_by(email=data.email.strip().lower()).first()
    if not u or not verify_password(data.password, u.password_hash):
        raise HTTPException(401, "Wrong email or password")
    return {"token": make_token(u), "user": user_out(u)}


@app.get("/auth/me")
def me(user: User = Depends(current_user)):
    return user_out(user)


@app.get("/agents")
def agents(db: Session = Depends(get_db), _: User = Depends(agent_only)):
    return [short(u) for u in db.query(User).filter_by(role="agent").all()]


# --------------------------------------------------------------- tickets
@app.post("/tickets")
async def create_ticket(
    title: str = Form(...), description: str = Form(...),
    category: str = Form("other"), priority: str = Form("medium"),
    files: List[UploadFile] = File(default=[]),
    db: Session = Depends(get_db), user: User = Depends(current_user),
):
    if category not in CATEGORIES or priority not in PRIORITIES:
        raise HTTPException(400, "Invalid category or priority")
    t = Ticket(title=title.strip(), description=description.strip(),
               category=category, priority=priority, owner_id=user.id)
    db.add(t)
    db.flush()
    for f in files:
        if not f.filename:
            continue
        ext = os.path.splitext(f.filename)[1].lower()
        if ext not in ALLOWED_EXT:
            raise HTTPException(400, f"File type {ext} is not allowed")
        content = await f.read()
        if len(content) > MAX_FILE_MB * 1024 * 1024:
            raise HTTPException(400, f"{f.filename} is larger than {MAX_FILE_MB} MB")
        stored = f"{uuid.uuid4().hex}{ext}"
        with open(os.path.join(UPLOAD_DIR, stored), "wb") as out:
            out.write(content)
        db.add(Attachment(ticket_id=t.id, filename=f.filename, stored_name=stored))
    for a in db.query(User).filter_by(role="agent").all():
        notify(db, a.id, t, f"New ticket #{t.id}: {t.title}")
    db.commit()
    db.refresh(t)
    return ticket_out(t, user)


@app.get("/tickets")
def list_tickets(
    status: Optional[str] = None, priority: Optional[str] = None,
    assigned: Optional[str] = Query(None, description="me | unassigned | <user id>"),
    q: Optional[str] = None,
    db: Session = Depends(get_db), user: User = Depends(current_user),
):
    query = db.query(Ticket)
    if user.role != "agent":
        query = query.filter(Ticket.owner_id == user.id)
    elif assigned == "me":
        query = query.filter(Ticket.assigned_to == user.id)
    elif assigned == "unassigned":
        query = query.filter(Ticket.assigned_to.is_(None))
    elif assigned and assigned.isdigit():
        query = query.filter(Ticket.assigned_to == int(assigned))
    if status:
        query = query.filter(Ticket.status == status)
    if priority:
        query = query.filter(Ticket.priority == priority)
    if q:
        like = f"%{q}%"
        query = query.filter(or_(Ticket.title.ilike(like), Ticket.description.ilike(like)))
    return [ticket_out(t, user) for t in query.order_by(Ticket.updated_at.desc()).all()]


@app.get("/tickets/{tid}")
def get_ticket(tid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return ticket_out(get_ticket_or_404(db, tid, user), user, detail=True)


@app.patch("/tickets/{tid}")
def update_ticket(tid: int, data: TicketUpdate, db: Session = Depends(get_db),
                  user: User = Depends(agent_only)):
    t = get_ticket_or_404(db, tid, user)
    changes = data.model_dump(exclude_unset=True)
    if "status" in changes and changes["status"] is not None:
        if changes["status"] not in STATUSES:
            raise HTTPException(400, "Invalid status")
        if changes["status"] != t.status:
            t.status = changes["status"]
            t.resolved_at = now() if t.status in ("resolved", "closed") else None
            label = t.status.replace("_", " ")
            notify(db, t.owner_id, t, f"Ticket #{t.id} is now {label}")
    if "priority" in changes and changes["priority"] is not None:
        if changes["priority"] not in PRIORITIES:
            raise HTTPException(400, "Invalid priority")
        t.priority = changes["priority"]
    if "assigned_to" in changes:
        aid = changes["assigned_to"]
        if aid is not None:
            a = db.get(User, aid)
            if not a or a.role != "agent":
                raise HTTPException(400, "Assignee must be a support agent")
        if aid != t.assigned_to:
            t.assigned_to = aid
            if aid and aid != user.id:
                notify(db, aid, t, f"Ticket #{t.id} was assigned to you")
            if t.status == "open" and aid:
                t.status = "in_progress"
                notify(db, t.owner_id, t, f"Ticket #{t.id} is now in progress")
    t.updated_at = now()
    db.commit()
    db.refresh(t)
    return ticket_out(t, user, detail=True)


@app.post("/tickets/{tid}/comments")
def add_comment(tid: int, data: CommentIn, db: Session = Depends(get_db),
                user: User = Depends(current_user)):
    t = get_ticket_or_404(db, tid, user)
    if not data.message.strip():
        raise HTTPException(400, "Write a message first")
    internal = data.is_internal and user.role == "agent"
    db.add(Comment(ticket_id=t.id, author_id=user.id, message=data.message.strip(),
                   is_internal=internal))
    t.updated_at = now()
    if not internal:
        if user.role == "agent":
            notify(db, t.owner_id, t, f"New reply on ticket #{t.id}")
        else:
            if t.status in ("resolved", "closed"):  # user replied -> reopen
                t.status, t.resolved_at = "open", None
            targets = [t.assigned_to] if t.assigned_to else \
                [a.id for a in db.query(User).filter_by(role="agent").all()]
            for uid in targets:
                notify(db, uid, t, f"{user.name} replied on ticket #{t.id}")
    db.commit()
    return ticket_out(t, user, detail=True)


# --------------------------------------------------------- notifications
@app.get("/notifications")
def notifications(db: Session = Depends(get_db), user: User = Depends(current_user)):
    rows = (db.query(Notification).filter_by(user_id=user.id)
            .order_by(Notification.created_at.desc()).limit(30).all())
    return [{"id": n.id, "ticket_id": n.ticket_id, "message": n.message,
             "is_read": n.is_read, "created_at": iso(n.created_at)} for n in rows]


@app.post("/notifications/read")
def mark_read(db: Session = Depends(get_db), user: User = Depends(current_user)):
    db.query(Notification).filter_by(user_id=user.id, is_read=False).update({"is_read": True})
    db.commit()
    return {"ok": True}


# ----------------------------------------------------------------- stats
@app.get("/stats")
def stats(db: Session = Depends(get_db), _: User = Depends(agent_only)):
    tickets = db.query(Ticket).all()
    by_status = {s: 0 for s in STATUSES}
    by_priority = {p: 0 for p in PRIORITIES}
    hours = []
    for t in tickets:
        by_status[t.status] = by_status.get(t.status, 0) + 1
        by_priority[t.priority] = by_priority.get(t.priority, 0) + 1
        if t.resolved_at:
            hours.append((t.resolved_at - t.created_at).total_seconds() / 3600)
    today = now().date()
    per_day = []
    for i in range(6, -1, -1):
        day = today - timedelta(days=i)
        per_day.append({"date": day.isoformat(),
                        "count": sum(1 for t in tickets if t.created_at.date() == day)})
    return {
        "total": len(tickets), "by_status": by_status, "by_priority": by_priority,
        "avg_resolution_hours": round(sum(hours) / len(hours), 1) if hours else None,
        "created_last_7_days": per_day,
        "unassigned": sum(1 for t in tickets if not t.assigned_to and t.status != "closed"),
    }
