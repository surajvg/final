# Backend
    python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
    pip install -r requirements.txt
    uvicorn main:app --reload

Default agent login (created on first run): agent@example.com / agent123  -> change it.
Env vars: SECRET_KEY, DATABASE_URL (e.g. postgresql://user:pass@host/db), CORS_ORIGINS.
