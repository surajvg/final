# Support module (React + FastAPI)

## 1. Backend
    cd backend
    python -m venv venv && source venv/bin/activate     # Windows: venv\Scripts\activate
    pip install -r requirements.txt
    uvicorn main:app --reload                            # http://localhost:8000/docs

A support agent is created on first run: agent@example.com / agent123 (change it!).

## 2. Frontend
    cd frontend
    npm install
    cp .env.example .env
    npm run dev                                          # http://localhost:5173

## How to use
- Users: register, click "New ticket", follow progress on the ticket page, reply, check "Updates".
- Support team: log in as agent, see all tickets, filter, assign, change status, reply, add internal notes, open Dashboard.

## Plugging into your existing ME system
- Login: replace /auth/* and `current_user()` in backend/main.py with your ME system's own auth/JWT, and map its roles to "user" / "agent".
- Database: set DATABASE_URL (e.g. postgresql://user:pass@host/db; add psycopg2-binary). Tables are created automatically.
- Frontend: mount <TicketList/>, <NewTicket/>, <TicketDetail/> inside your existing routes, or keep this as a separate app and link to it from ME.
- Production: set SECRET_KEY, set CORS_ORIGINS to your domain, and use Alembic for migrations.
