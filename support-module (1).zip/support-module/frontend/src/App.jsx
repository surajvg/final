import { createContext, useContext, useEffect, useState, useCallback } from "react";
import { Link, NavLink, Navigate, Route, Routes, useNavigate, useParams } from "react-router-dom";
import { api, fileUrl } from "./api.js";

/* ------------------------------------------------------------ helpers */
const STEPS = ["open", "in_progress", "resolved", "closed"];
const label = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1).replace("_", " ") : "");
const fmt = (iso) => new Date(iso).toLocaleString([], { dateStyle: "medium", timeStyle: "short" });

const Auth = createContext(null);
const useAuth = () => useContext(Auth);

function Badge({ kind, value }) {
  return <span className={`badge ${kind}-${value}`}>{label(value)}</span>;
}

function useLoad(fn, deps) {
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const reload = useCallback(() => {
    fn().then(setData).catch((e) => setError(e.message));
  }, deps); // eslint-disable-line
  useEffect(reload, [reload]);
  return { data, setData, error, reload };
}

/* --------------------------------------------------------------- app */
export default function App() {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!localStorage.getItem("token")) return setReady(true);
    api.me().then(setUser).catch(() => localStorage.removeItem("token")).finally(() => setReady(true));
  }, []);

  const signIn = ({ token, user }) => {
    localStorage.setItem("token", token);
    setUser(user);
  };
  const signOut = () => {
    localStorage.removeItem("token");
    setUser(null);
  };

  if (!ready) return <p className="center muted">Loading…</p>;

  return (
    <Auth.Provider value={{ user, signIn, signOut }}>
      {!user ? (
        <LoginPage />
      ) : (
        <Shell>
          <Routes>
            <Route path="/" element={<TicketList />} />
            <Route path="/new" element={<NewTicket />} />
            <Route path="/tickets/:id" element={<TicketDetail />} />
            <Route path="/dashboard" element={user.role === "agent" ? <Dashboard /> : <Navigate to="/" />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </Shell>
      )}
    </Auth.Provider>
  );
}

/* ------------------------------------------------------------- layout */
function Shell({ children }) {
  const { user, signOut } = useAuth();
  const isAgent = user.role === "agent";
  return (
    <>
      <header className="topbar">
        <Link to="/" className="brand">Support</Link>
        <nav>
          <NavLink to="/" end>{isAgent ? "All tickets" : "My tickets"}</NavLink>
          {!isAgent && <NavLink to="/new">New ticket</NavLink>}
          {isAgent && <NavLink to="/dashboard">Dashboard</NavLink>}
        </nav>
        <div className="spacer" />
        <Bell />
        <span className="muted who">{user.name}</span>
        <button className="link" onClick={signOut}>Log out</button>
      </header>
      <main className="page">{children}</main>
    </>
  );
}

function Bell() {
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);
  const nav = useNavigate();
  const load = () => api.notifications().then(setItems).catch(() => {});
  useEffect(() => {
    load();
    const t = setInterval(load, 30000);
    return () => clearInterval(t);
  }, []);
  const unread = items.filter((n) => !n.is_read).length;
  const toggle = () => {
    if (open && unread) api.markRead().then(load);
    setOpen(!open);
  };
  return (
    <div className="bell">
      <button className="link" onClick={toggle} aria-label="Notifications">
        Updates{unread > 0 && <span className="dot">{unread}</span>}
      </button>
      {open && (
        <div className="popover">
          {items.length === 0 && <p className="muted pad">No updates yet.</p>}
          {items.map((n) => (
            <button key={n.id} className={`note ${n.is_read ? "" : "unread"}`}
              onClick={() => { setOpen(false); nav(`/tickets/${n.ticket_id}`); }}>
              {n.message}
              <small>{fmt(n.created_at)}</small>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* -------------------------------------------------------------- login */
function LoginPage() {
  const { signIn } = useAuth();
  const [mode, setMode] = useState("login");
  const [f, setF] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const res = mode === "login" ? await api.login(f.email, f.password)
                                   : await api.register(f.name, f.email, f.password);
      signIn(res);
    } catch (err) { setError(err.message); }
  };

  return (
    <div className="auth">
      <form onSubmit={submit} className="card">
        <h1>{mode === "login" ? "Log in to Support" : "Create your account"}</h1>
        {mode === "register" && (
          <label>Name<input required value={f.name} onChange={set("name")} /></label>
        )}
        <label>Email<input type="email" required value={f.email} onChange={set("email")} /></label>
        <label>Password<input type="password" required minLength={6} value={f.password} onChange={set("password")} /></label>
        {error && <p className="error">{error}</p>}
        <button className="primary">{mode === "login" ? "Log in" : "Create account"}</button>
        <button type="button" className="link" onClick={() => setMode(mode === "login" ? "register" : "login")}>
          {mode === "login" ? "New here? Create an account" : "Have an account? Log in"}
        </button>
      </form>
    </div>
  );
}

/* ---------------------------------------------------------- ticket list */
function TicketList() {
  const { user } = useAuth();
  const isAgent = user.role === "agent";
  const [filters, setFilters] = useState({ status: "", priority: "", assigned: "", q: "" });
  const { data, error } = useLoad(() => api.tickets(filters), [JSON.stringify(filters)]);
  const set = (k) => (e) => setFilters({ ...filters, [k]: e.target.value });

  return (
    <>
      <div className="row">
        <h1>{isAgent ? "All tickets" : "My tickets"}</h1>
        <div className="spacer" />
        {!isAgent && <Link to="/new" className="btn primary">New ticket</Link>}
      </div>

      <div className="filters">
        <input placeholder="Search tickets" value={filters.q} onChange={set("q")} />
        <select value={filters.status} onChange={set("status")}>
          <option value="">Any status</option>
          {STEPS.map((s) => <option key={s} value={s}>{label(s)}</option>)}
        </select>
        <select value={filters.priority} onChange={set("priority")}>
          <option value="">Any priority</option>
          {["low", "medium", "high", "urgent"].map((s) => <option key={s} value={s}>{label(s)}</option>)}
        </select>
        {isAgent && (
          <select value={filters.assigned} onChange={set("assigned")}>
            <option value="">Anyone</option>
            <option value="me">Assigned to me</option>
            <option value="unassigned">Unassigned</option>
          </select>
        )}
      </div>

      {error && <p className="error">{error}</p>}
      {data && data.length === 0 && (
        <p className="empty">
          {isAgent ? "No tickets match these filters." : "You have no tickets yet. Raise one when something goes wrong."}
        </p>
      )}
      <div className="list">
        {data?.map((t) => (
          <Link key={t.id} to={`/tickets/${t.id}`} className="ticket">
            <div className="grow">
              <strong>#{t.id} {t.title}</strong>
              <small className="muted">
                {isAgent && <>{t.owner.name} · </>}{label(t.category)} · updated {fmt(t.updated_at)}
                {isAgent && <> · {t.assignee ? `assigned to ${t.assignee.name}` : "unassigned"}</>}
              </small>
            </div>
            <Badge kind="priority" value={t.priority} />
            <Badge kind="status" value={t.status} />
          </Link>
        ))}
      </div>
    </>
  );
}

/* ------------------------------------------------------------ new ticket */
function NewTicket() {
  const nav = useNavigate();
  const { data: meta } = useLoad(api.meta, []);
  const [f, setF] = useState({ title: "", description: "", category: "bug", priority: "medium" });
  const [files, setFiles] = useState([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError("");
    const form = new FormData();
    Object.entries(f).forEach(([k, v]) => form.append(k, v));
    files.forEach((file) => form.append("files", file));
    try {
      const t = await api.createTicket(form);
      nav(`/tickets/${t.id}`);
    } catch (err) { setError(err.message); setBusy(false); }
  };

  return (
    <form onSubmit={submit} className="card narrow">
      <h1>Raise a ticket</h1>
      <label>What is the problem?
        <input required maxLength={200} value={f.title} onChange={set("title")} placeholder="Short summary" />
      </label>
      <label>Details
        <textarea required rows={6} value={f.description} onChange={set("description")}
          placeholder="What were you doing, what did you expect, what happened instead?" />
      </label>
      <div className="two">
        <label>Category
          <select value={f.category} onChange={set("category")}>
            {(meta?.categories || ["bug"]).map((c) => <option key={c} value={c}>{label(c)}</option>)}
          </select>
        </label>
        <label>Priority
          <select value={f.priority} onChange={set("priority")}>
            {(meta?.priorities || ["medium"]).map((c) => <option key={c} value={c}>{label(c)}</option>)}
          </select>
        </label>
      </div>
      <label>Screenshots or files (max 5 MB each)
        <input type="file" multiple onChange={(e) => setFiles([...e.target.files])} />
      </label>
      {error && <p className="error">{error}</p>}
      <button className="primary" disabled={busy}>{busy ? "Sending…" : "Send ticket"}</button>
    </form>
  );
}

/* --------------------------------------------------------- ticket detail */
function Progress({ status }) {
  const current = STEPS.indexOf(status);
  return (
    <ol className="progress">
      {STEPS.map((s, i) => (
        <li key={s} className={i < current ? "done" : i === current ? "now" : ""}>
          <span />{label(s)}
        </li>
      ))}
    </ol>
  );
}

function TicketDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const isAgent = user.role === "agent";
  const { data: t, setData, error } = useLoad(() => api.ticket(id), [id]);
  const { data: agents } = useLoad(() => (isAgent ? api.agents() : Promise.resolve([])), [isAgent]);
  const [msg, setMsg] = useState("");
  const [internal, setInternal] = useState(false);
  const [err, setErr] = useState("");

  if (error) return <p className="error">{error}</p>;
  if (!t) return <p className="muted">Loading…</p>;

  const update = (body) => api.updateTicket(t.id, body).then(setData).catch((e) => setErr(e.message));
  const send = async (e) => {
    e.preventDefault();
    setErr("");
    try {
      setData(await api.comment(t.id, msg, internal));
      setMsg(""); setInternal(false);
    } catch (e2) { setErr(e2.message); }
  };

  return (
    <div className="detail">
      <Link to="/" className="muted">← Back to tickets</Link>
      <div className="row">
        <h1 className="grow">#{t.id} {t.title}</h1>
        <Badge kind="priority" value={t.priority} />
        <Badge kind="status" value={t.status} />
      </div>
      <Progress status={t.status} />
      <p className="muted">
        Raised by {t.owner.name} on {fmt(t.created_at)} · {label(t.category)} ·{" "}
        {t.assignee ? `Handled by ${t.assignee.name}` : "Waiting for a team member"}
        {t.resolved_at && <> · Resolved {fmt(t.resolved_at)}</>}
      </p>

      {isAgent && (
        <div className="card controls">
          <label>Status
            <select value={t.status} onChange={(e) => update({ status: e.target.value })}>
              {STEPS.map((s) => <option key={s} value={s}>{label(s)}</option>)}
            </select>
          </label>
          <label>Priority
            <select value={t.priority} onChange={(e) => update({ priority: e.target.value })}>
              {["low", "medium", "high", "urgent"].map((s) => <option key={s} value={s}>{label(s)}</option>)}
            </select>
          </label>
          <label>Assigned to
            <select value={t.assignee?.id || ""} onChange={(e) => update({ assigned_to: e.target.value ? Number(e.target.value) : null })}>
              <option value="">Unassigned</option>
              {agents?.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
            </select>
          </label>
        </div>
      )}

      <div className="card">
        <p className="pre">{t.description}</p>
        {t.attachments.length > 0 && (
          <ul className="files">
            {t.attachments.map((a) => (
              <li key={a.id}><a href={fileUrl(a.stored_name)} target="_blank" rel="noreferrer">{a.filename}</a></li>
            ))}
          </ul>
        )}
      </div>

      <h2>Conversation</h2>
      {t.comments.length === 0 && <p className="empty">No replies yet. The team will respond here.</p>}
      {t.comments.map((c) => (
        <div key={c.id} className={`comment ${c.author.role === "agent" ? "agent" : ""} ${c.is_internal ? "internal" : ""}`}>
          <div className="meta">
            <strong>{c.author.name}</strong>
            {c.author.role === "agent" && <span className="tag">Support team</span>}
            {c.is_internal && <span className="tag warn">Internal note</span>}
            <small className="muted">{fmt(c.created_at)}</small>
          </div>
          <p className="pre">{c.message}</p>
        </div>
      ))}

      <form onSubmit={send} className="card">
        <textarea required rows={3} value={msg} onChange={(e) => setMsg(e.target.value)}
          placeholder={isAgent ? "Reply to the user or add a note" : "Add a reply"} />
        {isAgent && (
          <label className="check">
            <input type="checkbox" checked={internal} onChange={(e) => setInternal(e.target.checked)} />
            Internal note (the user will not see it)
          </label>
        )}
        {err && <p className="error">{err}</p>}
        <button className="primary">{internal ? "Save note" : "Send reply"}</button>
      </form>
    </div>
  );
}

/* ------------------------------------------------------------- dashboard */
function Dashboard() {
  const { data: s, error } = useLoad(api.stats, []);
  if (error) return <p className="error">{error}</p>;
  if (!s) return <p className="muted">Loading…</p>;
  const max = Math.max(1, ...s.created_last_7_days.map((d) => d.count));
  return (
    <>
      <h1>Dashboard</h1>
      <div className="stats">
        <div className="card"><b>{s.total}</b><span>Total tickets</span></div>
        <div className="card"><b>{s.by_status.open}</b><span>Open</span></div>
        <div className="card"><b>{s.unassigned}</b><span>Unassigned</span></div>
        <div className="card"><b>{s.avg_resolution_hours ?? "–"}</b><span>Avg hours to resolve</span></div>
      </div>
      <div className="two">
        <div className="card">
          <h2>By status</h2>
          {Object.entries(s.by_status).map(([k, v]) => (
            <div key={k} className="bar"><span>{label(k)}</span><i style={{ width: `${(v / Math.max(1, s.total)) * 100}%` }} /><em>{v}</em></div>
          ))}
        </div>
        <div className="card">
          <h2>By priority</h2>
          {Object.entries(s.by_priority).map(([k, v]) => (
            <div key={k} className="bar"><span>{label(k)}</span><i style={{ width: `${(v / Math.max(1, s.total)) * 100}%` }} /><em>{v}</em></div>
          ))}
        </div>
      </div>
      <div className="card">
        <h2>Raised in the last 7 days</h2>
        <div className="days">
          {s.created_last_7_days.map((d) => (
            <div key={d.date}>
              <em>{d.count}</em>
              <i style={{ height: `${(d.count / max) * 100}px` }} />
              <small>{new Date(d.date).toLocaleDateString([], { weekday: "short" })}</small>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
