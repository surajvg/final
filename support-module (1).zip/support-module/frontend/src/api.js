const BASE = import.meta.env.VITE_API_URL || "http://localhost:8000";

export const fileUrl = (storedName) => `${BASE}/uploads/${storedName}`;

async function request(path, { method = "GET", body, form } = {}) {
  const headers = {};
  const token = localStorage.getItem("token");
  if (token) headers.Authorization = `Bearer ${token}`;
  let payload;
  if (form) payload = form;
  else if (body) {
    headers["Content-Type"] = "application/json";
    payload = JSON.stringify(body);
  }
  const res = await fetch(BASE + path, { method, headers, body: payload });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    if (res.status === 401 && token) {
      localStorage.removeItem("token");
    }
    throw new Error(typeof err.detail === "string" ? err.detail : "Something went wrong");
  }
  return res.json();
}

const qs = (params) => {
  const p = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => v && p.set(k, v));
  const s = p.toString();
  return s ? `?${s}` : "";
};

export const api = {
  login: (email, password) => request("/auth/login", { method: "POST", body: { email, password } }),
  register: (name, email, password) =>
    request("/auth/register", { method: "POST", body: { name, email, password } }),
  me: () => request("/auth/me"),
  meta: () => request("/meta"),
  agents: () => request("/agents"),
  tickets: (filters = {}) => request("/tickets" + qs(filters)),
  ticket: (id) => request(`/tickets/${id}`),
  createTicket: (form) => request("/tickets", { method: "POST", form }),
  updateTicket: (id, body) => request(`/tickets/${id}`, { method: "PATCH", body }),
  comment: (id, message, is_internal) =>
    request(`/tickets/${id}/comments`, { method: "POST", body: { message, is_internal } }),
  notifications: () => request("/notifications"),
  markRead: () => request("/notifications/read", { method: "POST" }),
  stats: () => request("/stats"),
};
